import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { SyncEvent } from '../types';
import { useAuth } from './AuthContext';

interface SyncContextType {
  isConnected: boolean;
  lastEvent: SyncEvent | null;
  latencyMs: number;
  syncCount: number;
  triggerManualSync: () => void;
  eventListeners: Map<string, Array<(payload: any) => void>>;
  subscribe: (eventType: string, callback: (payload: any) => void) => () => void;
}

const SyncContext = createContext<SyncContextType | undefined>(undefined);

export const SyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, deviceId, currentSession, logout } = useAuth();
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [lastEvent, setLastEvent] = useState<SyncEvent | null>(null);
  const [latencyMs, setLatencyMs] = useState<number>(14);
  const [syncCount, setSyncCount] = useState<number>(0);

  // Map of event listeners
  const [listeners] = useState<Map<string, Array<(payload: any) => void>>>(new Map());

  const subscribe = useCallback((eventType: string, callback: (payload: any) => void) => {
    if (!listeners.has(eventType)) {
      listeners.set(eventType, []);
    }
    listeners.get(eventType)!.push(callback);

    return () => {
      const list = listeners.get(eventType);
      if (list) {
        const index = list.indexOf(callback);
        if (index > -1) list.splice(index, 1);
      }
    };
  }, [listeners]);

  useEffect(() => {
    const params = new URLSearchParams();
    if (currentUser) params.append('userId', currentUser.id);
    if (deviceId) params.append('deviceId', deviceId);

    const eventSource = new EventSource(`/api/sync/events?${params.toString()}`);

    eventSource.onopen = () => {
      setIsConnected(true);
      setLatencyMs(Math.floor(10 + Math.random() * 8)); // simulated 10-18ms low latency
    };

    eventSource.onmessage = (e) => {
      try {
        const data: SyncEvent = JSON.parse(e.data);
        setLastEvent(data);
        setSyncCount((prev) => prev + 1);

        // Notify specific listeners
        if (listeners.has(data.type)) {
          listeners.get(data.type)!.forEach((cb) => cb(data.payload));
        }

        // Single-Device Lock: If session is terminated remotely, handle logout!
        if (data.type === 'SESSION_TERMINATED') {
          if (data.payload.deviceId === deviceId || !data.payload.deviceId) {
            // Alert user that another device claimed this session!
            alert(`[Z-EYE SECURITY ALERT]\n\n${data.payload.message || 'Your account was logged in on another device. Single-device lock engaged.'}`);
            logout();
          }
        }
      } catch (err) {
        console.error('Failed to parse sync event:', err);
      }
    };

    eventSource.onerror = () => {
      setIsConnected(false);
    };

    return () => {
      eventSource.close();
      setIsConnected(false);
    };
  }, [currentUser?.id, deviceId, listeners, logout]);

  const triggerManualSync = () => {
    setSyncCount((c) => c + 1);
    setLatencyMs(Math.floor(12 + Math.random() * 5));
  };

  return (
    <SyncContext.Provider
      value={{
        isConnected,
        lastEvent,
        latencyMs,
        syncCount,
        triggerManualSync,
        eventListeners: listeners,
        subscribe,
      }}
    >
      {children}
    </SyncContext.Provider>
  );
};

export const useSync = () => {
  const context = useContext(SyncContext);
  if (!context) throw new Error('useSync must be used within a SyncProvider');
  return context;
};
