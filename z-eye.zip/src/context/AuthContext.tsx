import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '../types';
import { api, getOrCreateDeviceId, getDeviceModel, setDeviceModel } from '../services/api';

interface AuthContextType {
  currentUser: User | null;
  currentSession: Session | null;
  deviceId: string;
  deviceModel: string;
  isLoading: boolean;
  isForcedLogout: boolean;
  forcedLogoutReason: string | null;
  takeoverPrompt: {
    isOpen: boolean;
    existingDevice: any;
    targetUserId: string;
    pendingCredentials?: any;
  } | null;
  updateDeviceModel: (newModel: string) => void;
  loginDemo: (userId?: string) => Promise<void>;
  requestOtp: (identifier: string) => Promise<{ success: boolean; message: string; debugCode?: string }>;
  verifyOtp: (identifier: string, code: string) => Promise<{ success: boolean; error?: string }>;
  resolveTakeover: (confirm: boolean) => Promise<void>;
  logout: () => void;
  clearForcedLogout: () => void;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [deviceId, setDeviceId] = useState<string>('');
  const [deviceModel, setDevModel] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isForcedLogout, setIsForcedLogout] = useState<boolean>(false);
  const [forcedLogoutReason, setForcedLogoutReason] = useState<string | null>(null);
  const [takeoverPrompt, setTakeoverPrompt] = useState<{
    isOpen: boolean;
    existingDevice: any;
    targetUserId: string;
    pendingCredentials?: any;
  } | null>(null);

  useEffect(() => {
    const id = getOrCreateDeviceId();
    const model = getDeviceModel();
    setDeviceId(id);
    setDevModel(model);

    // Auto-login with default demo user on first boot for smooth preview
    const savedUserId = localStorage.getItem('zeye_user_id') || 'u-apex';
    loginDemo(savedUserId);
  }, []);

  const updateDeviceModel = (newModel: string) => {
    setDeviceModel(newModel);
    setDevModel(newModel);
  };

  const loginDemo = async (userId: string = 'u-apex') => {
    setIsLoading(true);
    try {
      const devId = getOrCreateDeviceId();
      const model = getDeviceModel();
      const res = await api.demoLogin(userId, devId, model);
      if (res.success) {
        setCurrentUser(res.user);
        setCurrentSession(res.session);
        localStorage.setItem('zeye_user_id', res.user.id);
        setIsForcedLogout(false);
        setForcedLogoutReason(null);
      }
    } catch (e) {
      console.error('Demo login error:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const requestOtp = async (identifier: string) => {
    return api.requestOtp(identifier);
  };

  const verifyOtp = async (identifier: string, code: string) => {
    try {
      const devId = getOrCreateDeviceId();
      const model = getDeviceModel();
      const res = await api.verifyOtp({
        identifier,
        code,
        deviceId: devId,
        deviceModel: model,
        locationCity: 'Tokyo, JP',
      });

      if (res.error === 'ACTIVE_SESSION_EXISTS') {
        // Trigger Single-Device Lock prompt!
        setTakeoverPrompt({
          isOpen: true,
          existingDevice: res.existingDevice,
          targetUserId: res.userId,
          pendingCredentials: { identifier, code },
        });
        return { success: false, error: 'ACTIVE_SESSION_EXISTS' };
      }

      if (res.success) {
        setCurrentUser(res.user);
        setCurrentSession(res.session);
        localStorage.setItem('zeye_user_id', res.user.id);
        setIsForcedLogout(false);
        setForcedLogoutReason(null);
        return { success: true };
      }

      return { success: false, error: res.error || 'Verification failed.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const resolveTakeover = async (confirm: boolean) => {
    if (!takeoverPrompt) return;

    if (confirm) {
      const devId = getOrCreateDeviceId();
      const model = getDeviceModel();
      const res = await api.confirmDeviceTakeover({
        userId: takeoverPrompt.targetUserId,
        deviceId: devId,
        deviceModel: model,
        locationCity: 'Tokyo, JP',
      });

      if (res.success) {
        setCurrentUser(res.user);
        setCurrentSession(res.session);
        localStorage.setItem('zeye_user_id', res.user.id);
        setIsForcedLogout(false);
        setForcedLogoutReason(null);
      }
    }

    setTakeoverPrompt(null);
  };

  const logout = () => {
    if (currentSession) {
      api.terminateSession(currentSession.id);
    }
    setCurrentUser(null);
    setCurrentSession(null);
    localStorage.removeItem('zeye_user_id');
  };

  const clearForcedLogout = () => {
    setIsForcedLogout(false);
    setForcedLogoutReason(null);
  };

  const refreshUserProfile = async () => {
    if (!currentUser) return;
    try {
      const res = await api.getUserProfile(currentUser.id, currentUser.id);
      if (res.user) {
        setCurrentUser(res.user);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentSession,
        deviceId,
        deviceModel,
        isLoading,
        isForcedLogout,
        forcedLogoutReason,
        takeoverPrompt,
        updateDeviceModel,
        loginDemo,
        requestOtp,
        verifyOtp,
        resolveTakeover,
        logout,
        clearForcedLogout,
        refreshUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
