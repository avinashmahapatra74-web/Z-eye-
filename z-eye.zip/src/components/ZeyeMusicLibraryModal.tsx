import React, { useState, useEffect } from 'react';
import {
  Music,
  Play,
  Pause,
  Volume2,
  Sparkles,
  X,
  Check,
  Disc,
  Flame,
  Radio,
  Sliders,
  Wand2,
  Headphones,
} from 'lucide-react';
import { ZeyeTrackItem } from '../types';
import { synthEngine, SOUNDTRACK_PRESETS } from '../utils/audioSynth';
import { api } from '../services/api';

interface ZeyeMusicLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTrack: (track: { id: string; title: string; artist: string; isAiGenerated?: boolean }) => void;
  currentSelectedId?: string;
}

const DEFAULT_CATALOG: ZeyeTrackItem[] = [
  {
    id: 'cyber_pulse',
    title: 'Neon Drift Anthem',
    artist: 'Z-eye Sound Lab',
    genre: 'Cyberpunk',
    bpm: 128,
    duration: 30,
    tags: ['#Trending', '#Cyberpunk', '#Reels'],
    coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'lofi_midnight',
    title: 'Monsoon Rooftop Lofi',
    artist: 'Desi Chill Station',
    genre: 'Desi Lofi',
    bpm: 85,
    duration: 45,
    tags: ['#DesiLofi', '#ChaiVibes', '#Aesthetic'],
    coverArt: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'hyper_trap',
    title: 'Tokyo Midnight Phonk',
    artist: 'Drift King 808',
    genre: 'Phonk & Bass',
    bpm: 140,
    duration: 25,
    tags: ['#Phonk', '#BassBoosted', '#ViralReel'],
    coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'sunset_acoustic',
    title: 'Golden Sunset In Goa',
    artist: 'Acoustic Soul',
    genre: 'Trending Reels',
    bpm: 100,
    duration: 35,
    tags: ['#Trending', '#Travel', '#GoldenHour'],
    coverArt: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'deep_nebula',
    title: 'Interstellar Nebula 432Hz',
    artist: 'Aetheria Ambient',
    genre: 'Cinematic',
    bpm: 60,
    duration: 60,
    tags: ['#Cinematic', '#DeepFocus', '#AMOLED'],
    coverArt: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=300&auto=format&fit=crop&q=80',
  },
];

export const ZeyeMusicLibraryModal: React.FC<ZeyeMusicLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectTrack,
  currentSelectedId,
}) => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'ai_composer'>('catalog');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [tracks, setTracks] = useState<ZeyeTrackItem[]>(DEFAULT_CATALOG);
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [volume, setVolume] = useState<number>(80);

  // AI Composer State
  const [aiPrompt, setAiPrompt] = useState<string>('Heavy phonk bass with aggressive 808 and drift whistle');
  const [aiGenre, setAiGenre] = useState<string>('Phonk & Bass');
  const [aiBpm, setAiBpm] = useState<number>(140);
  const [isAiComposing, setIsAiComposing] = useState<boolean>(false);
  const [generatedTrack, setGeneratedTrack] = useState<ZeyeTrackItem | null>(null);

  useEffect(() => {
    return () => {
      synthEngine.stop();
    };
  }, []);

  if (!isOpen) return null;

  const genres = ['All', 'Trending Reels', 'Phonk & Bass', 'Desi Lofi', 'Cyberpunk', 'Cinematic'];

  const filteredTracks = selectedGenre === 'All'
    ? tracks
    : tracks.filter((t) => t.genre === selectedGenre);

  const handlePlayToggle = (track: ZeyeTrackItem) => {
    if (playingTrackId === track.id) {
      synthEngine.stop();
      setPlayingTrackId(null);
    } else {
      synthEngine.setVolume(volume / 100);
      if (track.audioRecipe) {
        synthEngine.playCustomRecipe(track.audioRecipe);
      } else {
        synthEngine.playTrack(track.id);
      }
      setPlayingTrackId(track.id);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    synthEngine.setVolume(newVol / 100);
  };

  const handleGenerateAiMusic = async () => {
    setIsAiComposing(true);
    try {
      const res = await api.generateAiMusic({
        prompt: aiPrompt,
        genre: aiGenre,
        bpm: aiBpm,
      });

      if (res && res.id) {
        const fullTrack: ZeyeTrackItem = {
          ...res,
          coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
        };
        setGeneratedTrack(fullTrack);
        setTracks((prev) => [fullTrack, ...prev]);

        // Auto-play the newly composed track
        if (fullTrack.audioRecipe) {
          synthEngine.setVolume(volume / 100);
          synthEngine.playCustomRecipe(fullTrack.audioRecipe);
          setPlayingTrackId(fullTrack.id);
        }
      }
    } catch (e) {
      console.error('AI music generation failed:', e);
    } finally {
      setIsAiComposing(false);
    }
  };

  const handleChooseTrack = (track: ZeyeTrackItem) => {
    synthEngine.stop();
    onSelectTrack({
      id: track.id,
      title: track.title,
      artist: track.artist,
      isAiGenerated: track.isAiGenerated,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div
        className="w-full max-w-xl bg-[#0B0D10] border border-[#1E232B] rounded-2xl overflow-hidden shadow-2xl shadow-cyan-950/40 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#14171C] flex items-center justify-between bg-gradient-to-r from-black via-[#0E1116] to-black">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
              <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                <Music className="w-4 h-4 text-[#00E5FF]" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Z-eye Music & Sound Library</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
                  Zero-MB Audio
                </span>
              </h2>
              <p className="text-xs text-[#9AA4AF]">
                Royalty-free trending tracks & AI procedural music maestro
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              synthEngine.stop();
              onClose();
            }}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#14171C] hover:bg-[#222730] text-[#9AA4AF] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 pb-2 border-b border-[#14171C] flex items-center space-x-2 bg-[#080A0D]">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'catalog'
                ? 'bg-[#14171C] text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                : 'text-[#9AA4AF] hover:text-white'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>Official Sounds ({tracks.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('ai_composer')}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
              activeTab === 'ai_composer'
                ? 'bg-gradient-to-r from-[#7C4DFF]/20 to-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/50 shadow-sm'
                : 'text-[#9AA4AF] hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>✨ AI Music Generator</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'catalog' ? (
            <>
              {/* Genre Pills */}
              <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
                {genres.map((g) => (
                  <button
                    key={g}
                    onClick={() => setSelectedGenre(g)}
                    className={`px-3 py-1 rounded-lg text-xs whitespace-nowrap transition-all ${
                      selectedGenre === g
                        ? 'bg-[#00E5FF] text-black font-bold shadow-md shadow-[#00E5FF]/20'
                        : 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>

              {/* Tracks List */}
              <div className="space-y-2">
                {filteredTracks.map((track) => {
                  const isPlaying = playingTrackId === track.id;
                  const isAttached = currentSelectedId === track.id;

                  return (
                    <div
                      key={track.id}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between ${
                        isPlaying
                          ? 'bg-[#12161E] border-[#00E5FF]/50 shadow-md shadow-[#00E5FF]/10'
                          : isAttached
                          ? 'bg-[#0E1116] border-emerald-500/40'
                          : 'bg-[#0E1116] border-[#181C22] hover:border-[#262C36]'
                      }`}
                    >
                      <div className="flex items-center space-x-3 min-w-0 flex-1">
                        <button
                          onClick={() => handlePlayToggle(track)}
                          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-transform active:scale-95 flex-shrink-0 ${
                            isPlaying
                              ? 'bg-[#00E5FF] text-black shadow-lg shadow-[#00E5FF]/30'
                              : 'bg-[#1E232B] text-white hover:bg-[#2A313C]'
                          }`}
                        >
                          {isPlaying ? (
                            <Pause className="w-5 h-5 fill-current" />
                          ) : (
                            <Play className="w-5 h-5 fill-current ml-0.5" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center space-x-1.5">
                            <h4 className="text-sm font-semibold text-white truncate">
                              {track.title}
                            </h4>
                            {track.isAiGenerated && (
                              <span className="text-[9px] px-1 py-0.2 rounded bg-purple-900/60 text-purple-300 border border-purple-500/30">
                                AI
                              </span>
                            )}
                          </div>
                          <div className="flex items-center space-x-2 text-[11px] text-[#9AA4AF] mt-0.5">
                            <span className="truncate">{track.artist}</span>
                            <span>•</span>
                            <span className="font-mono text-[10px] text-cyan-400">{track.bpm} BPM</span>
                            <span>•</span>
                            <span className="text-[10px] text-emerald-400">0.00 MB</span>
                          </div>
                        </div>
                      </div>

                      {/* Right Action */}
                      <div className="flex items-center space-x-2 flex-shrink-0 ml-3">
                        {isPlaying && (
                          <div className="flex items-center space-x-0.5 px-2 py-1 rounded bg-[#00E5FF]/10 text-[#00E5FF] text-[10px] font-mono">
                            <span className="w-1 h-3 bg-[#00E5FF] animate-pulse rounded-full" />
                            <span className="w-1 h-4 bg-[#00E5FF] animate-bounce rounded-full delay-75" />
                            <span className="w-1 h-2 bg-[#00E5FF] animate-pulse rounded-full delay-150" />
                          </div>
                        )}
                        <button
                          onClick={() => handleChooseTrack(track)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-all ${
                            isAttached
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] hover:brightness-110 text-white shadow-sm'
                          }`}
                        >
                          {isAttached ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Selected</span>
                            </>
                          ) : (
                            <span>Use Track</span>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            /* AI Composer Tab */
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-purple-950/30 via-cyan-950/20 to-black border border-purple-500/30">
                <div className="flex items-center space-x-2 text-xs text-purple-300 font-semibold mb-1">
                  <Sparkles className="w-4 h-4 text-[#00E5FF]" />
                  <span>Z-AI Procedural Music Maestro</span>
                </div>
                <p className="text-xs text-[#9AA4AF]">
                  Apne reel ya short video ke hisaab se mood describe karein. AI real-time me Web Audio synthesis ke saath custom royalty-free beat compose karega!
                </p>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
                  Track Mood & Prompt:
                </label>
                <textarea
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g. Dark Phonk beat with 808 drift bass and energetic high-tempo rhythm..."
                  className="w-full h-20 px-3 py-2 bg-[#14171C] border border-[#222730] rounded-xl text-xs text-white focus:outline-none focus:border-[#00E5FF] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
                    Genre:
                  </label>
                  <select
                    value={aiGenre}
                    onChange={(e) => setAiGenre(e.target.value)}
                    className="w-full px-3 py-2 bg-[#14171C] border border-[#222730] rounded-xl text-xs text-white focus:outline-none focus:border-[#00E5FF]"
                  >
                    <option value="Phonk & Bass">Phonk & Bass (Drift Reels)</option>
                    <option value="Desi Lofi">Desi & Bollywood Lofi</option>
                    <option value="Cyberpunk">Cyberpunk / Synthwave</option>
                    <option value="Trending Reels">Trending Reels Anthem</option>
                    <option value="Cinematic">Cinematic Space Drone</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#F5F7FA] block mb-1.5">
                    Tempo: <span className="text-[#00E5FF] font-mono">{aiBpm} BPM</span>
                  </label>
                  <input
                    type="range"
                    min={70}
                    max={165}
                    value={aiBpm}
                    onChange={(e) => setAiBpm(Number(e.target.value))}
                    className="w-full accent-[#00E5FF]"
                  />
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateAiMusic}
                disabled={isAiComposing}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow-lg shadow-[#00E5FF]/20 hover:brightness-110 active:scale-98 disabled:opacity-50 transition-all"
              >
                {isAiComposing ? (
                  <>
                    <Wand2 className="w-4 h-4 animate-spin" />
                    <span>AI Composing Synthesizer Notes...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>Generate AI Sound Track Now</span>
                  </>
                )}
              </button>

              {/* Generated Result Card */}
              {generatedTrack && (
                <div className="p-3.5 rounded-xl bg-[#0E1116] border border-[#00E5FF]/40 shadow-lg shadow-[#00E5FF]/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <h4 className="text-sm font-bold text-white">{generatedTrack.title}</h4>
                        <span className="text-[9px] px-1 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                          AI Created
                        </span>
                      </div>
                      <p className="text-[11px] text-[#9AA4AF] mt-0.5">
                        {generatedTrack.artist} • {generatedTrack.bpm} BPM • 0.00 MB Procedural
                      </p>
                    </div>

                    <button
                      onClick={() => handlePlayToggle(generatedTrack)}
                      className="w-9 h-9 rounded-xl bg-[#00E5FF] text-black flex items-center justify-center font-bold"
                    >
                      {playingTrackId === generatedTrack.id ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>
                  </div>

                  <button
                    onClick={() => handleChooseTrack(generatedTrack)}
                    className="w-full py-2 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Attach This AI Beat to My Post</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Master Volume */}
        <div className="px-5 py-3 border-t border-[#14171C] bg-black/90 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-[#9AA4AF]">
            <Volume2 className="w-4 h-4 text-[#00E5FF]" />
            <span>Master Volume:</span>
            <input
              type="range"
              min={0}
              max={100}
              value={volume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              className="w-24 accent-[#00E5FF]"
            />
            <span className="font-mono text-[11px] text-white">{volume}%</span>
          </div>

          <button
            onClick={() => {
              synthEngine.stop();
              onClose();
            }}
            className="px-4 py-1.5 rounded-lg bg-[#14171C] hover:bg-[#222730] text-xs text-[#9AA4AF] hover:text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
