import React, { useState } from 'react';
import { PlatformMode } from '../types';
import {
  Smartphone,
  Monitor,
  Laptop,
  CheckCircle2,
  Sparkles,
  Zap,
  Activity,
  ShieldCheck,
  UserPlus,
  Check,
} from 'lucide-react';
import { useSync } from '../context/SyncContext';

interface DesktopRightPanelProps {
  platformMode: PlatformMode;
  onSelectPlatform: (mode: PlatformMode) => void;
  onSwitchToMobile: () => void;
  onOpenOptimizer?: () => void;
}

const TRENDING_CREATORS = [
  {
    id: 'tc-1',
    name: 'Aura Cinematics',
    username: 'aura_cine',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    type: 'Short Video Producer',
  },
  {
    id: 'tc-2',
    name: 'Tokyo Rain Lab',
    username: 'tokyo_rain',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    type: 'High-Contrast Photo',
  },
  {
    id: 'tc-3',
    name: 'Cyber Horizon',
    username: 'cyber_horizon',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    type: 'Visual 3D & Reels',
  },
];

export const DesktopRightPanel: React.FC<DesktopRightPanelProps> = ({
  platformMode,
  onSelectPlatform,
  onSwitchToMobile,
  onOpenOptimizer,
}) => {
  const { isConnected, latencyMs } = useSync();
  const [followingState, setFollowingState] = useState<Record<string, boolean>>({});

  const toggleFollow = (id: string) => {
    setFollowingState((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const platforms: { id: PlatformMode; label: string; sub: string; icon: string }[] = [
    { id: 'android', label: 'Android', sub: 'AMOLED Mobile', icon: '🤖' },
    { id: 'ios', label: 'Apple iOS', sub: 'iPhone 16 Pro', icon: '🍏' },
    { id: 'desktop', label: 'Windows PC', sub: 'Fluent 4K', icon: '💻' },
    { id: 'mac', label: 'macOS', sub: 'Apple Silicon', icon: '🍎' },
  ];

  return (
    <aside className="w-80 shrink-0 space-y-4 p-4 border-l border-[#1C2028] hidden lg:block sticky top-0 h-screen overflow-y-auto select-none bg-[#0B0D10]/50">
      {/* 1. Interactive Platform Mode Switcher Widget */}
      <div className="p-4 rounded-2xl bg-[#0E1117] border border-[#222730] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Monitor className="w-4 h-4 text-[#00E5FF]" />
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider">
              Platform Switcher
            </h3>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] font-semibold">
            4 Modes
          </span>
        </div>

        <p className="text-[11px] text-[#9AA4AF] leading-relaxed">
          Switch live layout between Android, iOS, Windows Desktop, and Mac.
        </p>

        <div className="grid grid-cols-2 gap-2">
          {platforms.map((p) => {
            const isCurrent = platformMode === p.id;
            return (
              <button
                key={p.id}
                onClick={() => {
                  onSelectPlatform(p.id);
                  if (p.id === 'android' || p.id === 'ios') {
                    onSwitchToMobile();
                  }
                }}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-r from-[#7C4DFF]/25 to-[#00E5FF]/25 border-[#00E5FF] text-white shadow-md shadow-[#00E5FF]/10'
                    : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:text-white hover:border-[#384152]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-base">{p.icon}</span>
                  {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF]" />}
                </div>
                <div className="mt-1">
                  <p className="font-bold text-xs text-white">{p.label}</p>
                  <p className="text-[9px] text-[#9AA4AF] font-mono">{p.sub}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* USER REQUEST: SENTINEL AI BOT (Device Optimization & Zero-MB Data Saver) */}
      <div className="p-4 rounded-2xl bg-gradient-to-b from-[#14171C] to-[#0E1117] border border-emerald-500/30 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Zap className="w-3.5 h-3.5 fill-emerald-400" />
            </div>
            <h4 className="font-extrabold text-xs text-white uppercase tracking-wider">
              Sentinel AI Bot
            </h4>
          </div>
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">
            ZERO-MB ACTIVE
          </span>
        </div>

        <p className="text-[11px] text-[#9AA4AF] leading-relaxed">
          Screen-size adaptive auto-scaler & neural AV1 codec that slashes reel data consumption by 97.4%!
        </p>

        {onOpenOptimizer && (
          <button
            onClick={onOpenOptimizer}
            className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500/20 to-[#00E5FF]/20 hover:from-emerald-500/30 hover:to-[#00E5FF]/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-sm shadow-emerald-500/10 active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Open Device Optimizer & Downloads</span>
          </button>
        )}
      </div>

      {/* 2. AMOLED Display Engine Specs */}
      <div className="p-4 rounded-2xl bg-[#0E1117] border border-[#222730] space-y-2.5">
        <div className="flex items-center space-x-2">
          <Zap className="w-4 h-4 text-[#00E5FF]" />
          <h4 className="font-bold text-xs text-white uppercase tracking-wider">
            AMOLED Visual Engine
          </h4>
        </div>

        <div className="space-y-1.5 text-xs">
          <div className="flex justify-between py-1 border-b border-[#14171C]">
            <span className="text-[#9AA4AF]">Pure Black Lum</span>
            <span className="font-mono text-white font-semibold">0.000 nits (#000000)</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#14171C]">
            <span className="text-[#9AA4AF]">Contrast Ratio</span>
            <span className="font-mono text-[#00E5FF] font-semibold">∞ : 1 Infinite</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#14171C]">
            <span className="text-[#9AA4AF]">Refresh Rate</span>
            <span className="font-mono text-emerald-400 font-semibold">120Hz ProMotion</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-[#9AA4AF]">Media Engine</span>
            <span className="font-mono text-white">Photos & Short Videos</span>
          </div>
        </div>
      </div>

      {/* 3. Real-time SRE & Single-Device Lock Telemetry */}
      <div className="p-4 rounded-2xl bg-[#0E1117] border border-[#222730] space-y-2.5">
        <div className="flex items-center space-x-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <h4 className="font-bold text-xs text-white uppercase tracking-wider">
            Live Telemetry
          </h4>
        </div>
        <div className="space-y-1.5 text-xs">
          <div className="flex justify-between py-1 border-b border-[#14171C]">
            <span className="text-[#9AA4AF]">Sync Socket</span>
            <span className="font-mono text-emerald-400 font-semibold">
              {isConnected ? 'ONLINE' : 'CONNECTING'}
            </span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#14171C]">
            <span className="text-[#9AA4AF]">Ping Latency</span>
            <span className="font-mono text-white">{latencyMs} ms</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-[#9AA4AF]">Single-Device Lock</span>
            <span className="font-mono text-emerald-400">ENFORCED (1 Device)</span>
          </div>
        </div>
      </div>

      {/* 4. Trending Visual Creators */}
      <div className="p-4 rounded-2xl bg-[#0E1117] border border-[#222730] space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-xs text-white uppercase tracking-wider">
            Suggested Creators
          </h4>
          <span className="text-[10px] text-[#00E5FF] font-semibold cursor-pointer hover:underline">
            View All
          </span>
        </div>

        <div className="space-y-2.5">
          {TRENDING_CREATORS.map((creator) => {
            const isFollowing = !!followingState[creator.id];
            return (
              <div key={creator.id} className="flex items-center justify-between space-x-2">
                <div className="flex items-center space-x-2 min-w-0">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-8 h-8 rounded-full object-cover shrink-0 bg-black"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">{creator.name}</p>
                    <p className="text-[10px] text-[#9AA4AF] truncate">@{creator.username}</p>
                  </div>
                </div>
                <button
                  onClick={() => toggleFollow(creator.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-all ${
                    isFollowing
                      ? 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                      : 'bg-[#00E5FF] text-black hover:opacity-90 font-bold'
                  }`}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </aside>
  );
};
