import React, { useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, X, CheckCircle2 } from 'lucide-react';

interface SafetyReportModalProps {
  postId: string | null;
  onClose: () => void;
}

const REPORT_CATEGORIES = [
  { id: 'spam', label: 'Spam or Bot activity' },
  { id: 'hate_speech', label: 'Hate speech or harassment' },
  { id: 'violence', label: 'Graphic violence or dangerous content' },
  { id: 'nudity', label: 'Non-consensual nudity or adult content' },
  { id: 'copyright', label: 'Copyright or intellectual property' },
  { id: 'csam', label: 'Child safety violation (Zero Tolerance / Immediate Escalate)' },
  { id: 'other', label: 'Other community guideline breach' },
];

export const SafetyReportModal: React.FC<SafetyReportModalProps> = ({ postId, onClose }) => {
  const { currentUser } = useAuth();
  const [category, setCategory] = useState('spam');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (!postId) return null;

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.submitReport({
        reporterUserId: currentUser?.id || 'anonymous',
        targetType: 'post',
        targetId: postId,
        category,
        notes,
      });
      setSubmitted(true);
    } catch (e) {
      console.error(e);
      alert('Failed to submit report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-[#0B0D10] border border-[#222730] rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#14171C]">
          <div className="flex items-center space-x-2 text-rose-500">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="font-bold text-sm text-white">Report Content</h3>
          </div>
          <button onClick={onClose} className="text-[#9AA4AF] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-6 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h4 className="font-bold text-sm text-white">Report Submitted</h4>
            <p className="text-xs text-[#9AA4AF] max-w-xs mx-auto">
              Our automated UGC violation shield and 24/7 trust & safety engineers will review this post immediately.
            </p>
            <button
              onClick={onClose}
              className="mt-3 px-5 py-2 rounded-xl bg-[#00E5FF] text-black font-bold text-xs"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitReport} className="space-y-3 text-xs">
            <p className="text-[#9AA4AF]">
              Why are you reporting this post? Your report is confidential and logged in the immutable audit trail.
            </p>

            <div className="space-y-1.5">
              {REPORT_CATEGORIES.map((cat) => (
                <label
                  key={cat.id}
                  className={`flex items-center space-x-2 p-2.5 rounded-xl border cursor-pointer transition-colors ${
                    category === cat.id
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-white font-medium'
                      : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:text-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="category"
                    value={cat.id}
                    checked={category === cat.id}
                    onChange={(e) => setCategory(e.target.value)}
                    className="accent-[#00E5FF]"
                  />
                  <span>{cat.label}</span>
                </label>
              ))}
            </div>

            <div>
              <label className="text-[#9AA4AF] block mb-1">Additional Context (Optional)</label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Help us understand the issue..."
                className="w-full bg-[#14171C] border border-[#222730] rounded-xl p-2.5 text-white resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition-colors disabled:opacity-50"
              >
                {submitting ? 'Submitting...' : 'Submit Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
