import React, { useState, useEffect } from 'react';
import { User, Post } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import {
  Settings,
  Shield,
  Link as LinkIcon,
  CheckCircle2,
  Grid,
  Sparkles,
  Smartphone,
  LogOut,
  Edit3,
  X,
  Lock,
  Globe,
  Download,
  Trash2,
} from 'lucide-react';

interface ProfileViewProps {
  onOpenDeviceManager: () => void;
  onPostSelect: (post: Post) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onOpenDeviceManager, onPostSelect }) => {
  const { currentUser, loginDemo, logout, refreshUserProfile } = useAuth();
  const [profileData, setProfileData] = useState<{
    user: User;
    stats: { postsCount: number; followersCount: number; followingCount: number; isFollowing: boolean };
    posts: Post[];
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  // Edit fields
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [pronouns, setPronouns] = useState('');
  const [linkInput, setLinkInput] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [isAiPolishing, setIsAiPolishing] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    loadProfile();
  }, [currentUser?.id]);

  const loadProfile = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const res = await api.getUserProfile(currentUser.id, currentUser.id);
      setProfileData(res);
      setDisplayName(res.user.displayName || '');
      setBio(res.user.bio || '');
      setPronouns(res.user.pronouns || '');
      setLinkInput(res.user.links?.join(', ') || '');
      setIsPrivate(res.user.isPrivate || false);
    } catch (err) {
      console.error('Error fetching profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const links = linkInput
      .split(',')
      .map((l) => l.trim())
      .filter(Boolean);

    await api.updateProfile(currentUser.id, {
      displayName,
      bio: bio.slice(0, 150),
      pronouns,
      links,
      isPrivate,
    });

    await refreshUserProfile();
    await loadProfile();
    setIsEditModalOpen(false);
  };

  const handleAiFixBio = async () => {
    setIsAiPolishing(true);
    try {
      const res = await api.aiFixBio(bio, 'FPS gaming, AMOLED aesthetic, streaming');
      if (res.bio) {
        setBio(res.bio.slice(0, 150));
      }
    } catch (e) {
      console.error('Bio AI fix error:', e);
    } finally {
      setIsAiPolishing(false);
    }
  };

  const handleExportData = async () => {
    if (!currentUser) return;
    const res = await api.exportData(currentUser.id);
    const blob = new Blob([JSON.stringify(res.exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zeye-data-export-${currentUser.username}.json`;
    a.click();
    alert('GDPR / DPDP data archive exported successfully!');
  };

  const handleDeleteAccount = async () => {
    if (!currentUser) return;
    if (confirm('Are you sure you want to schedule your Z-eye account for permanent deletion? This action honors GDPR/DPDP 30-day notice.')) {
      await api.deleteAccount(currentUser.id);
      alert('Account scheduled for deletion in 30 days. Signing out.');
      logout();
    }
  };

  if (!currentUser) return null;

  return (
    <div className="max-w-2xl mx-auto px-4 py-4 pb-24 text-[#F5F7FA]">
      {/* 1. Profile Header */}
      <div className="flex items-start justify-between mb-5">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-20 h-20 rounded-full p-[2px] bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF]">
              <img
                src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300'}
                alt={currentUser.username}
                className="w-full h-full rounded-full object-cover bg-black"
              />
            </div>
            {currentUser.isVerified && (
              <span className="absolute bottom-0 right-0 bg-black rounded-full p-0.5">
                <CheckCircle2 className="w-5 h-5 text-[#00E5FF] fill-[#00E5FF]/20" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-extrabold text-lg text-white">
                {currentUser.displayName || currentUser.username}
              </h2>
              {currentUser.pronouns && (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#14171C] text-[#9AA4AF] border border-[#222730]">
                  {currentUser.pronouns}
                </span>
              )}
            </div>
            <p className="text-xs text-[#9AA4AF]">@{currentUser.username}</p>

            <div className="flex items-center space-x-4 mt-2.5 text-xs">
              <div>
                <span className="font-extrabold text-white mr-1">
                  {profileData?.stats.postsCount || profileData?.posts.length || 0}
                </span>
                <span className="text-[#9AA4AF]">posts</span>
              </div>
              <div>
                <span className="font-extrabold text-white mr-1">
                  {profileData?.stats.followersCount || 128}
                </span>
                <span className="text-[#9AA4AF]">followers</span>
              </div>
              <div>
                <span className="font-extrabold text-white mr-1">
                  {profileData?.stats.followingCount || 94}
                </span>
                <span className="text-[#9AA4AF]">following</span>
              </div>
            </div>
          </div>
        </div>

        {/* Settings button */}
        <button
          onClick={() => setIsPrivacyModalOpen(true)}
          className="w-10 h-10 rounded-xl bg-[#0B0D10] hover:bg-[#14171C] border border-[#222730] flex items-center justify-center text-[#9AA4AF] hover:text-white transition-colors"
          title="Account Settings & Privacy"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* 2. Bio & Links (150-char constraint) */}
      <div className="bg-[#0B0D10] border border-[#14171C] rounded-2xl p-4 mb-4">
        <p className="text-xs leading-relaxed text-[#F5F7FA] whitespace-pre-line">
          {currentUser.bio || 'Visual creator on Z-eye | High-contrast Photos & Short Videos.'}
        </p>

        {currentUser.links && currentUser.links.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {currentUser.links.map((link, idx) => (
              <a
                key={idx}
                href={link.startsWith('http') ? link : `https://${link}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-[#14171C] hover:bg-[#222730] border border-[#222730] text-[11px] text-[#00E5FF] transition-colors"
              >
                <LinkIcon className="w-3 h-3" />
                <span className="truncate max-w-[150px]">{link.replace(/^https?:\/\//, '')}</span>
              </a>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#14171C]">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl bg-[#14171C] hover:bg-[#222730] text-xs font-semibold text-white transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Profile</span>
          </button>
          <button
            onClick={onOpenDeviceManager}
            className="flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl bg-[#00E5FF]/10 hover:bg-[#00E5FF]/20 border border-[#00E5FF]/30 text-xs font-semibold text-[#00E5FF] transition-colors"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Active Sessions</span>
          </button>
        </div>
      </div>

      {/* Switch Demo Accounts Quick Selector */}
      <div className="mb-5 flex items-center justify-between p-3 rounded-xl bg-[#0B0D10] border border-[#14171C]">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-4 h-4 text-[#7C4DFF]" />
          <span className="text-xs text-[#9AA4AF]">Switch Persona / Test Lock:</span>
        </div>
        <div className="flex space-x-1.5">
          {[
            { id: 'u-apex', name: 'Kaelen' },
            { id: 'u-cyber', name: 'Maya' },
            { id: 'u-pixel', name: 'Taro' },
          ].map((u) => (
            <button
              key={u.id}
              onClick={() => loginDemo(u.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                currentUser.id === u.id
                  ? 'bg-[#00E5FF] text-black font-bold'
                  : 'bg-[#14171C] text-[#9AA4AF] hover:text-white'
              }`}
            >
              {u.name}
            </button>
          ))}
        </div>
      </div>

      {/* 3. 3x3 Iconic Square Grid Layout (Feature 5) */}
      <div>
        <div className="flex items-center space-x-2 mb-3 pb-2 border-b border-[#14171C]">
          <Grid className="w-4 h-4 text-[#00E5FF]" />
          <span className="text-xs font-bold uppercase tracking-wider text-white">Posts Grid</span>
        </div>

        {profileData?.posts && profileData.posts.length > 0 ? (
          <div className="grid grid-cols-3 gap-1.5">
            {profileData.posts.map((post) => {
              const cover = post.media?.[0]?.url || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400';
              const isVideo = post.postType === 'video' || post.media?.[0]?.type === 'video';
              return (
                <div
                  key={post.id}
                  onClick={() => onPostSelect(post)}
                  className="relative aspect-square bg-[#0B0D10] overflow-hidden rounded-lg cursor-pointer group border border-[#14171C]"
                >
                  {isVideo ? (
                    <video
                      src={cover}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      muted
                      playsInline
                    />
                  ) : (
                    <img
                      src={cover}
                      alt={post.caption}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                  )}
                  {isVideo ? (
                    <span className="absolute top-1.5 right-1.5 bg-black/80 px-1.5 py-0.5 rounded text-[10px] font-mono text-[#00E5FF] flex items-center space-x-0.5">
                      <span>🎬</span>
                    </span>
                  ) : post.media?.length > 1 ? (
                    <span className="absolute top-1.5 right-1.5 bg-black/80 px-1.5 py-0.5 rounded text-[10px] font-mono text-white">
                      +{post.media.length}
                    </span>
                  ) : null}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center space-x-3 text-white transition-opacity font-bold text-xs">
                    <span>❤️ {post.likesCount}</span>
                    <span>💬 {post.commentsCount}</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12 text-[#9AA4AF] text-xs">
            No posts published yet. Tap the + icon to post your first photo or short video!
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0B0D10] border border-[#222730] rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#14171C]">
              <h3 className="font-bold text-sm text-white">Edit Profile</h3>
              <button onClick={() => setIsEditModalOpen(false)} className="text-[#9AA4AF] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3 text-xs">
              <div>
                <label className="text-[#9AA4AF] mb-1 block">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-[#14171C] border border-[#222730] rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[#9AA4AF]">Bio ({bio.length}/150)</label>
                  <button
                    type="button"
                    onClick={handleAiFixBio}
                    disabled={isAiPolishing}
                    className="text-[#00E5FF] hover:text-white flex items-center space-x-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{isAiPolishing ? 'Fixing...' : 'AI Bio Polish'}</span>
                  </button>
                </div>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value.slice(0, 150))}
                  className="w-full bg-[#14171C] border border-[#222730] rounded-xl p-3 text-white resize-none"
                />
              </div>

              <div>
                <label className="text-[#9AA4AF] mb-1 block">Pronouns</label>
                <input
                  type="text"
                  value={pronouns}
                  onChange={(e) => setPronouns(e.target.value)}
                  placeholder="e.g. they/them, he/him, she/her"
                  className="w-full bg-[#14171C] border border-[#222730] rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#9AA4AF] mb-1 block">External Links (comma separated)</label>
                <input
                  type="text"
                  value={linkInput}
                  onChange={(e) => setLinkInput(e.target.value)}
                  placeholder="twitch.tv/username, discord.gg/server"
                  className="w-full bg-[#14171C] border border-[#222730] rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-[#00E5FF] hover:bg-[#00E5FF]/90 text-black font-bold text-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Account Settings & Privacy Modal */}
      {isPrivacyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0B0D10] border border-[#222730] rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#14171C]">
              <h3 className="font-bold text-sm text-white">Privacy & Account Safety</h3>
              <button onClick={() => setIsPrivacyModalOpen(false)} className="text-[#9AA4AF] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Private account toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#14171C] border border-[#222730]">
                <div className="flex items-center space-x-2.5">
                  <Lock className="w-4 h-4 text-[#00E5FF]" />
                  <div>
                    <p className="font-semibold text-white">Private Account</p>
                    <p className="text-[10px] text-[#9AA4AF]">Only approved followers see posts</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPrivate(!isPrivate)}
                  className={`w-11 h-6 rounded-full p-1 transition-colors ${
                    isPrivate ? 'bg-[#00E5FF]' : 'bg-[#222730]'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-black transition-transform ${
                      isPrivate ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* GDPR Export */}
              <button
                onClick={handleExportData}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-[#14171C] hover:bg-[#222730] border border-[#222730] text-left transition-colors"
              >
                <div className="flex items-center space-x-2.5">
                  <Download className="w-4 h-4 text-[#7C4DFF]" />
                  <div>
                    <p className="font-semibold text-white">Download Information (GDPR)</p>
                    <p className="text-[10px] text-[#9AA4AF]">Export JSON of posts, sessions & profile</p>
                  </div>
                </div>
              </button>

              {/* Delete Account */}
              <button
                onClick={handleDeleteAccount}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/40 text-left transition-colors text-rose-400"
              >
                <div className="flex items-center space-x-2.5">
                  <Trash2 className="w-4 h-4" />
                  <div>
                    <p className="font-semibold">Delete Account (30-day notice)</p>
                    <p className="text-[10px] text-rose-400/70">Wipe all media, chats and database logs</p>
                  </div>
                </div>
              </button>

              {/* Log Out */}
              <button
                onClick={() => {
                  logout();
                  setIsPrivacyModalOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#14171C] hover:bg-[#222730] text-[#9AA4AF] hover:text-white font-medium flex items-center justify-center space-x-1.5 transition-colors mt-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
