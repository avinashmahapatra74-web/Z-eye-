import React from 'react';
import { PlatformMode } from '../types';
import { Minus, Square, X, Monitor, Smartphone, Laptop, Sparkles } from 'lucide-react';

interface DesktopWindowBarProps {
  platformMode: PlatformMode;
  onSelectPlatform: (mode: PlatformMode) => void;
  onSwitchToMobile: () => void;
}

export const DesktopWindowBar: React.FC<DesktopWindowBarProps> = ({
  platformMode,
  onSelectPlatform,
  onSwitchToMobile,
}) => {
  const isMac = platformMode === 'mac';

  return (
    <div
      className={`w-full h-10 px-4 flex items-center justify-between select-none text-xs border-b ${
        isMac
          ? 'bg-[#11141B]/90 backdrop-blur-xl border-white/10 text-[#9AA4AF]'
          : 'bg-[#0B0D10] border-[#1C2028] text-[#9AA4AF]'
      }`}
    >
      {/* Left section: macOS traffic lights or Windows App Icon */}
      <div className="flex items-center space-x-3">
        {isMac ? (
          <div className="flex items-center space-x-2">
            <button
              onClick={onSwitchToMobile}
              className="w-3 h-3 rounded-full bg-[#FF5F56] hover:opacity-80 border border-[#E0443E] transition-opacity"
              title="Close / Switch to Mobile"
            />
            <button
              className="w-3 h-3 rounded-full bg-[#FFBD2E] hover:opacity-80 border border-[#DEA123] transition-opacity"
              title="Minimize"
            />
            <button
              className="w-3 h-3 rounded-full bg-[#27C93F] hover:opacity-80 border border-[#1AAB29] transition-opacity"
              title="Zoom / Fullscreen"
            />
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1px] flex items-center justify-center">
              <span className="font-extrabold text-[10px] text-black">Z</span>
            </div>
            <span className="font-semibold text-white text-[11px] tracking-wide font-['Plus_Jakarta_Sans']">
              Z-eye Desktop
            </span>
          </div>
        )}

        {/* System Title */}
        <span className="text-[11px] font-mono text-[#9AA4AF] hidden md:inline">
          {isMac ? 'macOS Sonoma — Apple Silicon (120Hz ProMotion)' : 'Windows 11 Fluent Edition — AMOLED 4K Engine'}
        </span>
      </div>

      {/* Center: Quick Switch to Mobile CTA for desktop viewers */}
      <div className="flex items-center space-x-2">
        <button
          onClick={onSwitchToMobile}
          className="flex items-center space-x-1.5 px-3 py-1 rounded-md bg-[#14171C] hover:bg-[#222730] border border-[#222730] text-[#00E5FF] text-[11px] font-semibold transition-all hover:scale-105 active:scale-95"
          title="Switch from Desktop back to Mobile phone view"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Switch to Phone (Android / iOS)</span>
        </button>
      </div>

      {/* Right: Windows Controls or macOS system indicators */}
      <div className="flex items-center space-x-2">
        {isMac ? (
          <div className="flex items-center space-x-2 text-[11px] font-mono text-[#9AA4AF]">
            <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white">Metal Pro</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-[#9AA4AF]">
            <button
              onClick={onSwitchToMobile}
              className="w-7 h-7 flex items-center justify-center hover:bg-[#1C2028] hover:text-white rounded transition-colors"
              title="Minimize to Mobile"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button
              className="w-7 h-7 flex items-center justify-center hover:bg-[#1C2028] hover:text-white rounded transition-colors"
              title="Maximize"
            >
              <Square className="w-3 h-3" />
            </button>
            <button
              onClick={onSwitchToMobile}
              className="w-7 h-7 flex items-center justify-center hover:bg-rose-600 hover:text-white rounded transition-colors"
              title="Close Desktop View"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
