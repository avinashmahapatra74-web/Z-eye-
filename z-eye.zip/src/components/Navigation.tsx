import React from 'react';
import { Home, PlusSquare, User, Sparkles, Compass } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type NavTab = 'feed' | 'create' | 'explore' | 'ai' | 'profile';

interface NavigationProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentTab, onSelectTab }) => {
  const { currentUser } = useAuth();

  const navItems = [
    { id: 'feed', label: 'Feed', icon: Home },
    { id: 'explore', label: 'Explore', icon: Compass },
    { id: 'create', label: 'Create', icon: PlusSquare, isAccent: true },
    { id: 'ai', label: 'Big Fix AI', icon: Sparkles },
    { id: 'profile', label: 'Profile', icon: User, isAvatar: true },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-black/95 backdrop-blur-md border-t border-[#14171C]">
      <div className="max-w-2xl mx-auto px-4 h-16 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;

          if (item.isAvatar && currentUser?.avatarUrl) {
            return (
              <button
                key={item.id}
                id={`nav-${item.id}-btn`}
                onClick={() => onSelectTab(item.id as NavTab)}
                className="min-w-[48px] min-h-[48px] flex flex-col items-center justify-center p-2 rounded-xl transition-all"
                aria-label="Profile navigation"
              >
                <div
                  className={`w-7 h-7 rounded-full p-[1.5px] transition-all ${
                    isActive ? 'bg-[#00E5FF] scale-105 ring-2 ring-[#00E5FF]/20' : 'bg-transparent'
                  }`}
                >
                  <img
                    src={currentUser.avatarUrl}
                    alt={currentUser.username}
                    className="w-full h-full rounded-full object-cover bg-[#14171C]"
                  />
                </div>
                <span
                  className={`text-[10px] mt-0.5 font-medium ${
                    isActive ? 'text-[#00E5FF]' : 'text-[#9AA4AF]'
                  }`}
                >
                  Profile
                </span>
              </button>
            );
          }

          if (item.isAccent) {
            return (
              <button
                key={item.id}
                id={`nav-${item.id}-btn`}
                onClick={() => onSelectTab(item.id as NavTab)}
                className="min-w-[48px] min-h-[48px] flex flex-col items-center justify-center p-1"
                aria-label="Create new post"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20 hover:scale-105 active:scale-95 transition-transform">
                  <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                    <PlusSquare className="w-5 h-5 text-[#00E5FF]" />
                  </div>
                </div>
                <span className="text-[10px] mt-0.5 text-[#00E5FF] font-medium">Post</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              id={`nav-${item.id}-btn`}
              onClick={() => onSelectTab(item.id as NavTab)}
              className="min-w-[48px] min-h-[48px] flex flex-col items-center justify-center p-2 rounded-xl transition-all"
              aria-label={item.label}
            >
              <Icon
                className={`w-6 h-6 transition-all ${
                  isActive ? 'text-[#00E5FF] scale-110' : 'text-[#9AA4AF] hover:text-white'
                }`}
              />
              <span
                className={`text-[10px] mt-0.5 font-medium ${
                  isActive ? 'text-[#00E5FF]' : 'text-[#9AA4AF]'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
