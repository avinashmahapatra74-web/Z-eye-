import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSync } from '../context/SyncContext';
import { Shield, Smartphone, Sparkles, Image, Film, Monitor, Zap } from 'lucide-react';
import { PlatformMode } from '../types';

interface HeaderProps {
  selectedTag: string;
  onSelectTag: (tag: string) => void;
  onOpenDeviceManager: () => void;
  onOpenBigFixAI: () => void;
  onOpenOptimizer?: () => void;
  platformMode?: PlatformMode;
  onSwitchToDesktop?: () => void;
  onSwitchToMobile?: () => void;
}

const CATEGORIES = [
  { id: 'All', label: 'All Media', icon: null },
  { id: 'Photos', label: 'Photos', icon: Image },
  { id: 'Short Videos', label: 'Short Videos', icon: Film },
];

export const Header: React.FC<HeaderProps> = ({
  selectedTag,
  onSelectTag,
  onOpenDeviceManager,
  onOpenBigFixAI,
  onOpenOptimizer,
  platformMode = 'android',
  onSwitchToDesktop,
  onSwitchToMobile,
}) => {
  const { currentUser, deviceModel } = useAuth();
  const { isConnected, latencyMs } = useSync();

  const isMobile = platformMode === 'android' || platformMode === 'ios';

  return (
    <header className="sticky top-0 z-40 bg-black/95 backdrop-blur-md border-b border-[#14171C]">
      {/* Top Brand Bar */}
      <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[2px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/10">
            <div className="w-full h-full bg-black rounded-[6px] flex items-center justify-center">
              <span className="font-extrabold text-sm tracking-wider text-[#00E5FF]">Z</span>
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold text-lg tracking-tight text-white font-['Plus_Jakarta_Sans']">
                Z<span className="text-[#00E5FF]">-</span>eye
              </span>
              <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#14171C] text-[#9AA4AF] border border-[#222730]">
                {platformMode === 'ios' ? 'iOS' : platformMode === 'android' ? 'Android' : platformMode === 'mac' ? 'macOS' : 'Desktop'}
              </span>
            </div>
          </div>
        </div>

        {/* Center / Right Status & Controls */}
        <div className="flex items-center space-x-1.5 sm:space-x-2">
          {/* USER REQUEST: Mobile switch to desktop button */}
          {isMobile && onSwitchToDesktop && (
            <button
              id="mobile-header-switch-to-desktop-btn"
              onClick={onSwitchToDesktop}
              className="flex items-center space-x-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-gradient-to-r from-[#00E5FF]/20 to-[#7C4DFF]/20 hover:from-[#00E5FF]/30 hover:to-[#7C4DFF]/30 border border-[#00E5FF]/60 text-[#00E5FF] text-xs font-bold transition-all shadow-sm shadow-[#00E5FF]/20 active:scale-95"
              title="Switch to Desktop / Mac Mode"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="text-[11px] font-bold">Desktop</span>
            </button>
          )}

          {!isMobile && onSwitchToMobile && (
            <button
              id="desktop-header-switch-to-mobile-btn"
              onClick={onSwitchToMobile}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-[#14171C] hover:bg-[#222730] border border-[#222730] text-[#9AA4AF] hover:text-white text-xs font-medium transition-all active:scale-95"
              title="Switch to Mobile Phone View"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#00E5FF]" />
              <span className="text-[11px] font-medium hidden sm:inline">Phone Mode</span>
            </button>
          )}

          {/* USER REQUEST: Sentinel AI Bot & Device Optimization */}
          {onOpenOptimizer && (
            <button
              id="header-device-optimizer-btn"
              onClick={onOpenOptimizer}
              className="flex items-center space-x-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition-all shadow-sm shadow-emerald-500/10 active:scale-95"
              title="Sentinel AI Bot: Hardware Auto-Tuning & Zero-MB Data Saver"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
              <span className="text-[11px] hidden xs:inline">Zero-MB AI</span>
            </button>
          )}

          {/* Real-time DB Sync Badge */}
          <div
            className="hidden sm:flex items-center space-x-1.5 px-2 py-1 rounded-full bg-[#0B0D10] border border-[#14171C] text-[11px] text-[#9AA4AF]"
            title={`Real-time DB synchronization: ${isConnected ? 'Connected' : 'Reconnecting'}`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`}
            />
            <span className="font-mono text-[10px] text-white">
              {isConnected ? `${latencyMs}ms` : 'Syncing'}
            </span>
          </div>

          {/* Single-Device Lock indicator */}
          <button
            id="device-lock-badge-btn"
            onClick={onOpenDeviceManager}
            className="flex items-center space-x-1 px-2 py-1.5 rounded-lg bg-[#0B0D10] hover:bg-[#14171C] border border-[#222730] text-xs text-[#F5F7FA] transition-colors"
            title="Single-Device Lock: 1 active session enforced"
          >
            <Shield className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span className="font-mono text-[10px] hidden md:inline truncate max-w-[65px]">
              {deviceModel.split(' ')[0]}
            </span>
          </button>

          {/* Big Fix AI Dashboard Toggle */}
          <button
            id="big-fix-ai-btn"
            onClick={onOpenBigFixAI}
            className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-[#7C4DFF]/20 to-[#00E5FF]/20 hover:from-[#7C4DFF]/30 hover:to-[#00E5FF]/30 border border-[#7C4DFF]/50 text-xs font-semibold text-white transition-all shadow-sm shadow-[#00E5FF]/10"
            title="Open Big Fix AI & SRE Telemetry"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span className="hidden sm:inline">AI</span>
          </button>
        </div>
      </div>


      {/* Only Photos & Short Videos Filter Ribbon (Other categories removed) */}
      <div className="max-w-2xl mx-auto px-4 pb-2.5 flex items-center space-x-2">
        {CATEGORIES.map((cat) => {
          const isActive = selectedTag === cat.id;
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectTag(cat.id)}
              className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                isActive
                  ? 'bg-[#00E5FF] text-black font-semibold shadow-sm shadow-[#00E5FF]/30'
                  : 'bg-[#0B0D10] hover:bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#14171C]'
              }`}
            >
              {Icon && <Icon className="w-3.5 h-3.5" />}
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
