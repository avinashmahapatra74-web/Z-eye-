import React, { useState, useEffect } from 'react';
import { Wifi, Sparkles, Activity, Monitor } from 'lucide-react';

interface IosTopBarProps {
  onDesktopSwitch?: () => void;
}

export const IosTopBar: React.FC<IosTopBarProps> = ({ onDesktopSwitch }) => {
  const [islandExpanded, setIslandExpanded] = useState(false);
  const [timeStr, setTimeStr] = useState('9:41');

  useEffect(() => {
    const update = () => {
      const d = new Date();
      setTimeStr(d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-black px-5 pt-2 pb-1.5 flex items-center justify-between text-[12px] font-sans font-semibold text-white select-none border-b border-[#14171C]/50 z-50 relative">
      {/* iOS Left Clock */}
      <span className="tracking-tight font-medium text-[13px]">{timeStr}</span>

      {/* iOS Dynamic Island */}
      <div
        onClick={() => setIslandExpanded(!islandExpanded)}
        className={`transition-all duration-300 ease-out bg-black border border-white/15 rounded-full flex items-center justify-between px-3 cursor-pointer shadow-lg shadow-black/80 ${
          islandExpanded ? 'w-44 h-8 bg-[#0D1017]' : 'w-28 h-6'
        }`}
        title="Tap to toggle Dynamic Island info"
      >
        <div className="flex items-center space-x-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#7C4DFF] animate-pulse" />
          <span className="text-[10px] text-[#00E5FF] font-mono font-medium">Z-eye</span>
        </div>
        <div className="flex items-center space-x-1">
          {islandExpanded ? (
            <span className="text-[9px] text-emerald-400 font-mono">120Hz PRO</span>
          ) : (
            <Activity className="w-3 h-3 text-[#00E5FF] animate-pulse" />
          )}
          <div className="w-2.5 h-2.5 rounded-full bg-[#14171C] border border-white/20" />
        </div>
      </div>

      {/* iOS Right: Signal bars, 5G, Battery Pill */}
      <div className="flex items-center space-x-1.5 text-[#F5F7FA]">
        {/* Cellular 4 bars */}
        <div className="flex items-end space-x-[1.5px] h-3">
          <span className="w-[2.5px] h-1 bg-white rounded-xs" />
          <span className="w-[2.5px] h-1.5 bg-white rounded-xs" />
          <span className="w-[2.5px] h-2 bg-white rounded-xs" />
          <span className="w-[2.5px] h-3 bg-white rounded-xs" />
        </div>
        <span className="text-[10px] font-mono font-bold ml-0.5">5G</span>
        <Wifi className="w-3 h-3 text-white ml-0.5" />
        {/* iOS Battery icon */}
        <div className="w-5 h-2.5 rounded-[3px] border border-white/70 p-[1px] flex items-center">
          <div className="w-3/4 h-full bg-white rounded-[1.5px]" />
        </div>
        {onDesktopSwitch && (
          <button
            onClick={onDesktopSwitch}
            className="ml-1 px-1.5 py-0.5 rounded-md bg-[#181C24] hover:bg-[#00E5FF] text-[#00E5FF] hover:text-black flex items-center space-x-1 font-bold text-[9px] border border-white/10 transition-colors"
            title="Switch to Desktop Mode"
          >
            <Monitor className="w-2.5 h-2.5" />
            <span>PC</span>
          </button>
        )}
      </div>
    </div>
  );
};

export const IosHomeIndicator: React.FC = () => {
  return (
    <div className="w-full h-6 bg-black flex items-center justify-center select-none z-50">
      <div className="w-36 h-1 bg-white/40 rounded-full hover:bg-white/70 transition-colors" />
    </div>
  );
};
