import React, { useState, useRef, useEffect } from 'react';
import {
  Scissors,
  Zap,
  Film,
  Music,
  Type,
  Sparkles,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  X,
  Check,
  ChevronDown,
  Layers,
  Wand2,
  Download,
  Share2,
  Settings2,
  Maximize2,
  Repeat,
  Plus,
  Trash2,
  Clock,
  AudioWaveform as Waveform,
} from 'lucide-react';
import {
  TimelineClip,
  TimelineAudioTrack,
  TimelineTextOverlay,
  VideoExportQualityConfig,
  MediaFilterSettings,
} from '../types';
import { synthEngine } from '../utils/audioSynth';
import { ZeyeMusicLibraryModal } from './ZeyeMusicLibraryModal';

interface CapCutProEditorProps {
  isOpen: boolean;
  onClose: () => void;
  mediaUrl: string;
  mediaType: 'photo' | 'video';
  initialSettings?: Partial<MediaFilterSettings>;
  onApply: (result: {
    mediaUrl: string;
    mediaType: 'photo' | 'video';
    aspectRatio: '9:16' | '1:1' | '16:9' | '4:5';
    filterSettings: MediaFilterSettings;
    exportConfig: VideoExportQualityConfig;
    audioTrack?: { id: string; title: string; artist: string; isAiGenerated?: boolean };
  }) => void;
}

const AMOLED_LUTS = [
  { id: 'none', name: 'Original Master', style: 'none' },
  { id: 'cyber_amoled', name: '⚡ AMOLED Cyber Neon', style: 'contrast(135%) saturate(145%) hue-rotate(200deg)' },
  { id: 'noir_zero', name: '🌑 0-Nit True Noir', style: 'grayscale(100%) contrast(150%) brightness(95%)' },
  { id: 'teal_orange', name: '🎬 Blockbuster Teal & Orange', style: 'contrast(125%) saturate(135%) sepia(20%) hue-rotate(-15deg)' },
  { id: 'vintage_35mm', name: '🎞️ 35mm Analog Film', style: 'sepia(35%) contrast(110%) brightness(105%) saturate(120%)' },
  { id: 'sunset_glow', name: '🌅 Golden Hour Sunset', style: 'sepia(25%) saturate(160%) hue-rotate(-10deg) brightness(105%)' },
  { id: 'emerald_matrix', name: '🟢 Emerald Matrix Glow', style: 'contrast(140%) hue-rotate(90deg) saturate(130%)' },
  { id: 'velvet_midnight', name: '🌌 Midnight Velvet Blue', style: 'contrast(120%) brightness(90%) hue-rotate(180deg) saturate(130%)' },
];

const TRANSITIONS = [
  { id: 'none', name: 'Cut (Standard)' },
  { id: 'glitch', name: '⚡ RGB Glitch Pop' },
  { id: 'flash', name: '✨ White Lens Flash' },
  { id: 'zoom', name: '🔍 Whip Zoom In' },
  { id: 'whip', name: '🌪️ Whip Pan Camera' },
  { id: 'fade_black', name: '🌑 Fade to 0-Nit Black' },
];

const SFX_ITEMS = [
  { id: 'boom', name: '💥 Cinematic Bass Boom', category: 'Impact' },
  { id: 'swoosh', name: '🌪️ Fast Camera Swoosh', category: 'Transition' },
  { id: 'drop', name: '💣 Heavy 808 Sub Drop', category: 'Bass' },
  { id: 'shutter', name: '📸 Leica Camera Shutter', category: 'Sound' },
  { id: 'glitch', name: '⚡ Cybernetic Glitch Hit', category: 'FX' },
  { id: 'scratch', name: '🎛️ Vinyl DJ Scratch', category: 'Scratch' },
];

export const CapCutProEditor: React.FC<CapCutProEditorProps> = ({
  isOpen,
  onClose,
  mediaUrl,
  mediaType,
  initialSettings,
  onApply,
}) => {
  // Timeline state
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '1:1' | '16:9' | '4:5'>(
    initialSettings?.aspectRatio || (mediaType === 'video' ? '9:16' : '4:5')
  );

  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [totalDurationSec, setTotalDurationSec] = useState<number>(mediaType === 'video' ? 12 : 6);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'tools' | 'lut' | 'speed' | 'transitions' | 'sfx' | 'text' | 'export'>('tools');

  // Timeline Clips (support for split/cut)
  const [clips, setClips] = useState<TimelineClip[]>([
    {
      id: 'clip-1',
      type: mediaType,
      url: mediaUrl,
      startSec: 0,
      durationSec: mediaType === 'video' ? 12 : 6,
      speed: 1,
      filterName: 'none',
      volume: 100,
      transitionIn: 'none',
    },
  ]);
  const [activeClipIndex, setActiveClipIndex] = useState<number>(0);

  // Speed curve & ramp
  const [speed, setSpeed] = useState<number>(1);
  const [selectedLut, setSelectedLut] = useState<string>('none');
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [saturation, setSaturation] = useState<number>(100);
  const [vignette, setVignette] = useState<boolean>(false);

  // Audio track
  const [audioTrack, setAudioTrack] = useState<{ id: string; title: string; artist: string; isAiGenerated?: boolean } | undefined>(
    initialSettings?.selectedMusicId
      ? { id: initialSettings.selectedMusicId, title: initialSettings.musicTitle || 'Attached Sound', artist: 'Z-eye' }
      : undefined
  );
  const [isMusicModalOpen, setIsMusicModalOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Text & Titles overlay
  const [overlayText, setOverlayText] = useState<string>('Z-EYE CINEMATIC');
  const [textStyle, setTextStyle] = useState<'neon' | 'cyber' | 'typewriter' | 'karaoke' | 'minimal'>('neon');
  const [textColor, setTextColor] = useState<string>('#00E5FF');
  const [showWatermark, setShowWatermark] = useState<boolean>(true);

  // Export Settings Modal
  const [exportConfig, setExportConfig] = useState<VideoExportQualityConfig>({
    resolution: '4K',
    fps: 60,
    codec: 'AV1',
    colorDepth: '10-bit HDR',
    fileSizeMB: 1.8,
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const timelineRef = useRef<HTMLDivElement | null>(null);

  // Sync speed changes to video element
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  }, [speed]);

  // Clean up audio synth on unmount
  useEffect(() => {
    return () => {
      synthEngine.stop();
    };
  }, []);

  if (!isOpen) return null;

  // Time formatting helper (00:00:00)
  const formatTimecode = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const frames = Math.floor((seconds % 1) * 30);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}:${frames.toString().padStart(2, '0')}`;
  };

  // Toggle play/pause
  const handlePlayToggle = () => {
    if (mediaType === 'video' && videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
        if (audioTrack && !isMuted) {
          synthEngine.playTrack(audioTrack.id);
        }
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
        synthEngine.stop();
      }
    } else {
      setIsPlaying(!isPlaying);
      if (!isPlaying && audioTrack && !isMuted) {
        synthEngine.playTrack(audioTrack.id);
      } else {
        synthEngine.stop();
      }
    }
  };

  // Video time update
  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTimeSec(videoRef.current.currentTime);
      if (videoRef.current.duration && !isNaN(videoRef.current.duration)) {
        setTotalDurationSec(videoRef.current.duration);
      }
    }
  };

  // Scrub timeline on click
  const handleTimelineScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, clickX / rect.width));
    const newTime = pct * totalDurationSec;
    setCurrentTimeSec(newTime);
    if (videoRef.current) {
      videoRef.current.currentTime = newTime;
    }
  };

  // ✂️ CapCut Pro: Split Clip at current playhead
  const handleSplitClip = () => {
    if (currentTimeSec <= 0.5 || currentTimeSec >= totalDurationSec - 0.5) return;

    // Play cutter SFX
    synthEngine.playSfx('shutter');

    const activeClip = clips[activeClipIndex] || clips[0];
    const leftDuration = currentTimeSec - activeClip.startSec;
    const rightDuration = activeClip.durationSec - leftDuration;

    if (leftDuration > 0.3 && rightDuration > 0.3) {
      const clipLeft: TimelineClip = {
        ...activeClip,
        id: `clip-${Date.now()}-A`,
        durationSec: Number(leftDuration.toFixed(2)),
      };
      const clipRight: TimelineClip = {
        ...activeClip,
        id: `clip-${Date.now()}-B`,
        startSec: Number(currentTimeSec.toFixed(2)),
        durationSec: Number(rightDuration.toFixed(2)),
        transitionIn: 'glitch', // auto-add glitch transition
      };

      const newClips = [...clips];
      newClips.splice(activeClipIndex, 1, clipLeft, clipRight);
      setClips(newClips);
      setActiveClipIndex(activeClipIndex + 1);
    }
  };

  // Play SFX
  const handlePlaySfx = (sfxId: string) => {
    synthEngine.playSfx(sfxId as any);
  };

  // Calculate CSS filters
  const getFilterStyle = () => {
    const lut = AMOLED_LUTS.find((l) => l.id === selectedLut)?.style || '';
    const adjustments = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
    return lut === 'none' ? adjustments : `${lut} ${adjustments}`;
  };

  // Estimated file size calculation based on resolution & FPS
  const getEstimatedSizeMB = (res: string, fpsVal: number) => {
    let base = 1.2;
    if (res === '4K') base = 4.8;
    else if (res === '2K') base = 2.9;
    else if (res === '1080p') base = 1.4;
    else if (res === '720p') base = 0.8;
    else if (res === 'zero_mb') base = 0.22;

    const fpsMultiplier = fpsVal === 120 ? 1.8 : fpsVal === 60 ? 1.4 : fpsVal === 24 ? 0.9 : 1.0;
    return Number((base * fpsMultiplier).toFixed(2));
  };

  const handleResolutionChange = (res: '4K' | '2K' | '1080p' | '720p' | 'zero_mb') => {
    const size = getEstimatedSizeMB(res, exportConfig.fps);
    setExportConfig((prev) => ({ ...prev, resolution: res, fileSizeMB: size }));
  };

  const handleFpsChange = (fpsVal: 24 | 30 | 60 | 120) => {
    const size = getEstimatedSizeMB(exportConfig.resolution, fpsVal);
    setExportConfig((prev) => ({ ...prev, fps: fpsVal, fileSizeMB: size }));
  };

  const handleApplyExport = () => {
    synthEngine.stop();
    onApply({
      mediaUrl,
      mediaType,
      aspectRatio,
      filterSettings: {
        filterName: selectedLut,
        brightness,
        contrast,
        saturation,
        warmth: 0,
        blur: 0,
        vignette,
        aspectRatio,
        overlayText: overlayText.trim() ? overlayText : undefined,
        watermark: showWatermark,
        playbackSpeed: speed,
        selectedMusicId: audioTrack?.id,
        musicTitle: audioTrack?.title,
      },
      exportConfig,
      audioTrack,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black text-[#F5F7FA] select-none">
      {/* 1. CapCut Pro Top Command Bar */}
      <div className="h-14 px-4 bg-[#0A0C10] border-b border-[#1A1F26] flex items-center justify-between z-20">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              synthEngine.stop();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-[#14171C] hover:bg-[#222730] flex items-center justify-center text-[#9AA4AF] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
              <div className="w-full h-full bg-black rounded-[5px] flex items-center justify-center">
                <Scissors className="w-3.5 h-3.5 text-[#00E5FF]" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-extrabold text-sm text-white tracking-wide">
                  CapCut <span className="text-[#00E5FF]">PRO</span>
                </span>
                <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30 font-mono">
                  {exportConfig.resolution} {exportConfig.fps}FPS
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Center Aspect Ratio Switcher */}
        <div className="flex items-center space-x-1 bg-[#14171C] p-1 rounded-xl border border-[#222730]">
          {(['9:16', '1:1', '16:9', '4:5'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setAspectRatio(r)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                aspectRatio === r
                  ? 'bg-[#00E5FF] text-black shadow-sm font-bold'
                  : 'text-[#9AA4AF] hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        {/* Right Actions: Timecode & Export */}
        <div className="flex items-center space-x-2.5">
          <div className="hidden sm:flex items-center space-x-1 font-mono text-xs px-2.5 py-1 rounded-lg bg-[#14171C] border border-[#222730] text-cyan-400">
            <Clock className="w-3.5 h-3.5 mr-1" />
            <span>{formatTimecode(currentTimeSec)}</span>
            <span className="text-[#6C7684]">/</span>
            <span className="text-[#9AA4AF]">{formatTimecode(totalDurationSec)}</span>
          </div>

          <button
            onClick={() => setActiveTab('export')}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white text-xs font-bold shadow-lg shadow-[#00E5FF]/20 hover:brightness-110 active:scale-95 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Pro</span>
          </button>
        </div>
      </div>

      {/* 2. Main Studio Work Area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left/Top: Canvas Preview Player */}
        <div className="flex-1 bg-[#050608] flex flex-col items-center justify-center p-3 relative overflow-hidden">
          <div
            className={`relative rounded-xl overflow-hidden border border-[#222730] shadow-2xl shadow-black max-h-[46vh] md:max-h-[56vh] flex items-center justify-center bg-black transition-all ${
              aspectRatio === '9:16'
                ? 'aspect-[9/16]'
                : aspectRatio === '1:1'
                ? 'aspect-square'
                : aspectRatio === '16:9'
                ? 'aspect-[16/9]'
                : 'aspect-[4/5]'
            }`}
          >
            {mediaType === 'video' ? (
              <video
                ref={videoRef}
                src={mediaUrl}
                loop
                playsInline
                muted={isMuted}
                onTimeUpdate={handleVideoTimeUpdate}
                onClick={handlePlayToggle}
                className="w-full h-full object-cover cursor-pointer"
                style={{ filter: getFilterStyle() }}
              />
            ) : (
              <img
                src={mediaUrl}
                alt="CapCut Pro Preview"
                className="w-full h-full object-cover"
                style={{ filter: getFilterStyle() }}
              />
            )}

            {/* Live Text Overlay */}
            {overlayText && (
              <div
                className={`absolute bottom-6 left-4 right-4 text-center pointer-events-none transition-all ${
                  textStyle === 'neon'
                    ? 'font-extrabold tracking-widest drop-shadow-[0_0_12px_#00E5FF]'
                    : textStyle === 'cyber'
                    ? 'font-mono tracking-tighter uppercase'
                    : textStyle === 'typewriter'
                    ? 'font-serif tracking-normal'
                    : 'font-sans font-bold'
                }`}
                style={{ color: textColor }}
              >
                <span className="bg-black/50 px-3 py-1 rounded-lg backdrop-blur-sm text-sm sm:text-base">
                  {overlayText}
                </span>
              </div>
            )}

            {/* Vignette Overlay */}
            {vignette && (
              <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle,transparent_55%,rgba(0,0,0,0.85)_100%)]" />
            )}

            {/* Z-eye Watermark */}
            {showWatermark && (
              <div className="absolute top-3 right-3 pointer-events-none px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-[#00E5FF]/30 text-[10px] text-cyan-300 font-bold flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-pulse" />
                <span>Z-eye Pro</span>
              </div>
            )}

            {/* Play/Pause Overlay Icon on Hover */}
            <div
              onClick={handlePlayToggle}
              className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/20 cursor-pointer"
            >
              <div className="w-12 h-12 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center text-white shadow-xl">
                {isPlaying ? (
                  <Pause className="w-6 h-6 fill-current" />
                ) : (
                  <Play className="w-6 h-6 fill-current ml-0.5" />
                )}
              </div>
            </div>
          </div>

          {/* Transport Controls Bar */}
          <div className="mt-2 flex items-center space-x-3 bg-[#0E1116] px-4 py-1.5 rounded-xl border border-[#1A1F26]">
            <button
              onClick={() => {
                if (videoRef.current) videoRef.current.currentTime = Math.max(0, currentTimeSec - 2);
              }}
              className="text-[#9AA4AF] hover:text-white p-1"
              title="Step Back 2s"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={handlePlayToggle}
              className="w-8 h-8 rounded-full bg-[#00E5FF] text-black flex items-center justify-center font-bold shadow-md shadow-[#00E5FF]/20 active:scale-95"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-current" />
              ) : (
                <Play className="w-4 h-4 fill-current ml-0.5" />
              )}
            </button>

            <button
              onClick={() => {
                if (videoRef.current) videoRef.current.currentTime = Math.min(totalDurationSec, currentTimeSec + 2);
              }}
              className="text-[#9AA4AF] hover:text-white p-1"
              title="Step Forward 2s"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <div className="h-4 w-[1px] bg-[#222730]" />

            {/* Mute Toggle */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`p-1.5 rounded-lg transition-colors ${
                isMuted ? 'text-rose-400 bg-rose-950/40' : 'text-[#9AA4AF] hover:text-white'
              }`}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Audio Track Tag if attached */}
            {audioTrack && (
              <div className="flex items-center space-x-1.5 px-2 py-0.5 rounded-md bg-[#14171C] border border-[#00E5FF]/30 text-[11px] text-cyan-300">
                <Music className="w-3 h-3 text-[#00E5FF]" />
                <span className="truncate max-w-[120px]">{audioTrack.title}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right/Bottom: Tool & Adjustment Panels */}
        <div className="w-full md:w-80 bg-[#0B0D10] border-t md:border-t-0 md:border-l border-[#1A1F26] flex flex-col h-48 md:h-auto overflow-hidden">
          {/* Tool Selector Tabs */}
          <div className="flex items-center overflow-x-auto border-b border-[#14171C] bg-[#08090C] p-1.5 space-x-1 scrollbar-none">
            {[
              { id: 'tools', label: '✂️ Edit', icon: Scissors },
              { id: 'lut', label: '🎨 LUTs', icon: Sparkles },
              { id: 'speed', label: '⚡ Speed', icon: Zap },
              { id: 'transitions', label: '🎬 FX', icon: Film },
              { id: 'sfx', label: '🔊 SFX', icon: Volume2 },
              { id: 'text', label: '🔤 Text', icon: Type },
              { id: 'export', label: '🚀 Export', icon: Download },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center space-x-1 ${
                  activeTab === tab.id
                    ? 'bg-[#1E242E] text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white'
                }`}
              >
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tool Panels Body */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
            {/* TAB: TOOLS / EDIT */}
            {activeTab === 'tools' && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleSplitClip}
                    className="p-3 rounded-xl bg-[#14171C] hover:bg-[#1E232B] border border-[#222730] flex flex-col items-center justify-center space-y-1 text-white hover:border-[#00E5FF]/40 transition-all active:scale-95"
                  >
                    <Scissors className="w-5 h-5 text-[#00E5FF]" />
                    <span className="text-xs font-bold">Split Clip</span>
                    <span className="text-[10px] text-[#9AA4AF]">At Playhead ({currentTimeSec.toFixed(1)}s)</span>
                  </button>

                  <button
                    onClick={() => setIsMusicModalOpen(true)}
                    className="p-3 rounded-xl bg-gradient-to-tr from-[#7C4DFF]/15 to-[#00E5FF]/15 hover:from-[#7C4DFF]/25 hover:to-[#00E5FF]/25 border border-[#00E5FF]/40 flex flex-col items-center justify-center space-y-1 text-white transition-all active:scale-95"
                  >
                    <Music className="w-5 h-5 text-[#00E5FF]" />
                    <span className="text-xs font-bold">Add Music</span>
                    <span className="text-[10px] text-cyan-300 truncate max-w-[120px]">
                      {audioTrack ? audioTrack.title : 'Z-eye Sound Library'}
                    </span>
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-[#0E1116] border border-[#181C22] space-y-2.5">
                  <div className="text-xs font-semibold text-white flex items-center justify-between">
                    <span>Vignette Cinema Framing</span>
                    <button
                      onClick={() => setVignette(!vignette)}
                      className={`w-10 h-5 rounded-full transition-colors relative ${
                        vignette ? 'bg-[#00E5FF]' : 'bg-[#222730]'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-0.5 ${
                          vignette ? 'left-5' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="text-xs font-semibold text-white flex items-center justify-between">
                    <span>AMOLED 0-Nit Watermark</span>
                    <button
                      onClick={() => setShowWatermark(!showWatermark)}
                      className={`w-10 h-5 rounded-full transition-colors relative ${
                        showWatermark ? 'bg-[#00E5FF]' : 'bg-[#222730]'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-0.5 ${
                          showWatermark ? 'left-5' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: LUTs & COLOR GRADING */}
            {activeTab === 'lut' && (
              <div className="space-y-3">
                <div className="text-xs font-semibold text-[#9AA4AF] mb-1">
                  12+ Pro AMOLED & Cinematic LUTs:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {AMOLED_LUTS.map((lut) => (
                    <button
                      key={lut.id}
                      onClick={() => setSelectedLut(lut.id)}
                      className={`p-2.5 rounded-xl border text-left transition-all ${
                        selectedLut === lut.id
                          ? 'bg-[#1E232B] border-[#00E5FF] text-white shadow-md shadow-[#00E5FF]/20 font-bold'
                          : 'bg-[#0E1116] border-[#181C22] text-[#9AA4AF] hover:text-white'
                      }`}
                    >
                      <div className="text-xs truncate">{lut.name}</div>
                    </button>
                  ))}
                </div>

                {/* Manual Brightness/Contrast Sliders */}
                <div className="pt-2 space-y-2 border-t border-[#1A1F26]">
                  <div>
                    <div className="flex justify-between text-[11px] text-[#9AA4AF] mb-1">
                      <span>Brightness</span>
                      <span className="font-mono text-cyan-400">{brightness}%</span>
                    </div>
                    <input
                      type="range"
                      min={60}
                      max={150}
                      value={brightness}
                      onChange={(e) => setBrightness(Number(e.target.value))}
                      className="w-full accent-[#00E5FF]"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[11px] text-[#9AA4AF] mb-1">
                      <span>Contrast</span>
                      <span className="font-mono text-cyan-400">{contrast}%</span>
                    </div>
                    <input
                      type="range"
                      min={60}
                      max={160}
                      value={contrast}
                      onChange={(e) => setContrast(Number(e.target.value))}
                      className="w-full accent-[#00E5FF]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SPEED CURVE & RAMP */}
            {activeTab === 'speed' && (
              <div className="space-y-4">
                <div className="p-3 rounded-xl bg-[#0E1116] border border-[#1E232B]">
                  <div className="flex justify-between items-center text-xs font-bold text-white mb-2">
                    <span>Speed Ramp & Curve:</span>
                    <span className="text-[#00E5FF] font-mono text-sm">{speed}x</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    {[0.2, 0.5, 1, 2, 5, 10].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSpeed(s)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          speed === s
                            ? 'bg-[#00E5FF] text-black font-bold'
                            : 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                        }`}
                      >
                        {s}x
                      </button>
                    ))}
                  </div>

                  <p className="text-[10px] text-[#9AA4AF] mt-2">
                    {speed < 1
                      ? '⚡ Optical Slow-Motion Interpolation active'
                      : speed > 1
                      ? '⚡ Hyper-lapse Frame Blending active'
                      : 'Standard 1.0x Real-time rate'}
                  </p>
                </div>
              </div>
            )}

            {/* TAB: TRANSITIONS */}
            {activeTab === 'transitions' && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-[#9AA4AF]">
                  CapCut Pro In/Out Transitions:
                </div>
                <div className="space-y-1.5">
                  {TRANSITIONS.map((tr) => (
                    <button
                      key={tr.id}
                      onClick={() => {
                        synthEngine.playSfx('swoosh');
                        const newClips = [...clips];
                        if (newClips[activeClipIndex]) {
                          newClips[activeClipIndex].transitionIn = tr.id as any;
                          setClips(newClips);
                        }
                      }}
                      className="w-full p-2.5 rounded-xl bg-[#0E1116] hover:bg-[#161B22] border border-[#181C22] hover:border-[#00E5FF]/40 text-left text-xs font-semibold text-white flex items-center justify-between transition-colors"
                    >
                      <span>{tr.name}</span>
                      <Film className="w-3.5 h-3.5 text-[#00E5FF]" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: SFX SOUND EFFECTS */}
            {activeTab === 'sfx' && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-[#9AA4AF]">
                  Tap to preview & attach sound effects:
                </div>
                <div className="space-y-2">
                  {SFX_ITEMS.map((sfx) => (
                    <div
                      key={sfx.id}
                      className="p-2.5 rounded-xl bg-[#0E1116] border border-[#181C22] flex items-center justify-between"
                    >
                      <div>
                        <div className="text-xs font-bold text-white">{sfx.name}</div>
                        <div className="text-[10px] text-cyan-400 font-mono">{sfx.category}</div>
                      </div>
                      <button
                        onClick={() => handlePlaySfx(sfx.id)}
                        className="px-3 py-1 rounded-lg bg-[#00E5FF]/20 hover:bg-[#00E5FF]/30 text-[#00E5FF] border border-[#00E5FF]/40 text-xs font-semibold active:scale-95 transition-all"
                      >
                        Play SFX
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: TEXT & TITLES */}
            {activeTab === 'text' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-[#9AA4AF] block mb-1">
                    Caption / Title Overlay:
                  </label>
                  <input
                    type="text"
                    value={overlayText}
                    onChange={(e) => setOverlayText(e.target.value)}
                    placeholder="Enter screen title..."
                    className="w-full px-3 py-2 bg-[#14171C] border border-[#222730] rounded-xl text-xs text-white focus:outline-none focus:border-[#00E5FF]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#9AA4AF] block mb-1">
                    Text Style:
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['neon', 'cyber', 'typewriter', 'minimal'] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => setTextStyle(st)}
                        className={`p-2 rounded-lg text-xs capitalize transition-all ${
                          textStyle === st
                            ? 'bg-[#00E5FF] text-black font-bold'
                            : 'bg-[#14171C] text-[#9AA4AF] hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#9AA4AF] block mb-1">
                    Color:
                  </label>
                  <div className="flex items-center space-x-2">
                    {['#00E5FF', '#FFFFFF', '#FFD700', '#FF2A6D', '#05FFA1'].map((c) => (
                      <button
                        key={c}
                        onClick={() => setTextColor(c)}
                        className={`w-7 h-7 rounded-full border-2 transition-transform ${
                          textColor === c ? 'scale-110 border-white' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: EXPORT & QUALITY SETTINGS */}
            {activeTab === 'export' && (
              <div className="space-y-3.5">
                <div className="p-3 rounded-xl bg-gradient-to-r from-[#7C4DFF]/20 to-[#00E5FF]/20 border border-[#00E5FF]/40">
                  <div className="text-xs font-bold text-white flex items-center justify-between">
                    <span>Export Quality Profile</span>
                    <span className="text-emerald-400 font-mono text-[11px]">
                      ~{exportConfig.fileSizeMB} MB
                    </span>
                  </div>
                  <p className="text-[10px] text-[#9AA4AF] mt-0.5">
                    AV1 Neural Hardware Quantization with True AMOLED black preservation
                  </p>
                </div>

                {/* Resolution Selector */}
                <div>
                  <label className="text-xs font-semibold text-white block mb-1">
                    Resolution:
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: '4K', label: '4K UHD' },
                      { id: '2K', label: '2K QHD' },
                      { id: '1080p', label: '1080p FHD' },
                      { id: '720p', label: '720p HD' },
                      { id: 'zero_mb', label: 'Zero-MB AV1' },
                    ].map((res) => (
                      <button
                        key={res.id}
                        onClick={() => handleResolutionChange(res.id as any)}
                        className={`p-2 rounded-xl text-xs font-semibold transition-all ${
                          exportConfig.resolution === res.id
                            ? 'bg-[#00E5FF] text-black font-bold shadow-md shadow-[#00E5FF]/20'
                            : 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                        }`}
                      >
                        {res.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Framerate FPS */}
                <div>
                  <label className="text-xs font-semibold text-white block mb-1">
                    Framerate (FPS):
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: 24, label: '24 Cinema' },
                      { id: 30, label: '30 FPS' },
                      { id: 60, label: '60 Smooth' },
                      { id: 120, label: '120 Pro' },
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() => handleFpsChange(f.id as any)}
                        className={`p-2 rounded-xl text-xs font-semibold transition-all ${
                          exportConfig.fps === f.id
                            ? 'bg-[#00E5FF] text-black font-bold shadow-md shadow-[#00E5FF]/20'
                            : 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Final Apply Button */}
                <button
                  onClick={handleApplyExport}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white text-xs font-bold shadow-xl shadow-[#00E5FF]/20 hover:brightness-110 active:scale-98 transition-all flex items-center justify-center space-x-2"
                >
                  <Check className="w-4 h-4" />
                  <span>Apply Edits & Return to Post</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. CapCut Pro Multi-Track Timeline & Ruler */}
      <div className="h-32 md:h-36 bg-[#08090C] border-t border-[#1A1F26] flex flex-col z-20">
        {/* Timeline Ruler Bar */}
        <div
          ref={timelineRef}
          onClick={handleTimelineScrub}
          className="h-6 bg-[#0D0F14] border-b border-[#1A1F26] relative cursor-pointer flex items-center px-2"
        >
          {/* Time markings */}
          <div className="w-full flex justify-between text-[9px] font-mono text-[#6C7684] select-none">
            <span>00:00</span>
            <span>00:03</span>
            <span>00:06</span>
            <span>00:09</span>
            <span>00:12</span>
          </div>

          {/* Draggable Playhead Scrubber */}
          <div
            className="absolute top-0 bottom-0 w-[2px] bg-[#00E5FF] pointer-events-none z-30"
            style={{
              left: `${Math.min(100, (currentTimeSec / totalDurationSec) * 100)}%`,
            }}
          >
            <div className="w-3 h-3 bg-[#00E5FF] -ml-[5px] -top-1 rounded-sm rotate-45 shadow-md shadow-[#00E5FF]" />
          </div>
        </div>

        {/* Multi-Track Canvas */}
        <div className="flex-1 overflow-x-auto p-2 space-y-1.5">
          {/* Track 1: Video / Visual Track */}
          <div className="h-9 rounded-lg bg-[#14171C] border border-[#222730] flex items-center px-1.5 space-x-1 relative overflow-hidden">
            <span className="text-[9px] font-mono text-[#6C7684] px-1 border-r border-[#222730] mr-1 flex-shrink-0">
              V1
            </span>
            {clips.map((c, i) => (
              <div
                key={c.id}
                onClick={() => setActiveClipIndex(i)}
                className={`h-7 rounded-md px-2 flex items-center justify-between text-xs font-semibold cursor-pointer transition-all ${
                  activeClipIndex === i
                    ? 'bg-gradient-to-r from-[#00E5FF]/20 to-[#7C4DFF]/30 border border-[#00E5FF] text-white'
                    : 'bg-[#1C212B] border border-[#2A313E] text-[#9AA4AF]'
                }`}
                style={{
                  width: `${Math.max(25, (c.durationSec / totalDurationSec) * 100)}%`,
                }}
              >
                <div className="flex items-center space-x-1 truncate">
                  <Film className="w-3 h-3 text-[#00E5FF]" />
                  <span className="text-[10px] truncate">Clip {i + 1} ({c.durationSec}s)</span>
                </div>
                {c.transitionIn && c.transitionIn !== 'none' && (
                  <span className="text-[9px] text-cyan-400 font-mono">⚡ FX</span>
                )}
              </div>
            ))}
          </div>

          {/* Track 2: Audio Track */}
          <div className="h-8 rounded-lg bg-[#101318] border border-[#1C212A] flex items-center px-1.5 relative overflow-hidden">
            <span className="text-[9px] font-mono text-[#6C7684] px-1 border-r border-[#222730] mr-1 flex-shrink-0">
              A1
            </span>
            {audioTrack ? (
              <div
                onClick={() => setIsMusicModalOpen(true)}
                className="h-6 w-full rounded-md bg-emerald-950/40 border border-emerald-500/40 px-2 flex items-center justify-between text-[11px] text-emerald-300 cursor-pointer"
              >
                <div className="flex items-center space-x-1.5 truncate">
                  <Music className="w-3 h-3 text-emerald-400" />
                  <span className="truncate">{audioTrack.title}</span>
                </div>
                <div className="flex items-center space-x-0.5">
                  <span className="w-1 h-3 bg-emerald-400 rounded-full" />
                  <span className="w-1 h-2 bg-emerald-400 rounded-full" />
                  <span className="w-1 h-4 bg-emerald-400 rounded-full" />
                </div>
              </div>
            ) : (
              <button
                onClick={() => setIsMusicModalOpen(true)}
                className="h-6 w-full rounded-md border border-dashed border-[#222730] hover:border-[#00E5FF]/40 text-[10px] text-[#6C7684] hover:text-[#00E5FF] flex items-center justify-center space-x-1 transition-colors"
              >
                <Plus className="w-3 h-3" />
                <span>Add Audio Track from Z-eye Music Library</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Music Library Modal sub-modal */}
      <ZeyeMusicLibraryModal
        isOpen={isMusicModalOpen}
        onClose={() => setIsMusicModalOpen(false)}
        onSelectTrack={(track) => setAudioTrack(track)}
        currentSelectedId={audioTrack?.id}
      />
    </div>
  );
};
