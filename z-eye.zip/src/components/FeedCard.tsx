import React, { useState, useRef } from 'react';
import { Post } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Eye,
  MoreVertical,
  CheckCircle2,
  Camera,
  Film,
  Zap,
  Users,
  Tag,
  Music,
  Disc,
} from 'lucide-react';

interface FeedCardProps {
  post: Post;
  onLikeToggle: (postId: string) => void;
  onOpenComments: (post: Post) => void;
  onOpenReport: (postId: string) => void;
}

export const FeedCard: React.FC<FeedCardProps> = ({
  post,
  onLikeToggle,
  onOpenComments,
  onOpenReport,
}) => {
  const { currentUser } = useAuth();
  const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [showAltTextBanner, setShowAltTextBanner] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showTaggedPopover, setShowTaggedPopover] = useState(false);
  
  // Video player state
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [videoProgress, setVideoProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const lastTapRef = useRef<number>(0);

  const mediaItems = post.media || [];
  const currentMedia = mediaItems[currentMediaIndex] || {
    url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
    type: 'image',
    aspectRatio: '1:1',
    altText: 'Photo post',
  };

  const isVideo = currentMedia.type === 'video' || post.postType === 'video';

  // Double-tap to like handler or video play/pause toggle
  const handleMediaTap = (e: React.MouseEvent) => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap triggered like
      if (!post.hasLiked) {
        onLikeToggle(post.id);
      }
      setShowHeartBurst(true);
      setTimeout(() => setShowHeartBurst(false), 900);
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
      // Single tap on video toggles play/pause
      if (isVideo && videoRef.current) {
        if (videoRef.current.paused) {
          videoRef.current.play().catch(() => {});
          setIsPlaying(true);
        } else {
          videoRef.current.pause();
          setIsPlaying(false);
        }
      }
    }
  };

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current && videoRef.current.duration) {
      const prog = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setVideoProgress(prog);
    }
  };

  // Next / Prev carousel slide
  const nextSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentMediaIndex < mediaItems.length - 1) {
      setCurrentMediaIndex((prev) => prev + 1);
    }
  };

  const prevSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentMediaIndex > 0) {
      setCurrentMediaIndex((prev) => prev - 1);
    }
  };

  // Aspect ratio class calculation
  const getAspectRatioClass = () => {
    switch (currentMedia.aspectRatio) {
      case '4:5':
        return 'aspect-[4/5]';
      case '9:16':
        return 'aspect-[9/16] max-h-[560px]';
      case '16:9':
        return 'aspect-[16/9]';
      case '1:1':
      default:
        return 'aspect-square';
    }
  };

  return (
    <article
      id={`post-${post.id}`}
      className="bg-[#0B0D10] border border-[#14171C] rounded-2xl overflow-hidden mb-5 transition-shadow shadow-md shadow-black/40"
    >
      {/* 1. Post Header */}
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {/* Avatar with Co-Author overlap if present */}
          <div className="relative flex items-center">
            <img
              src={post.user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
              alt={post.user.username}
              className="w-10 h-10 rounded-full object-cover border border-[#222730] z-10"
            />
            {post.collaborators && post.collaborators.length > 0 && (
              <div
                className="-ml-3 w-7 h-7 rounded-full bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] z-20 shadow-md shadow-black"
                title={`Co-creator: @${post.collaborators[0].username}`}
              >
                <div className="w-full h-full bg-black rounded-full flex items-center justify-center text-[9px] font-bold text-white uppercase">
                  {post.collaborators[0].username.slice(0, 2)}
                </div>
              </div>
            )}
            {post.user.isVerified && (
              <span className="absolute -bottom-0.5 -right-0.5 bg-black rounded-full p-0.5 z-30">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00E5FF] fill-[#00E5FF]/20" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center space-x-1.5 flex-wrap">
              <span className="font-bold text-sm text-[#F5F7FA] hover:text-[#00E5FF] transition-colors">
                {post.user.displayName || post.user.username}
              </span>
              {post.collaborators && post.collaborators.length > 0 && (
                <span className="text-xs font-semibold text-purple-300 flex items-center space-x-1">
                  <span>×</span>
                  <span className="hover:underline">@{post.collaborators[0].username}</span>
                </span>
              )}
              <span className="text-xs text-[#9AA4AF]">@{post.user.username}</span>
            </div>
            
            {/* Format & Metadata Badges */}
            <div className="flex items-center space-x-1.5 mt-0.5 flex-wrap gap-y-1">
              {isVideo ? (
                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded bg-gradient-to-r from-[#7C4DFF]/20 to-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/30 text-[10px] font-semibold">
                  <Film className="w-3 h-3" />
                  <span>Short Video</span>
                </span>
              ) : (
                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded bg-[#14171C] text-[#9AA4AF] border border-[#222730] text-[10px] font-medium">
                  <Camera className="w-3 h-3 text-[#7C4DFF]" />
                  <span>{mediaItems.length > 1 ? `Photo Carousel (${mediaItems.length})` : 'Photo'}</span>
                </span>
              )}

              {/* Quality & FPS Badge */}
              {post.videoQuality && (
                <span className="inline-flex items-center px-1.5 py-0.2 rounded bg-cyan-950/70 text-cyan-300 border border-cyan-500/30 text-[9px] font-mono font-bold">
                  {post.videoQuality.resolution} {post.videoQuality.fps}FPS
                </span>
              )}

              {/* Collaboration Tag */}
              {post.collaborators && post.collaborators.length > 0 && (
                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded bg-purple-950/70 text-purple-300 border border-purple-500/30 text-[9px] font-semibold">
                  <Users className="w-2.5 h-2.5" />
                  <span>Collab</span>
                </span>
              )}

              {/* Zero-MB tag */}
              <span
                className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono"
                title="Optimized with AI Zero-MB Codec: Stream without burning data"
              >
                <Zap className="w-2.5 h-2.5 text-emerald-400 fill-emerald-400" />
                <span>{isVideo ? '0.3 MB' : '18 KB'}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Options / Safety Report */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#14171C] text-[#9AA4AF] transition-colors"
            aria-label="More post options"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
          {showMenu && (
            <div className="absolute right-0 top-10 w-44 bg-[#14171C] border border-[#222730] rounded-xl shadow-2xl py-1.5 z-20">
              <button
                onClick={() => {
                  setShowAltTextBanner(!showAltTextBanner);
                  setShowMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#F5F7FA] hover:bg-[#0B0D10] flex items-center space-x-2"
              >
                <Eye className="w-3.5 h-3.5 text-[#00E5FF]" />
                <span>Accessibility Alt-Text</span>
              </button>
              <button
                onClick={() => {
                  setIsZoomOpen(true);
                  setShowMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#F5F7FA] hover:bg-[#0B0D10] flex items-center space-x-2"
              >
                <Maximize2 className="w-3.5 h-3.5 text-[#7C4DFF]" />
                <span>Expand View</span>
              </button>
              <div className="h-px bg-[#222730] my-1" />
              <button
                onClick={() => {
                  onOpenReport(post.id);
                  setShowMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-[#0B0D10]"
              >
                Report Post (Safety)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 2. Media Presentation (Video Player or High-Res Photo) */}
      <div
        className={`relative w-full ${getAspectRatioClass()} bg-black flex items-center justify-center overflow-hidden select-none cursor-pointer group`}
        onClick={handleMediaTap}
      >
        {isVideo ? (
          <>
            <video
              ref={videoRef}
              src={currentMedia.url}
              className="w-full h-full object-contain bg-black"
              autoPlay
              loop
              playsInline
              muted={isMuted}
              onTimeUpdate={handleVideoTimeUpdate}
            />

            {/* Video Play/Pause Overlay Indicator */}
            {!isPlaying && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center pointer-events-none z-10">
                <div className="w-14 h-14 rounded-full bg-black/70 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-2xl">
                  <Play className="w-7 h-7 text-white fill-white ml-1" />
                </div>
              </div>
            )}

            {/* Sound Toggle Button */}
            <button
              onClick={toggleSound}
              className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition-all z-10 border border-white/10"
              aria-label={isMuted ? 'Unmute video' : 'Mute video'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-[#9AA4AF]" /> : <Volume2 className="w-4 h-4 text-[#00E5FF]" />}
            </button>

            {/* Video Progress Bar */}
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20 z-10">
              <div
                className="h-full bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] transition-all"
                style={{ width: `${videoProgress}%` }}
              />
            </div>
          </>
        ) : (
          <img
            src={currentMedia.url}
            alt={currentMedia.altText || post.caption}
            className="w-full h-full object-cover transition-transform duration-300"
            loading="lazy"
          />
        )}

        {/* Carousel Multi-item indicator */}
        {mediaItems.length > 1 && (
          <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md text-white text-[11px] font-mono border border-white/10 z-10">
            {currentMediaIndex + 1}/{mediaItems.length}
          </div>
        )}

        {/* Carousel navigation buttons */}
        {mediaItems.length > 1 && currentMediaIndex > 0 && (
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition-all z-10"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}
        {mediaItems.length > 1 && currentMediaIndex < mediaItems.length - 1 && (
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition-all z-10"
            aria-label="Next image"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}

        {/* Carousel Pagination Dots */}
        {mediaItems.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center space-x-1.5 z-10">
            {mediaItems.map((_, idx) => (
              <span
                key={idx}
                className={`h-1.5 rounded-full transition-all ${
                  idx === currentMediaIndex ? 'w-4 bg-[#00E5FF]' : 'w-1.5 bg-white/40'
                }`}
              />
            ))}
          </div>
        )}

        {/* Tagged People Badge & Popover on Media */}
        {post.taggedUsers && post.taggedUsers.length > 0 && (
          <div className="absolute bottom-3 left-3 z-20">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowTaggedPopover(!showTaggedPopover);
              }}
              className="px-2.5 py-1 rounded-full bg-black/80 hover:bg-black text-cyan-300 text-[11px] font-semibold flex items-center space-x-1.5 border border-cyan-500/30 backdrop-blur-md shadow-lg"
            >
              <Tag className="w-3 h-3 text-[#00E5FF]" />
              <span>{post.taggedUsers.length} {post.taggedUsers.length === 1 ? 'Person' : 'People'}</span>
            </button>

            {showTaggedPopover && (
              <div
                className="absolute bottom-9 left-0 w-48 bg-[#101318]/95 border border-[#222730] rounded-xl p-2 shadow-2xl backdrop-blur-md space-y-1 animate-in zoom-in-90"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="text-[10px] text-[#9AA4AF] font-bold uppercase px-1 pb-1 border-b border-white/5">
                  Tagged Users
                </div>
                {post.taggedUsers.map((u) => (
                  <div
                    key={u.username}
                    className="flex items-center space-x-1.5 px-1.5 py-1 rounded-lg hover:bg-white/5 text-xs text-white cursor-pointer"
                    onClick={() => alert(`Visiting @${u.username}'s profile`)}
                  >
                    <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-500/30 text-[9px] flex items-center justify-center font-bold text-cyan-300">
                      @
                    </span>
                    <span className="font-semibold text-cyan-300">@{u.username}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Audio Track Badge */}
        {post.audioTrack && (
          <div className="absolute bottom-3 right-3 z-10 max-w-[160px] truncate">
            <div className="px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md text-white text-[10px] flex items-center space-x-1.5 border border-purple-500/30 shadow-md">
              <Disc className="w-3 h-3 text-purple-400 animate-spin" />
              <span className="truncate text-purple-200 font-medium">
                {post.audioTrack.title}
              </span>
            </div>
          </div>
        )}

        {/* Double-tap Heart Pop Animation */}
        {showHeartBurst && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20 animate-in zoom-in-50 fade-in duration-200">
            <Heart className="w-24 h-24 text-rose-500 fill-rose-500 drop-shadow-[0_0_20px_rgba(244,63,94,0.8)] animate-bounce" />
          </div>
        )}
      </div>

      {/* 3. Alt-text Accessibility Banner */}
      {showAltTextBanner && currentMedia.altText && (
        <div className="px-4 py-2 bg-[#14171C] border-b border-[#222730] flex items-start space-x-2 text-xs text-[#9AA4AF]">
          <Volume2 className="w-4 h-4 text-[#00E5FF] mt-0.5 shrink-0" />
          <p className="leading-relaxed">
            <strong className="text-white">Accessible Alt Text:</strong> {currentMedia.altText}
          </p>
        </div>
      )}

      {/* 4. Action Buttons (Optimistic UI) */}
      <div className="px-4 pt-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* Like Button */}
          <button
            onClick={() => onLikeToggle(post.id)}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center -ml-2 text-[#F5F7FA] hover:text-rose-500 transition-colors group"
            aria-label={post.hasLiked ? 'Unlike post' : 'Like post'}
          >
            <Heart
              className={`w-6 h-6 transition-transform group-active:scale-125 ${
                post.hasLiked ? 'text-rose-500 fill-rose-500' : 'text-[#F5F7FA]'
              }`}
            />
          </button>

          {/* Comment Button */}
          <button
            onClick={() => onOpenComments(post)}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#F5F7FA] hover:text-[#00E5FF] transition-colors"
            aria-label="Open comments sheet"
          >
            <MessageCircle className="w-6 h-6" />
          </button>

          {/* Share */}
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: 'Z-eye Post', url: window.location.href });
              } else {
                navigator.clipboard?.writeText(window.location.href);
                alert('Post link copied to clipboard!');
              }
            }}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#F5F7FA] hover:text-[#7C4DFF] transition-colors"
            aria-label="Share post"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>

        {/* Bookmark / Save */}
        <button
          onClick={() => alert('Saved to Z-eye collection.')}
          className="min-w-[44px] min-h-[44px] flex items-center justify-center -mr-2 text-[#9AA4AF] hover:text-[#00E5FF] transition-colors"
          aria-label="Save post"
        >
          <Bookmark className="w-5 h-5" />
        </button>
      </div>

      {/* 5. Metrics & Caption */}
      <div className="px-4 pb-3.5">
        <div className="text-xs font-bold text-white mb-1.5">
          {post.likesCount.toLocaleString()} {post.likesCount === 1 ? 'like' : 'likes'}
        </div>

        {/* Caption with Highlighted @Mentions & #Tags */}
        <p className="text-xs leading-relaxed text-[#F5F7FA]">
          <span className="font-bold text-white mr-2">@{post.user.username}</span>
          {post.caption.split(' ').map((word, wIdx) => {
            if (word.startsWith('@')) {
              return (
                <span
                  key={wIdx}
                  onClick={() => alert(`Visiting ${word}'s profile`)}
                  className="text-[#00E5FF] font-semibold hover:underline cursor-pointer mr-1"
                >
                  {word}{' '}
                </span>
              );
            }
            if (word.startsWith('#')) {
              return (
                <span key={wIdx} className="text-purple-400 font-medium hover:underline cursor-pointer mr-1">
                  {word}{' '}
                </span>
              );
            }
            return <span key={wIdx}>{word} </span>;
          })}
        </p>

        {/* Comments counter trigger */}
        {post.commentsCount > 0 && (
          <button
            onClick={() => onOpenComments(post)}
            className="mt-1.5 text-xs text-[#9AA4AF] hover:text-[#00E5FF] transition-colors"
          >
            View all {post.commentsCount} comments
          </button>
        )}

        <div className="mt-1 text-[10px] text-[#9AA4AF] uppercase tracking-wider font-mono">
          {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {isVideo ? 'SHORT VIDEO' : 'PHOTO'}
        </div>
      </div>

      {/* 6. Expand Modal */}
      {isZoomOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-lg animate-in fade-in"
          onClick={() => setIsZoomOpen(false)}
        >
          <button
            className="absolute top-5 right-5 text-white bg-[#14171C] p-2.5 rounded-full border border-[#222730]"
            onClick={() => setIsZoomOpen(false)}
          >
            ✕
          </button>
          <div className="max-w-2xl max-h-[85vh] w-full flex flex-col items-center">
            {isVideo ? (
              <video
                src={currentMedia.url}
                className="w-full max-h-[75vh] object-contain rounded-xl shadow-2xl"
                controls
                autoPlay
                playsInline
              />
            ) : (
              <img
                src={currentMedia.url}
                alt={currentMedia.altText || 'Expanded view'}
                className="w-full max-h-[75vh] object-contain rounded-xl shadow-2xl"
              />
            )}
            {currentMedia.altText && (
              <p className="mt-3 text-xs text-center text-[#9AA4AF] max-w-lg">
                {currentMedia.altText}
              </p>
            )}
          </div>
        </div>
      )}
    </article>
  );
};
