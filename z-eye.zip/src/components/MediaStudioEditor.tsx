import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Sliders,
  Music,
  Scissors,
  Type,
  Wand2,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Check,
  X,
  Zap,
  Disc,
  Film,
  Camera,
  Crop,
  Upload,
  Layers,
  Flame,
} from 'lucide-react';
import { MediaFilterSettings } from '../types';
import { synthEngine, SOUNDTRACK_PRESETS, PresetTrack } from '../utils/audioSynth';
import { api } from '../services/api';

interface MediaStudioEditorProps {
  isOpen: boolean;
  onClose: () => void;
  mediaUrl: string;
  postType: 'photo' | 'video';
  initialSettings: MediaFilterSettings;
  currentCaption: string;
  currentAltText: string;
  username: string;
  onApply: (
    settings: MediaFilterSettings,
    newCaption?: string,
    newAltText?: string
  ) => void;
}

const FILTER_PRESETS = [
  {
    id: 'none',
    name: 'Normal',
    badge: 'Raw',
    css: 'none',
    desc: 'Unfiltered authentic dynamic range',
  },
  {
    id: 'cyber_amoled',
    name: '⚡ Cyber AMOLED',
    badge: 'Neon',
    css: 'contrast(135%) saturate(145%) hue-rotate(15deg)',
    desc: 'Pure deep blacks with electric cyan & violet vibrancy',
  },
  {
    id: 'noir',
    name: '🌑 Noir Darkroom',
    badge: 'B&W',
    css: 'grayscale(100%) contrast(165%) brightness(95%)',
    desc: 'High-contrast monochrome tailored for OLED diodes',
  },
  {
    id: 'vintage',
    name: '🎞️ 35mm Analog',
    badge: 'Retro',
    css: 'sepia(42%) contrast(118%) saturate(120%)',
    desc: 'Warm analog grain with golden nostalgic shadows',
  },
  {
    id: 'sunset',
    name: '🌅 Sunset Glow',
    badge: 'Warm',
    css: 'sepia(25%) saturate(160%) brightness(106%)',
    desc: 'Golden hour warmth with rich twilight highlights',
  },
  {
    id: 'emerald',
    name: '💚 Matrix Cyber',
    badge: 'Sci-Fi',
    css: 'hue-rotate(95deg) contrast(130%) saturate(125%)',
    desc: 'Emerald neon grade for tech and nighttime reels',
  },
  {
    id: 'vivid',
    name: '💥 Vivid Pop',
    badge: 'Punchy',
    css: 'saturate(185%) contrast(125%) brightness(102%)',
    desc: 'Hyper-saturated colors for eye-catching feeds',
  },
  {
    id: 'midnight',
    name: '🌌 Deep Midnight',
    badge: 'True 0-Nit',
    css: 'contrast(155%) brightness(88%) saturate(110%)',
    desc: 'Crushed blacks that turn OLED pixels completely off',
  },
];

export const MediaStudioEditor: React.FC<MediaStudioEditorProps> = ({
  isOpen,
  onClose,
  mediaUrl,
  postType,
  initialSettings,
  currentCaption,
  currentAltText,
  username,
  onApply,
}) => {
  const [activeTab, setActiveTab] = useState<'filters' | 'adjust' | 'trim' | 'music' | 'text' | 'ai'>('filters');
  
  // Settings state
  const [filterName, setFilterName] = useState(initialSettings.filterName || 'none');
  const [brightness, setBrightness] = useState(initialSettings.brightness ?? 100);
  const [contrast, setContrast] = useState(initialSettings.contrast ?? 100);
  const [saturation, setSaturation] = useState(initialSettings.saturation ?? 100);
  const [warmth, setWarmth] = useState(initialSettings.warmth ?? 0);
  const [blur, setBlur] = useState(initialSettings.blur ?? 0);
  const [vignette, setVignette] = useState(initialSettings.vignette ?? false);
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '4:5' | '9:16' | '16:9'>(
    initialSettings.aspectRatio || (postType === 'video' ? '9:16' : '4:5')
  );

  // Video trim & speed
  const [trimStartSec, setTrimStartSec] = useState(initialSettings.trimStartSec ?? 0);
  const [trimEndSec, setTrimEndSec] = useState(initialSettings.trimEndSec ?? (postType === 'video' ? 15 : 0));
  const [playbackSpeed, setPlaybackSpeed] = useState(initialSettings.playbackSpeed ?? 1.0);
  const [muteOriginalAudio, setMuteOriginalAudio] = useState(initialSettings.muteOriginalAudio ?? false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(15);

  // Music state
  const [selectedMusicId, setSelectedMusicId] = useState(initialSettings.selectedMusicId || 'cyber_pulse');
  const [musicTitle, setMusicTitle] = useState(initialSettings.musicTitle || '⚡ Cyber-Pulse Synth');
  const [musicVolume, setMusicVolume] = useState(initialSettings.musicVolume ?? 75);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [customAudioFileName, setCustomAudioFileName] = useState<string | null>(null);

  // Text overlay & watermark
  const [overlayText, setOverlayText] = useState(initialSettings.overlayText || '');
  const [overlayPosition, setOverlayPosition] = useState<'top' | 'center' | 'bottom'>(
    initialSettings.overlayPosition || 'bottom'
  );
  const [overlayColor, setOverlayColor] = useState(initialSettings.overlayColor || '#00E5FF');
  const [overlayStyle, setOverlayStyle] = useState<'glow' | 'minimal' | 'cyber'>(
    initialSettings.overlayStyle || 'glow'
  );
  const [watermark, setWatermark] = useState(initialSettings.watermark ?? true);

  // AI Caption Studio
  const [captionDraft, setCaptionDraft] = useState(currentCaption);
  const [altTextDraft, setAltTextDraft] = useState(currentAltText);
  const [aiTone, setAiTone] = useState<'viral' | 'aesthetic' | 'hindi' | 'cyberpunk' | 'minimal'>('aesthetic');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [suggestedTags, setSuggestedTags] = useState<string[]>([
    '#Zeye',
    '#AMOLED',
    postType === 'video' ? '#Reels' : '#Photography',
    '#ZeroMB',
  ]);

  const videoRef = useRef<HTMLVideoElement>(null);
  const customAudioInputRef = useRef<HTMLInputElement>(null);

  // Synchronize initial settings on open
  useEffect(() => {
    if (isOpen) {
      setFilterName(initialSettings.filterName || 'none');
      setBrightness(initialSettings.brightness ?? 100);
      setContrast(initialSettings.contrast ?? 100);
      setSaturation(initialSettings.saturation ?? 100);
      setWarmth(initialSettings.warmth ?? 0);
      setBlur(initialSettings.blur ?? 0);
      setVignette(initialSettings.vignette ?? false);
      setAspectRatio(initialSettings.aspectRatio || (postType === 'video' ? '9:16' : '4:5'));
      setSelectedMusicId(initialSettings.selectedMusicId || 'cyber_pulse');
      setMusicTitle(initialSettings.musicTitle || '⚡ Cyber-Pulse Synth');
      setCaptionDraft(currentCaption);
      setAltTextDraft(currentAltText);
    } else {
      synthEngine.stop();
      setIsMusicPlaying(false);
    }
  }, [isOpen]);

  // Video time tracking
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    const onTimeUpdate = () => {
      setCurrentTime(v.currentTime);
      if (trimEndSec > 0 && v.currentTime >= trimEndSec) {
        v.currentTime = trimStartSec;
      }
    };
    const onLoadedMetadata = () => {
      if (v.duration && !isNaN(v.duration)) {
        setVideoDuration(Math.round(v.duration));
        if (trimEndSec === 15 || trimEndSec === 0) {
          setTrimEndSec(Math.min(30, Math.round(v.duration)));
        }
      }
    };

    v.addEventListener('timeupdate', onTimeUpdate);
    v.addEventListener('loadedmetadata', onLoadedMetadata);
    return () => {
      v.removeEventListener('timeupdate', onTimeUpdate);
      v.removeEventListener('loadedmetadata', onLoadedMetadata);
    };
  }, [trimStartSec, trimEndSec]);

  // Video playback speed
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Music synth volume sync
  useEffect(() => {
    synthEngine.setVolume(musicVolume / 100);
  }, [musicVolume]);

  if (!isOpen) return null;

  // Compute CSS filter string
  const activePreset = FILTER_PRESETS.find((f) => f.id === filterName);
  const presetCss = activePreset && activePreset.id !== 'none' ? activePreset.css : '';
  
  const computedFilterString = `
    brightness(${brightness}%)
    contrast(${contrast}%)
    saturate(${saturation}%)
    hue-rotate(${warmth}deg)
    ${blur > 0 ? `blur(${blur}px)` : ''}
    ${presetCss}
  `.trim();

  const handleTogglePlayVideo = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      if (videoRef.current.currentTime < trimStartSec || videoRef.current.currentTime >= trimEndSec) {
        videoRef.current.currentTime = trimStartSec;
      }
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleToggleMusic = (track: PresetTrack) => {
    if (selectedMusicId === track.id && isMusicPlaying) {
      synthEngine.stop();
      setIsMusicPlaying(false);
    } else {
      setSelectedMusicId(track.id);
      setMusicTitle(track.name);
      synthEngine.playTrack(track.id);
      setIsMusicPlaying(true);
    }
  };

  const handleCustomAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCustomAudioFileName(file.name);
      setSelectedMusicId('custom');
      setMusicTitle(`🎵 ${file.name.slice(0, 20)}`);
      synthEngine.stop();
      setIsMusicPlaying(false);
    }
  };

  const handleResetAdjustments = () => {
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setWarmth(0);
    setBlur(0);
    setVignette(false);
    setFilterName('none');
    setPlaybackSpeed(1.0);
  };

  const handleAiGenerateCaption = async () => {
    setIsAiGenerating(true);
    try {
      const res = await api.aiFixCaption(captionDraft, postType, {
        style: aiTone,
        musicTitle: selectedMusicId !== 'none' ? musicTitle : undefined,
        filterName: activePreset?.name,
      });

      if (res.enhancedCaption) {
        setCaptionDraft(res.enhancedCaption);
      }
      if (res.altText) {
        setAltTextDraft(res.altText);
      }
      if (res.suggestedTags && Array.isArray(res.suggestedTags)) {
        setSuggestedTags(res.suggestedTags);
      }
    } catch (e) {
      console.error('AI Studio generation failed:', e);
    } finally {
      setIsAiGenerating(false);
    }
  };

  const handleAddTagToCaption = (tag: string) => {
    if (!captionDraft.includes(tag)) {
      setCaptionDraft((prev) => `${prev.trim()} ${tag}`);
    }
  };

  const handleSaveAndApply = () => {
    synthEngine.stop();
    setIsMusicPlaying(false);

    const finalSettings: MediaFilterSettings = {
      filterName,
      brightness,
      contrast,
      saturation,
      warmth,
      blur,
      vignette,
      aspectRatio,
      overlayText: overlayText.trim() || undefined,
      overlayPosition,
      overlayColor,
      overlayStyle,
      watermark,
      trimStartSec,
      trimEndSec,
      playbackSpeed,
      selectedMusicId,
      musicTitle,
      musicVolume,
      muteOriginalAudio,
    };

    onApply(finalSettings, captionDraft, altTextDraft);
    onClose();
  };

  // Framing aspect ratio style
  const getAspectRatioClasses = () => {
    switch (aspectRatio) {
      case '1:1':
        return 'aspect-square max-h-[360px]';
      case '4:5':
        return 'aspect-[4/5] max-h-[420px]';
      case '9:16':
        return 'aspect-[9/16] max-h-[460px]';
      case '16:9':
        return 'aspect-[16/9] max-h-[300px]';
      default:
        return 'aspect-[4/5] max-h-[400px]';
    }
  };

  return (
    <div
      id="media-studio-editor-modal"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-2 sm:p-4 animate-in fade-in"
    >
      <div
        className="w-full max-w-4xl bg-[#0B0D10] border border-[#222730] rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[96vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Editor Top Bar */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-[#14171C] flex items-center justify-between bg-[#0E1116]">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#00E5FF] animate-pulse" />
            <h3 className="font-extrabold text-sm sm:text-base text-white tracking-wide">
              {postType === 'video' ? '🎬 Z-eye Video Reel Studio' : '🎨 Z-eye Photo Creative Studio'}
            </h3>
            <span className="hidden xs:inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-300 font-mono font-bold border border-emerald-500/30">
              <Zap className="w-2.5 h-2.5 fill-emerald-400" />
              <span>ZERO-MB ENGINE</span>
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleResetAdjustments}
              className="px-2.5 py-1.5 rounded-lg bg-[#14171C] hover:bg-[#222730] text-[#9AA4AF] hover:text-white text-xs font-semibold flex items-center space-x-1 transition-colors"
              title="Reset all filters and sliders"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>

            <button
              onClick={handleSaveAndApply}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00E5FF] to-[#7C4DFF] hover:brightness-110 text-black font-extrabold text-xs flex items-center space-x-1.5 shadow-md shadow-[#00E5FF]/20 active:scale-95 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Save & Apply</span>
            </button>

            <button
              onClick={() => {
                synthEngine.stop();
                onClose();
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center text-[#9AA4AF] hover:text-white hover:bg-[#14171C] transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Studio Body: Left Stage (Visual Canvas) & Right Toolbar */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Visual Stage (Live Canvas with Filters & Overlays) */}
          <div className="w-full md:w-1/2 p-3 sm:p-5 flex flex-col items-center justify-center bg-black/80 border-b md:border-b-0 md:border-r border-[#14171C] relative overflow-hidden">
            <div
              className={`w-full max-w-[340px] sm:max-w-[380px] ${getAspectRatioClasses()} rounded-2xl overflow-hidden relative bg-black shadow-2xl border border-white/10 flex items-center justify-center transition-all duration-300`}
            >
              {/* Media Element */}
              {postType === 'video' ? (
                <video
                  ref={videoRef}
                  src={mediaUrl}
                  style={{ filter: computedFilterString }}
                  className="w-full h-full object-cover"
                  muted={muteOriginalAudio}
                  playsInline
                  loop
                />
              ) : (
                <img
                  src={mediaUrl}
                  alt="Studio Canvas"
                  style={{ filter: computedFilterString }}
                  className="w-full h-full object-cover transition-all"
                />
              )}

              {/* Vignette Overlay */}
              {vignette && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background:
                      'radial-gradient(ellipse at center, rgba(0,0,0,0) 40%, rgba(0,0,0,0.8) 100%)',
                  }}
                />
              )}

              {/* Text Overlay */}
              {overlayText && (
                <div
                  className={`absolute inset-x-4 pointer-events-none flex justify-center ${
                    overlayPosition === 'top'
                      ? 'top-4'
                      : overlayPosition === 'center'
                      ? 'top-1/2 -translate-y-1/2'
                      : 'bottom-8'
                  }`}
                >
                  <span
                    className={`font-extrabold text-center px-3 py-1 rounded-lg text-sm sm:text-base tracking-wide max-w-full break-words ${
                      overlayStyle === 'glow'
                        ? 'drop-shadow-[0_2px_12px_rgba(0,229,255,0.8)]'
                        : overlayStyle === 'cyber'
                        ? 'bg-black/80 border border-[#00E5FF] px-2.5 py-1'
                        : 'bg-black/60 backdrop-blur-sm'
                    }`}
                    style={{ color: overlayColor }}
                  >
                    {overlayText}
                  </span>
                </div>
              )}

              {/* Watermark */}
              {watermark && (
                <div className="absolute bottom-2.5 right-2.5 pointer-events-none px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-white/15 text-[9px] font-mono text-white/90 flex items-center space-x-1 shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-pulse" />
                  <span>@{username || 'user'} • Z-eye</span>
                </div>
              )}

              {/* Video Play / Pause Controls Over Media */}
              {postType === 'video' && (
                <button
                  type="button"
                  onClick={handleTogglePlayVideo}
                  className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 flex items-center justify-center text-white transition-all hover:scale-105 active:scale-95 group"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-[#00E5FF] fill-[#00E5FF] ml-0.5" />
                  )}
                </button>
              )}

              {/* Equalizer Wave / Audio Indicator when music is active */}
              {isMusicPlaying && (
                <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-black/80 border border-emerald-500/50 backdrop-blur-md flex items-center space-x-1">
                  <div className="flex items-end space-x-0.5 h-3">
                    <span className="w-1 bg-emerald-400 rounded-full animate-[pulse_0.4s_infinite]" style={{ height: '70%' }} />
                    <span className="w-1 bg-[#00E5FF] rounded-full animate-[pulse_0.3s_infinite]" style={{ height: '100%' }} />
                    <span className="w-1 bg-purple-400 rounded-full animate-[pulse_0.5s_infinite]" style={{ height: '50%' }} />
                    <span className="w-1 bg-emerald-400 rounded-full animate-[pulse_0.4s_infinite]" style={{ height: '85%' }} />
                  </div>
                  <span className="text-[9px] font-mono text-emerald-300 font-bold ml-1">BEATS ON</span>
                </div>
              )}
            </div>

            {/* Video Scrubber & Timestamp Bar */}
            {postType === 'video' && (
              <div className="w-full max-w-[380px] mt-3 px-2 flex items-center space-x-2 text-[11px] font-mono text-[#9AA4AF]">
                <span>{currentTime.toFixed(1)}s</span>
                <input
                  type="range"
                  min={trimStartSec}
                  max={trimEndSec || videoDuration}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => {
                    const t = parseFloat(e.target.value);
                    setCurrentTime(t);
                    if (videoRef.current) videoRef.current.currentTime = t;
                  }}
                  className="flex-1 accent-[#00E5FF] cursor-pointer"
                />
                <span>{(trimEndSec || videoDuration).toFixed(1)}s</span>
              </div>
            )}
          </div>

          {/* Right Toolbar / Feature Tabs */}
          <div className="w-full md:w-1/2 flex flex-col bg-[#0B0D10] overflow-hidden">
            {/* Studio Navigation Tabs */}
            <div className="flex items-center space-x-1 px-3 sm:px-4 pt-3 pb-2 border-b border-[#14171C] overflow-x-auto shrink-0 scrollbar-none">
              <button
                type="button"
                onClick={() => setActiveTab('filters')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                  activeTab === 'filters'
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Filters</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('adjust')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                  activeTab === 'adjust'
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Adjust</span>
              </button>

              {postType === 'video' && (
                <button
                  type="button"
                  onClick={() => setActiveTab('trim')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                    activeTab === 'trim'
                      ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                      : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                  }`}
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Trim & Speed</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setActiveTab('music')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                  activeTab === 'music'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <Music className="w-3.5 h-3.5" />
                <span>Music Beats</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('text')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                  activeTab === 'text'
                    ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                <span>Text Overlay</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('ai')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                  activeTab === 'ai'
                    ? 'bg-gradient-to-r from-[#00E5FF]/20 to-[#7C4DFF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
                <span>AI Caption</span>
              </button>
            </div>

            {/* Tab Contents Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs">
              {/* TAB 1: FILTERS */}
              {activeTab === 'filters' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#9AA4AF] font-bold uppercase tracking-wider text-[10px]">
                      AMOLED & Cinematic Filter Presets
                    </span>
                    <span className="text-emerald-400 font-mono text-[10px]">8 Filters Ready</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {FILTER_PRESETS.map((preset) => {
                      const isSelected = filterName === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setFilterName(preset.id)}
                          className={`p-2.5 rounded-xl border text-left transition-all relative overflow-hidden group ${
                            isSelected
                              ? 'bg-[#00E5FF]/15 border-[#00E5FF] shadow-sm shadow-[#00E5FF]/20'
                              : 'bg-[#14171C] border-[#222730] hover:border-white/20'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-extrabold text-white text-xs truncate">
                              {preset.name}
                            </span>
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-white/10 text-[#00E5FF] font-mono">
                              {preset.badge}
                            </span>
                          </div>
                          <p className="text-[10px] text-[#9AA4AF] leading-tight line-clamp-2">
                            {preset.desc}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 2: ADJUST */}
              {activeTab === 'adjust' && (
                <div className="space-y-4">
                  {/* Framing / Crop Ratio */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-2">
                      Display Aspect Ratio Framing
                    </label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { id: '1:1', label: '1:1 Square' },
                        { id: '4:5', label: '4:5 Portrait' },
                        { id: '9:16', label: '9:16 Reel' },
                        { id: '16:9', label: '16:9 Cinema' },
                      ].map((ratio) => (
                        <button
                          key={ratio.id}
                          type="button"
                          onClick={() => setAspectRatio(ratio.id as any)}
                          className={`py-2 px-1 rounded-xl border text-center font-semibold text-[11px] transition-all ${
                            aspectRatio === ratio.id
                              ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:text-white'
                          }`}
                        >
                          {ratio.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Manual Sliders */}
                  <div className="space-y-3.5 pt-1">
                    {/* Brightness */}
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-white font-medium">Brightness</span>
                        <span className="font-mono text-[#00E5FF]">{brightness}%</span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="160"
                        value={brightness}
                        onChange={(e) => setBrightness(Number(e.target.value))}
                        className="w-full accent-[#00E5FF] cursor-pointer"
                      />
                    </div>

                    {/* Contrast */}
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-white font-medium">Contrast (AMOLED Depth)</span>
                        <span className="font-mono text-[#00E5FF]">{contrast}%</span>
                      </div>
                      <input
                        type="range"
                        min="60"
                        max="180"
                        value={contrast}
                        onChange={(e) => setContrast(Number(e.target.value))}
                        className="w-full accent-[#00E5FF] cursor-pointer"
                      />
                    </div>

                    {/* Saturation */}
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-white font-medium">Saturation</span>
                        <span className="font-mono text-[#00E5FF]">{saturation}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="200"
                        value={saturation}
                        onChange={(e) => setSaturation(Number(e.target.value))}
                        className="w-full accent-[#00E5FF] cursor-pointer"
                      />
                    </div>

                    {/* Warmth / Hue */}
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-white font-medium">Warmth / Color Tint</span>
                        <span className="font-mono text-[#00E5FF]">{warmth}°</span>
                      </div>
                      <input
                        type="range"
                        min="-60"
                        max="60"
                        value={warmth}
                        onChange={(e) => setWarmth(Number(e.target.value))}
                        className="w-full accent-[#00E5FF] cursor-pointer"
                      />
                    </div>

                    {/* Soft Focus / Blur */}
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-white font-medium">Soft Focus / Dream Glow</span>
                        <span className="font-mono text-[#00E5FF]">{blur}px</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="8"
                        step="0.5"
                        value={blur}
                        onChange={(e) => setBlur(Number(e.target.value))}
                        className="w-full accent-[#00E5FF] cursor-pointer"
                      />
                    </div>

                    {/* Vignette Toggle */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-[#14171C] border border-[#222730]">
                      <div>
                        <div className="font-semibold text-white text-xs">Cinematic Vignette</div>
                        <div className="text-[10px] text-[#9AA4AF]">Darken outer borders to highlight center subject</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setVignette(!vignette)}
                        className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                          vignette ? 'bg-[#00E5FF]' : 'bg-[#222730]'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-black transition-transform ${
                            vignette ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: VIDEO TRIM & SPEED */}
              {activeTab === 'trim' && postType === 'video' && (
                <div className="space-y-4">
                  {/* Trim Handles */}
                  <div className="p-3.5 rounded-xl bg-[#14171C] border border-[#222730] space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">Timeline Scissor Trim</span>
                      <span className="font-mono text-xs text-[#00E5FF]">
                        Duration: {(trimEndSec - trimStartSec).toFixed(1)}s
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-[#9AA4AF] block mb-1">Start Point (sec)</label>
                        <input
                          type="number"
                          min="0"
                          max={trimEndSec - 1}
                          step="0.5"
                          value={trimStartSec}
                          onChange={(e) => setTrimStartSec(Math.max(0, Number(e.target.value)))}
                          className="w-full bg-black border border-[#222730] rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:border-[#00E5FF] outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#9AA4AF] block mb-1">End Point (sec)</label>
                        <input
                          type="number"
                          min={trimStartSec + 1}
                          max={videoDuration}
                          step="0.5"
                          value={trimEndSec}
                          onChange={(e) => setTrimEndSec(Math.min(videoDuration, Number(e.target.value)))}
                          className="w-full bg-black border border-[#222730] rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:border-[#00E5FF] outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Playback Speed */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-2">
                      Playback Speed Rate
                    </label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {[0.5, 1.0, 1.25, 1.5, 2.0].map((spd) => (
                        <button
                          key={spd}
                          type="button"
                          onClick={() => setPlaybackSpeed(spd)}
                          className={`py-2 px-1 rounded-xl border text-center font-mono font-bold text-xs transition-all ${
                            playbackSpeed === spd
                              ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:text-white'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mute Original Audio */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-[#14171C] border border-[#222730]">
                    <div className="flex items-center space-x-2">
                      {muteOriginalAudio ? (
                        <VolumeX className="w-4 h-4 text-rose-400" />
                      ) : (
                        <Volume2 className="w-4 h-4 text-emerald-400" />
                      )}
                      <div>
                        <div className="font-semibold text-white text-xs">Mute Original Video Sound</div>
                        <div className="text-[10px] text-[#9AA4AF]">Replace background noise with selected music beat</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setMuteOriginalAudio(!muteOriginalAudio)}
                      className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                        muteOriginalAudio ? 'bg-rose-500' : 'bg-[#222730]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-black transition-transform ${
                          muteOriginalAudio ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 4: MUSIC & SOUNDTRACKS */}
              {activeTab === 'music' && (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[#9AA4AF] font-bold uppercase tracking-wider text-[10px]">
                      Trending Procedural Soundtracks
                    </span>
                    <span className="text-emerald-400 font-mono text-[10px] flex items-center space-x-1">
                      <Zap className="w-3 h-3 fill-emerald-400" />
                      <span>0.00 MB Data Stream</span>
                    </span>
                  </div>

                  {/* Presets List */}
                  <div className="space-y-2">
                    {SOUNDTRACK_PRESETS.map((track) => {
                      const isSelected = selectedMusicId === track.id;
                      return (
                        <div
                          key={track.id}
                          className={`p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                            isSelected
                              ? 'bg-purple-900/20 border-purple-500 text-white shadow-sm'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:border-white/20'
                          }`}
                        >
                          <div className="flex items-center space-x-3 truncate">
                            <button
                              type="button"
                              onClick={() => handleToggleMusic(track)}
                              className={`w-9 h-9 rounded-full shrink-0 flex items-center justify-center transition-all ${
                                isSelected && isMusicPlaying
                                  ? 'bg-purple-500 text-black animate-pulse'
                                  : 'bg-[#222730] text-white hover:bg-[#00E5FF] hover:text-black'
                              }`}
                            >
                              {isSelected && isMusicPlaying ? (
                                <Pause className="w-4 h-4 fill-current" />
                              ) : (
                                <Play className="w-4 h-4 fill-current ml-0.5" />
                              )}
                            </button>

                            <div className="truncate">
                              <div className="font-extrabold text-white text-xs truncate">{track.name}</div>
                              <div className="text-[10px] text-[#9AA4AF] flex items-center space-x-2">
                                <span>{track.genre}</span>
                                <span>•</span>
                                <span className="font-mono text-purple-300">{track.bpm} BPM</span>
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              setSelectedMusicId(track.id);
                              setMusicTitle(track.name);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                              isSelected
                                ? 'bg-purple-500 text-black'
                                : 'bg-[#222730] hover:bg-white/20 text-white'
                            }`}
                          >
                            {isSelected ? 'Active Track' : 'Use Beat'}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Custom Audio Upload */}
                  <div className="p-3 rounded-xl bg-[#14171C] border border-[#222730] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">Upload Your Own Song / MP3</span>
                      <button
                        type="button"
                        onClick={() => customAudioInputRef.current?.click()}
                        className="px-2.5 py-1 rounded-lg bg-[#222730] hover:bg-[#00E5FF] hover:text-black text-white font-bold text-[10px] flex items-center space-x-1 transition-colors"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Browse Audio</span>
                      </button>
                      <input
                        ref={customAudioInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleCustomAudioUpload}
                        className="hidden"
                      />
                    </div>
                    {customAudioFileName && (
                      <div className="text-[10px] text-emerald-400 font-mono flex items-center space-x-1">
                        <Check className="w-3 h-3" />
                        <span>Loaded: {customAudioFileName}</span>
                      </div>
                    )}
                  </div>

                  {/* Volume Slider */}
                  <div className="p-3 rounded-xl bg-[#14171C] border border-[#222730]">
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-white font-medium flex items-center space-x-1">
                        <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                        <span>Background Music Volume</span>
                      </span>
                      <span className="font-mono text-purple-400">{musicVolume}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={musicVolume}
                      onChange={(e) => setMusicVolume(Number(e.target.value))}
                      className="w-full accent-purple-400 cursor-pointer"
                    />
                  </div>
                </div>
              )}

              {/* TAB 5: TEXT OVERLAY & WATERMARK */}
              {activeTab === 'text' && (
                <div className="space-y-4">
                  {/* Text Input */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5">
                      Sticker Headline / Quote Text
                    </label>
                    <input
                      type="text"
                      value={overlayText}
                      onChange={(e) => setOverlayText(e.target.value)}
                      placeholder="e.g. AMOLED Midnight Drop, Cyber City, Tokyo Nights..."
                      className="w-full bg-[#14171C] border border-[#222730] rounded-xl px-3 py-2 text-xs text-white placeholder-[#9AA4AF] focus:border-[#00E5FF] outline-none"
                    />
                  </div>

                  {/* Position */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5">
                      Text Placement
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['top', 'center', 'bottom'] as const).map((pos) => (
                        <button
                          key={pos}
                          type="button"
                          onClick={() => setOverlayPosition(pos)}
                          className={`py-1.5 rounded-xl border text-center font-semibold capitalize text-xs ${
                            overlayPosition === pos
                              ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF]'
                          }`}
                        >
                          {pos}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Palette */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5">
                      Font Color
                    </label>
                    <div className="flex items-center space-x-2">
                      {[
                        { color: '#00E5FF', label: 'Neon Cyan' },
                        { color: '#7C4DFF', label: 'Neon Violet' },
                        { color: '#FFFFFF', label: 'Pure White' },
                        { color: '#FFD600', label: 'Electric Yellow' },
                        { color: '#10B981', label: 'Matrix Green' },
                      ].map((c) => (
                        <button
                          key={c.color}
                          type="button"
                          onClick={() => setOverlayColor(c.color)}
                          style={{ backgroundColor: c.color }}
                          className={`w-7 h-7 rounded-full border-2 transition-transform ${
                            overlayColor === c.color
                              ? 'border-white scale-110 shadow-md'
                              : 'border-transparent hover:scale-105'
                          }`}
                          title={c.label}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Style */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5">
                      Styling Effect
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['glow', 'cyber', 'minimal'] as const).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setOverlayStyle(st)}
                          className={`py-1.5 rounded-xl border text-center font-semibold capitalize text-xs ${
                            overlayStyle === st
                              ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF]'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Watermark Toggle */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-[#14171C] border border-[#222730]">
                    <div>
                      <div className="font-semibold text-white text-xs">Creator Watermark Pill</div>
                      <div className="text-[10px] text-[#9AA4AF]">Add verified @{username || 'user'} • Z-eye badge</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setWatermark(!watermark)}
                      className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                        watermark ? 'bg-[#00E5FF]' : 'bg-[#222730]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-black transition-transform ${
                          watermark ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 6: AI CAPTION & HASHTAGS */}
              {activeTab === 'ai' && (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 text-[#00E5FF]">
                      <Sparkles className="w-4 h-4 fill-[#00E5FF]" />
                      <span className="font-extrabold text-xs tracking-wide">Gemini AI Creator Studio</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                      LIVE AI ACTIVE
                    </span>
                  </div>

                  {/* Tone Selector */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5">
                      Select Tone / Mood
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {[
                        { id: 'viral', label: '🚀 Viral & Catchy' },
                        { id: 'aesthetic', label: '✨ AMOLED Aesthetic' },
                        { id: 'hindi', label: '🇮🇳 Desi / Hinglish' },
                        { id: 'cyberpunk', label: '⚡ Cyber Gamer' },
                        { id: 'minimal', label: '🧘 Poetic & Minimal' },
                      ].map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setAiTone(t.id as any)}
                          className={`py-1.5 px-2 rounded-xl border text-center text-xs font-semibold transition-all ${
                            aiTone === t.id
                              ? 'bg-gradient-to-r from-[#00E5FF]/20 to-[#7C4DFF]/20 border-[#00E5FF] text-[#00E5FF]'
                              : 'bg-[#14171C] border-[#222730] text-[#9AA4AF] hover:text-white'
                          }`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Generate Button */}
                  <button
                    type="button"
                    onClick={handleAiGenerateCaption}
                    disabled={isAiGenerating}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00E5FF] to-[#7C4DFF] hover:brightness-110 disabled:opacity-50 text-black font-extrabold text-xs flex items-center justify-center space-x-2 transition-all shadow-md shadow-[#00E5FF]/20"
                  >
                    {isAiGenerating ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>Gemini AI Crafting Viral Hook...</span>
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-3.5 h-3.5" />
                        <span>Generate High-Converting Caption & Tags</span>
                      </>
                    )}
                  </button>

                  {/* Caption Textarea */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1">
                      Post Caption
                    </label>
                    <textarea
                      rows={3}
                      value={captionDraft}
                      onChange={(e) => setCaptionDraft(e.target.value)}
                      placeholder="Write or generate your caption here..."
                      className="w-full bg-[#14171C] border border-[#222730] rounded-xl p-3 text-xs text-white placeholder-[#9AA4AF] focus:border-[#00E5FF] outline-none"
                    />
                  </div>

                  {/* Clickable Hashtags */}
                  {suggestedTags.length > 0 && (
                    <div>
                      <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1.5 flex items-center space-x-1">
                        <Flame className="w-3 h-3 text-orange-400" />
                        <span>Tap Tag to Add to Caption</span>
                      </label>
                      <div className="flex flex-wrap gap-1.5">
                        {suggestedTags.map((tag) => (
                          <button
                            key={tag}
                            type="button"
                            onClick={() => handleAddTagToCaption(tag)}
                            className="px-2 py-0.5 rounded-lg bg-[#14171C] hover:bg-[#00E5FF]/20 border border-[#222730] hover:border-[#00E5FF] text-[#00E5FF] text-[11px] font-mono transition-colors"
                          >
                            {tag}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Accessible Alt-Text */}
                  <div>
                    <label className="block text-[#9AA4AF] font-bold text-[10px] uppercase tracking-wider mb-1">
                      AI TalkBack Alt-Text (Accessibility)
                    </label>
                    <textarea
                      rows={2}
                      value={altTextDraft}
                      onChange={(e) => setAltTextDraft(e.target.value)}
                      className="w-full bg-[#14171C] border border-[#222730] rounded-xl p-2.5 text-[11px] text-[#9AA4AF] focus:border-[#00E5FF] outline-none"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
