import React from 'react';
import { NavTab } from './Navigation';
import { useAuth } from '../context/AuthContext';
import { useSync } from '../context/SyncContext';
import {
  Home,
  Compass,
  PlusSquare,
  Sparkles,
  User,
  Shield,
  Smartphone,
  Monitor,
  CheckCircle2,
  Radio,
} from 'lucide-react';
import { PlatformMode } from '../types';

interface DesktopSidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  platformMode: PlatformMode;
  onSelectPlatform: (mode: PlatformMode) => void;
  onOpenDeviceManager: () => void;
  onSwitchToMobile: () => void;
}

export const DesktopSidebar: React.FC<DesktopSidebarProps> = ({
  currentTab,
  onSelectTab,
  platformMode,
  onSelectPlatform,
  onOpenDeviceManager,
  onSwitchToMobile,
}) => {
  const { currentUser, deviceModel } = useAuth();
  const { isConnected, latencyMs } = useSync();

  const isMac = platformMode === 'mac';

  const menuItems: { id: NavTab; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'feed', label: 'Home Feed', icon: Home },
    { id: 'explore', label: 'Explore Reels', icon: Compass, badge: 'New' },
    { id: 'ai', label: 'Big Fix AI & SRE', icon: Sparkles },
    { id: 'profile', label: 'My Profile', icon: User },
  ];

  return (
    <aside
      className={`w-64 shrink-0 flex flex-col justify-between p-4 border-r sticky top-0 h-screen select-none ${
        isMac
          ? 'bg-[#0B0D12]/90 backdrop-blur-2xl border-white/10'
          : 'bg-[#0B0D10] border-[#1C2028]'
      }`}
    >
      {/* Top Brand & Desktop Navigation */}
      <div className="space-y-6">
        {/* Brand Header */}
        <div className="flex items-center space-x-2.5 px-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[2px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
            <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
              <span className="font-extrabold text-base tracking-wider text-[#00E5FF]">Z</span>
            </div>
          </div>
          <div>
            <h1 className="font-black text-lg tracking-tight text-white font-['Plus_Jakarta_Sans'] flex items-center space-x-1">
              <span>Z</span><span className="text-[#00E5FF]">-</span><span>eye</span>
            </h1>
            <p className="text-[10px] font-mono text-[#9AA4AF] uppercase tracking-wider">
              {isMac ? 'macOS Edition' : 'Desktop Studio'}
            </p>
          </div>
        </div>

        {/* Primary CTA: Create Post Button */}
        <button
          onClick={() => onSelectTab('create')}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] hover:opacity-95 text-black font-extrabold text-xs tracking-wide flex items-center justify-center space-x-2 shadow-lg shadow-[#00E5FF]/20 active:scale-95 transition-all"
        >
          <PlusSquare className="w-4 h-4 text-black" />
          <span>Create New Post</span>
        </button>

        {/* Navigation Links */}
        <nav className="space-y-1">
          {menuItems.map((item) => {
            const isActive = currentTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm shadow-[#00E5FF]/10'
                    : 'text-[#9AA4AF] hover:text-white hover:bg-[#14171C]'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#00E5FF]' : 'text-[#9AA4AF]'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] font-mono font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Device Security Link */}
          <button
            onClick={onOpenDeviceManager}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold text-[#9AA4AF] hover:text-white hover:bg-[#14171C] transition-all"
          >
            <div className="flex items-center space-x-3">
              <Shield className="w-4 h-4 text-[#00E5FF]" />
              <span>Device Security</span>
            </div>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-400 font-mono">
              1 Lock
            </span>
          </button>
        </nav>

        {/* Mobile Mode Switcher Card */}
        <div className="p-3 rounded-xl bg-[#14171C] border border-[#222730] space-y-2">
          <div className="flex items-center justify-between text-[11px] text-[#9AA4AF]">
            <span className="font-semibold text-white">Mobile View</span>
            <span className="text-[10px] text-[#00E5FF] font-mono">Android & iOS</span>
          </div>
          <p className="text-[10px] text-[#9AA4AF] leading-relaxed">
            Switch back to smartphone frame with touch simulation.
          </p>
          <div className="grid grid-cols-2 gap-1.5 pt-1">
            <button
              onClick={() => {
                onSelectPlatform('android');
                onSwitchToMobile();
              }}
              className="py-1.5 px-2 rounded-lg bg-[#0B0D10] hover:bg-black border border-[#222730] text-[11px] font-semibold text-white flex items-center justify-center space-x-1 hover:border-[#00E5FF] transition-all"
            >
              <span>🤖</span>
              <span>Android</span>
            </button>
            <button
              onClick={() => {
                onSelectPlatform('ios');
                onSwitchToMobile();
              }}
              className="py-1.5 px-2 rounded-lg bg-[#0B0D10] hover:bg-black border border-[#222730] text-[11px] font-semibold text-white flex items-center justify-center space-x-1 hover:border-[#00E5FF] transition-all"
            >
              <span>🍏</span>
              <span>iOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom User Card & Real-time Connectivity */}
      <div className="space-y-3 pt-4 border-t border-[#1C2028]">
        {/* Sync telemetry */}
        <div className="flex items-center justify-between text-[10px] text-[#9AA4AF] font-mono px-1">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-white font-medium">DB SYNC</span>
          </div>
          <span className="text-emerald-400">{latencyMs}ms</span>
        </div>

        {/* User Account */}
        {currentUser && (
          <div className="flex items-center space-x-2.5 p-2 rounded-xl bg-[#14171C] border border-[#222730]">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.username}
              className="w-8 h-8 rounded-full object-cover bg-black"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-1">
                <span className="text-xs font-bold text-white truncate">{currentUser.displayName}</span>
                {currentUser.isVerified && (
                  <CheckCircle2 className="w-3 h-3 text-[#00E5FF] shrink-0" />
                )}
              </div>
              <p className="text-[10px] text-[#9AA4AF] truncate">@{currentUser.username}</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
