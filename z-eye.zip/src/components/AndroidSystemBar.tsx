import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Triangle, Circle, Square, Monitor } from 'lucide-react';

interface AndroidTopBarProps {
  onDesktopSwitch?: () => void;
}

export const AndroidTopBar: React.FC<AndroidTopBarProps> = ({ onDesktopSwitch }) => {
  const [timeStr, setTimeStr] = useState('19:10');

  useEffect(() => {
    const update = () => {
      const d = new Date();
      setTimeStr(d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-8 bg-black px-4 flex items-center justify-between text-[11px] font-mono text-[#9AA4AF] select-none border-b border-[#14171C]/60 z-50">
      {/* Left: Time & notification pill */}
      <div className="flex items-center space-x-2">
        <span className="font-semibold text-white tracking-tight">{timeStr}</span>
        <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" title="Z-eye Active Sync" />
      </div>

      {/* Center: Android Camera Punch-Hole */}
      <div className="flex items-center justify-center">
        <div className="w-3.5 h-3.5 rounded-full bg-[#0B0D10] border border-[#222730] shadow-inner flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-950/80" />
        </div>
      </div>

      {/* Right: 5G, Wi-Fi, Battery & Top Corner Desktop Switch */}
      <div className="flex items-center space-x-2">
        <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/40 px-1 rounded">5G</span>
        <Wifi className="w-3 h-3 text-white" />
        <div className="flex items-center space-x-0.5">
          <span className="text-[10px] font-medium text-white">96%</span>
          <BatteryMedium className="w-3.5 h-3.5 text-white" />
        </div>
        {onDesktopSwitch && (
          <button
            onClick={onDesktopSwitch}
            className="ml-1 px-1.5 py-0.5 rounded-md bg-[#181C24] hover:bg-[#00E5FF] text-[#00E5FF] hover:text-black flex items-center space-x-1 font-bold text-[9px] border border-white/10 transition-colors"
            title="Switch to Desktop Mode"
          >
            <Monitor className="w-2.5 h-2.5" />
            <span>PC</span>
          </button>
        )}
      </div>
    </div>
  );
};

interface AndroidBottomBarProps {
  onBack?: () => void;
  onHome?: () => void;
  onRecents?: () => void;
}

export const AndroidBottomBar: React.FC<AndroidBottomBarProps> = ({
  onBack,
  onHome,
  onRecents,
}) => {
  return (
    <div className="w-full h-10 bg-black border-t border-[#14171C] flex items-center justify-around text-[#9AA4AF] select-none z-50 px-8">
      {/* Android Back Button ◀ */}
      <button
        onClick={onBack}
        className="w-10 h-8 flex items-center justify-center hover:text-white active:scale-90 transition-all"
        title="Android Back"
        aria-label="Android Back"
      >
        <Triangle className="w-3.5 h-3.5 -rotate-90 fill-current" />
      </button>

      {/* Android Home Button ● */}
      <button
        onClick={onHome}
        className="w-10 h-8 flex items-center justify-center hover:text-white active:scale-90 transition-all"
        title="Android Home"
        aria-label="Android Home"
      >
        <Circle className="w-3.5 h-3.5 border border-current rounded-full" />
      </button>

      {/* Android Recents / App Switcher ◼ */}
      <button
        onClick={onRecents}
        className="w-10 h-8 flex items-center justify-center hover:text-white active:scale-90 transition-all"
        title="Android App Switcher / Sessions"
        aria-label="Android Recents"
      >
        <Square className="w-3.5 h-3.5 border border-current rounded-sm" />
      </button>
    </div>
  );
};
