import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Volume2,
  VolumeX,
  Send,
  X,
  Bot,
  User,
  Zap,
  HelpCircle,
  Scissors,
  Music,
  Shield,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { GuideMessage } from '../types';
import { api } from '../services/api';

interface ZeyeSentinelGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCapCut?: () => void;
  onOpenMusicLibrary?: () => void;
  onOpenAiStudio?: () => void;
}

const DEFAULT_QUESTIONS = [
  'Zero-MB data saving feature kaise kaam karta hai?',
  'CapCut Pro editor me video split aur speed curve kaise use kare?',
  'Post me collaboration aur dosto ko tag kaise kare?',
  '4K 60FPS vs 120FPS me kaise export kare?',
  'AI se photos aur videos kaise generate kare?',
  'Single device lock kya hai aur kaise protect karta hai?',
];

export const ZeyeSentinelGuideModal: React.FC<ZeyeSentinelGuideModalProps> = ({
  isOpen,
  onClose,
  onOpenCapCut,
  onOpenMusicLibrary,
  onOpenAiStudio,
}) => {
  const [messages, setMessages] = useState<GuideMessage[]>([
    {
      id: 'msg-welcome',
      role: 'assistant',
      text: `**Namaste! Main Z-eye Sentinel AI Assistant hoon.** 🎙️✨\n\nAap mujhse Z-eye app ke kisi bhi feature ke baare me pooch sakte hain:\n- ✂️ **CapCut Pro Editing**: Multi-track timeline, Split, Speed ramps, aur LUTs\n- 🚀 **Export Settings**: 4K 60FPS, 120FPS, aur AV1 Zero-MB compression\n- 🎵 **Z-eye Music Library**: Trending Phonk, Desi Lofi, aur AI music maestro\n- 🤝 **Collaboration & Tagging**: Post me co-author aur tagging\n- 🎨 **AI Photo & Video Studio**: AI generation\n- 🔒 **Single Device Lock**: Anti-hijack hardware security\n\n*Neeche diye gaye questions par tap karein ya apna sawaal likhein!*`,
      speechText:
        'Namaste! Main Z-eye ka AI assistant hoon. Aap mujhse CapCut editor, music library, 4K export, ya kisi bhi feature ke baare me pooch sakte hain.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputQuestion, setInputQuestion] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  // Clean up speech on modal close
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  if (!isOpen) return null;

  // Speak text aloud using Web Speech API
  const speakText = (text: string) => {
    if (!isVoiceEnabled || !('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    // Look for Indian English or Hindi voice if available
    const voices = window.speechSynthesis.getVoices();
    const hindiVoice = voices.find((v) => v.lang.includes('hi') || v.name.includes('India') || v.lang.includes('IN'));
    if (hindiVoice) {
      utterance.voice = hindiVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSendQuestion = async (qText?: string) => {
    const query = (qText || inputQuestion).trim();
    if (!query || isLoading) return;

    stopSpeaking();

    const userMsg: GuideMessage = {
      id: `msg-${Date.now()}-u`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuestion('');
    setIsLoading(true);

    try {
      const res = await api.askAppGuide(query, 'hinglish');
      const botMsg: GuideMessage = {
        id: `msg-${Date.now()}-b`,
        role: 'assistant',
        text: res.answer,
        speechText: res.speechText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);

      // Voice speech trigger
      if (res.speechText && isVoiceEnabled) {
        speakText(res.speechText);
      }
    } catch (e) {
      const fallbackMsg: GuideMessage = {
        id: `msg-${Date.now()}-err`,
        role: 'assistant',
        text: 'Z-eye me AV1 neural compression engine aur CapCut Pro editing tools lagaye gaye hain jisse aap 4K 60FPS me edit karke bina data kharch kiye stream kar sakte hain!',
        speechText: 'Z-eye me AV1 compression aur CapCut Pro tools lagaye gaye hain jisse bina data kharch kiye HD streams play hoti hain.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div
        className="w-full max-w-xl bg-[#0B0D10] border border-[#1E232B] rounded-2xl overflow-hidden shadow-2xl shadow-cyan-950/40 flex flex-col h-[85vh] max-h-[700px]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#14171C] flex items-center justify-between bg-gradient-to-r from-black via-[#0E1116] to-black">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
              <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                <Bot className="w-5 h-5 text-[#00E5FF]" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white">Z-eye AI Voice & App Guide</h2>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30 font-mono">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-[11px] text-[#9AA4AF]">Ask any question about Z-eye features in Hindi or English</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Voice Mute/Unmute Toggle */}
            <button
              onClick={() => {
                if (isVoiceEnabled) {
                  stopSpeaking();
                  setIsVoiceEnabled(false);
                } else {
                  setIsVoiceEnabled(true);
                }
              }}
              className={`p-2 rounded-lg border transition-all flex items-center space-x-1 text-xs ${
                isVoiceEnabled
                  ? 'bg-[#00E5FF]/15 border-[#00E5FF]/40 text-[#00E5FF]'
                  : 'bg-[#14171C] border-[#222730] text-[#6C7684]'
              }`}
              title={isVoiceEnabled ? 'Voice response enabled (Click to mute)' : 'Voice response muted'}
            >
              {isVoiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              onClick={() => {
                stopSpeaking();
                onClose();
              }}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#14171C] hover:bg-[#222730] text-[#9AA4AF] hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Launch Action Ribbon */}
        <div className="px-4 py-2 bg-[#08090C] border-b border-[#14171C] flex items-center space-x-2 overflow-x-auto scrollbar-none">
          {onOpenCapCut && (
            <button
              onClick={() => {
                onClose();
                onOpenCapCut();
              }}
              className="px-2.5 py-1 rounded-lg bg-[#14171C] hover:bg-[#1E242E] text-cyan-300 border border-[#222730] text-[11px] font-semibold flex items-center space-x-1 whitespace-nowrap transition-colors"
            >
              <Scissors className="w-3 h-3 text-[#00E5FF]" />
              <span>CapCut Editor</span>
            </button>
          )}

          {onOpenMusicLibrary && (
            <button
              onClick={() => {
                onClose();
                onOpenMusicLibrary();
              }}
              className="px-2.5 py-1 rounded-lg bg-[#14171C] hover:bg-[#1E242E] text-purple-300 border border-[#222730] text-[11px] font-semibold flex items-center space-x-1 whitespace-nowrap transition-colors"
            >
              <Music className="w-3 h-3 text-[#7C4DFF]" />
              <span>Music Library</span>
            </button>
          )}

          {onOpenAiStudio && (
            <button
              onClick={() => {
                onClose();
                onOpenAiStudio();
              }}
              className="px-2.5 py-1 rounded-lg bg-[#14171C] hover:bg-[#1E242E] text-emerald-300 border border-[#222730] text-[11px] font-semibold flex items-center space-x-1 whitespace-nowrap transition-colors"
            >
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>AI Photo/Video Studio</span>
            </button>
          )}

          {isSpeaking && (
            <button
              onClick={stopSpeaking}
              className="px-2.5 py-1 rounded-lg bg-rose-950/40 text-rose-300 border border-rose-500/40 text-[10px] font-bold flex items-center space-x-1 animate-pulse"
            >
              <VolumeX className="w-3 h-3" />
              <span>Stop Speaking</span>
            </button>
          )}
        </div>

        {/* Chat History Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start space-x-2.5 ${
                m.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                  m.role === 'user'
                    ? 'bg-[#7C4DFF] text-white'
                    : 'bg-black border border-[#00E5FF]/40 text-[#00E5FF]'
                }`}
              >
                {m.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[#7C4DFF] text-white rounded-tr-none'
                    : 'bg-[#12161E] text-[#DCE2EA] border border-[#1E232B] rounded-tl-none space-y-1.5'
                }`}
              >
                {m.role === 'assistant' ? (
                  <div className="space-y-1.5">
                    <div className="whitespace-pre-line">{m.text}</div>
                    {m.speechText && isVoiceEnabled && (
                      <div className="pt-1.5 flex items-center space-x-2 border-t border-[#1C212A]">
                        <button
                          onClick={() => speakText(m.speechText!)}
                          className="text-[10px] text-[#00E5FF] hover:underline flex items-center space-x-1"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>Voice replay</span>
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <span>{m.text}</span>
                )}
                <div className="text-[9px] text-[#8492A6] mt-1 text-right">{m.timestamp}</div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-start space-x-2.5">
              <div className="w-7 h-7 rounded-lg bg-black border border-[#00E5FF]/40 text-[#00E5FF] flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 animate-spin" />
              </div>
              <div className="bg-[#12161E] border border-[#1E232B] rounded-2xl rounded-tl-none p-3 text-xs text-[#9AA4AF] flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" />
                <span>Z-eye AI thinking & synthesizing voice...</span>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Suggested Quick Questions Chips */}
        <div className="px-4 py-2 border-t border-[#14171C] bg-[#090B0E]">
          <div className="text-[10px] text-[#6C7684] uppercase font-mono mb-1.5">Quick Questions:</div>
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
            {DEFAULT_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuestion(q)}
                className="px-2.5 py-1 rounded-full bg-[#14171C] hover:bg-[#1E232B] border border-[#222730] hover:border-[#00E5FF]/40 text-[#9AA4AF] hover:text-white text-[11px] whitespace-nowrap transition-all active:scale-95"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Query Input Box */}
        <div className="p-3 bg-[#0A0C10] border-t border-[#14171C] flex items-center space-x-2">
          <input
            type="text"
            value={inputQuestion}
            onChange={(e) => setInputQuestion(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendQuestion();
            }}
            placeholder="Kuchh bhi poochhein Z-eye app ke baare me (Hindi / English)..."
            className="flex-1 px-3.5 py-2.5 bg-[#14171C] border border-[#222730] rounded-xl text-xs text-white placeholder-[#6C7684] focus:outline-none focus:border-[#00E5FF]"
          />
          <button
            onClick={() => handleSendQuestion()}
            disabled={!inputQuestion.trim() || isLoading}
            className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white flex items-center justify-center shadow-md shadow-[#00E5FF]/20 hover:brightness-110 active:scale-95 disabled:opacity-40 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
