import React, { useState } from 'react';
import {
  Sparkles,
  Camera,
  Film,
  Wand2,
  X,
  Check,
  Download,
  Scissors,
  Share2,
  RefreshCw,
  Layers,
  Zap,
} from 'lucide-react';
import { AiMediaGenerationResult } from '../types';
import { api } from '../services/api';

interface ZeyeAiStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUseInPost: (media: { url: string; type: 'photo' | 'video'; caption?: string; aspectRatio: '9:16' | '1:1' | '16:9' | '4:5' }) => void;
  onOpenInCapCut?: (media: { url: string; type: 'photo' | 'video'; aspectRatio: '9:16' | '1:1' | '16:9' | '4:5' }) => void;
}

const PHOTO_STYLES = [
  { id: 'cyberpunk', label: '⚡ Cyberpunk AMOLED', desc: 'Neon lasers against 0-nit true black darkness' },
  { id: 'photoreal', label: '📸 8K Photorealism', desc: 'Hyper-realistic cinematic camera lens' },
  { id: 'pixar', label: '🎨 3D Unreal Engine 5', desc: 'Stylized 3D character & dynamic lighting' },
  { id: 'noir', label: '🌑 High-Contrast Noir', desc: 'Deep monochrome shadows and rim light' },
  { id: 'anime', label: '🌸 Makoto Shinkai Anime', desc: 'Vibrant sunset sky & atmospheric clouds' },
];

const VIDEO_MOTIONS = [
  { id: 'neon_flythrough', label: '⚡ Tokyo Neon Flythrough', desc: 'High-speed drone through rainy illuminated streets' },
  { id: 'liquid_hologram', label: '🔮 Holographic Cyber City', desc: 'Floating futuristic vehicles and neon skyscrapers' },
  { id: 'speed_trail', label: '🏎️ Hyperspeed Light Trail', desc: 'Dynamic hyper-lapse motion blur' },
];

export const ZeyeAiStudioModal: React.FC<ZeyeAiStudioModalProps> = ({
  isOpen,
  onClose,
  onUseInPost,
  onOpenInCapCut,
}) => {
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('photo');
  const [prompt, setPrompt] = useState<string>('Cyberpunk supercar cruising through rainy neo-Tokyo street with neon reflections');
  const [selectedStyle, setSelectedStyle] = useState<string>('cyberpunk');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '1:1' | '16:9' | '4:5'>('9:16');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedResult, setGeneratedResult] = useState<AiMediaGenerationResult | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);

    try {
      const res = await api.generateAiMedia({
        type: mediaType,
        prompt,
        style: selectedStyle,
        aspectRatio,
      });

      if (res && res.url) {
        setGeneratedResult(res);
      }
    } catch (e) {
      console.error('AI Generation error:', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUseForPost = () => {
    if (!generatedResult) return;
    onUseInPost({
      url: generatedResult.url,
      type: generatedResult.type,
      caption: generatedResult.captionDraft,
      aspectRatio: generatedResult.aspectRatio,
    });
    onClose();
  };

  const handleOpenCapCut = () => {
    if (!generatedResult || !onOpenInCapCut) return;
    onOpenInCapCut({
      url: generatedResult.url,
      type: generatedResult.type,
      aspectRatio: generatedResult.aspectRatio,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div
        className="w-full max-w-2xl bg-[#0B0D10] border border-[#1E232B] rounded-2xl overflow-hidden shadow-2xl shadow-cyan-950/40 flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#14171C] flex items-center justify-between bg-gradient-to-r from-black via-[#0E1116] to-black">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
              <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-[#00E5FF]" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-white">Z-Studio Dedicated AI Generator</h2>
                <span className="text-[9px] uppercase font-mono px-1.5 py-0.2 rounded bg-gradient-to-r from-purple-900/40 to-cyan-900/40 text-[#00E5FF] border border-[#00E5FF]/30">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-xs text-[#9AA4AF]">
                Generate ultra-high definition AMOLED photos & cinematic short video reels
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#14171C] hover:bg-[#222730] text-[#9AA4AF] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Studio Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Mode Switcher: AI Photo vs AI Video */}
          <div className="grid grid-cols-2 gap-2 bg-[#080A0D] p-1 rounded-xl border border-[#14171C]">
            <button
              onClick={() => {
                setMediaType('photo');
                setPrompt('Cyberpunk supercar cruising through rainy neo-Tokyo street with neon reflections');
              }}
              className={`py-2 rounded-lg text-xs font-bold flex items-center justify-center space-x-2 transition-all ${
                mediaType === 'photo'
                  ? 'bg-[#14171C] text-[#00E5FF] border border-[#00E5FF]/40 shadow-sm'
                  : 'text-[#9AA4AF] hover:text-white'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>📸 AI Photo Generator</span>
            </button>

            <button
              onClick={() => {
                setMediaType('video');
                setPrompt('Vertical 9:16 neon street night drive reel with cinematic motion and lens flare');
                setAspectRatio('9:16');
              }}
              className={`py-2 rounded-lg text-xs font-bold flex items-center justify-center space-x-2 transition-all ${
                mediaType === 'video'
                  ? 'bg-gradient-to-r from-[#7C4DFF]/20 to-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/50 shadow-sm'
                  : 'text-[#9AA4AF] hover:text-white'
              }`}
            >
              <Film className="w-4 h-4 text-[#00E5FF]" />
              <span>🎬 AI Video / Reel Generator</span>
            </button>
          </div>

          {/* Prompt Box */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-semibold text-white flex items-center space-x-1.5">
                <Wand2 className="w-3.5 h-3.5 text-[#00E5FF]" />
                <span>Creative Prompt:</span>
              </label>
              <span className="text-[10px] text-[#6C7684]">Be as detailed as you like</span>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                mediaType === 'photo'
                  ? 'Describe the photo in detail (e.g. AMOLED cybernetic portrait with cyan neon lighting, 8k resolution)...'
                  : 'Describe the short video motion (e.g. Flying drone shot through futuristic Tokyo neon rain, 9:16 vertical reel)...'
              }
              className="w-full h-20 px-3.5 py-2.5 bg-[#14171C] border border-[#222730] rounded-xl text-xs text-white placeholder-[#6C7684] focus:outline-none focus:border-[#00E5FF] resize-none"
            />
          </div>

          {/* Style Presets */}
          <div>
            <label className="text-xs font-semibold text-[#9AA4AF] block mb-1.5">
              {mediaType === 'photo' ? 'Artistic Style & Aesthetic:' : 'Motion & Camera Dynamic:'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(mediaType === 'photo' ? PHOTO_STYLES : VIDEO_MOTIONS).map((st) => (
                <button
                  key={st.id}
                  onClick={() => setSelectedStyle(st.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    selectedStyle === st.id
                      ? 'bg-[#1E232B] border-[#00E5FF] text-white shadow-md shadow-[#00E5FF]/20'
                      : 'bg-[#0E1116] border-[#181C22] text-[#9AA4AF] hover:text-white'
                  }`}
                >
                  <div className="text-xs font-bold text-white truncate">{st.label}</div>
                  <div className="text-[10px] text-[#8492A6] truncate mt-0.5">{st.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio Picker */}
          <div>
            <label className="text-xs font-semibold text-[#9AA4AF] block mb-1.5">
              Format & Aspect Ratio:
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: '9:16', label: '9:16 Reel' },
                { id: '1:1', label: '1:1 Square' },
                { id: '16:9', label: '16:9 Cinema' },
                { id: '4:5', label: '4:5 Portrait' },
              ].map((r) => (
                <button
                  key={r.id}
                  onClick={() => setAspectRatio(r.id as any)}
                  className={`py-2 rounded-xl text-xs font-semibold transition-all ${
                    aspectRatio === r.id
                      ? 'bg-[#00E5FF] text-black font-bold shadow-md shadow-[#00E5FF]/20'
                      : 'bg-[#14171C] text-[#9AA4AF] hover:text-white border border-[#222730]'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow-xl shadow-[#00E5FF]/25 hover:brightness-110 active:scale-98 disabled:opacity-40 transition-all"
          >
            {isGenerating ? (
              <>
                <Wand2 className="w-4 h-4 animate-spin" />
                <span>Generating {mediaType === 'video' ? 'AI Video Reel' : '8K AI Photo'} with Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate {mediaType === 'video' ? 'AI Video' : 'AI Photo'} Now</span>
              </>
            )}
          </button>

          {/* Generated Result Showcase */}
          {generatedResult && (
            <div className="p-4 rounded-2xl bg-[#0E1116] border border-[#00E5FF]/50 shadow-2xl shadow-[#00E5FF]/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center space-x-1.5">
                  <Check className="w-4 h-4 text-[#00E5FF]" />
                  <span>AI Generation Complete!</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/30">
                  {generatedResult.type.toUpperCase()} • {generatedResult.aspectRatio}
                </span>
              </div>

              {/* Media Preview Box */}
              <div className="w-full max-h-72 rounded-xl overflow-hidden bg-black border border-[#222730] flex items-center justify-center">
                {generatedResult.type === 'video' ? (
                  <video
                    src={generatedResult.url}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="max-h-72 w-auto object-contain"
                  />
                ) : (
                  <img
                    src={generatedResult.url}
                    alt={generatedResult.prompt}
                    className="max-h-72 w-auto object-contain"
                  />
                )}
              </div>

              {/* Enhanced Prompt & Caption */}
              {generatedResult.captionDraft && (
                <div className="p-2.5 rounded-xl bg-[#14171C] border border-[#222730] text-xs text-[#DCE2EA]">
                  <span className="text-[#00E5FF] font-semibold block mb-0.5">Suggested Caption:</span>
                  <p>{generatedResult.captionDraft}</p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                {onOpenInCapCut && (
                  <button
                    onClick={handleOpenCapCut}
                    className="py-2.5 px-3 rounded-xl bg-[#1A202A] hover:bg-[#252E3C] border border-[#00E5FF]/40 text-cyan-300 text-xs font-bold flex items-center justify-center space-x-2 transition-all"
                  >
                    <Scissors className="w-4 h-4 text-[#00E5FF]" />
                    <span>Open in CapCut Pro Editor</span>
                  </button>
                )}

                <button
                  onClick={handleUseForPost}
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow-lg shadow-[#00E5FF]/20 hover:brightness-110 transition-all"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Post Directly to Feed</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
