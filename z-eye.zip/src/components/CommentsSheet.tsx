import React, { useState, useEffect } from 'react';
import { Post, Comment } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Heart, Reply, Send, X, CornerDownRight } from 'lucide-react';

interface CommentsSheetProps {
  post: Post | null;
  onClose: () => void;
  onCommentAdded?: () => void;
}

export const CommentsSheet: React.FC<CommentsSheetProps> = ({ post, onClose, onCommentAdded }) => {
  const { currentUser } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ id: string; username: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!post) return;
    loadComments();
  }, [post?.id]);

  const loadComments = async () => {
    if (!post) return;
    setLoading(true);
    try {
      const res = await api.getComments(post.id, currentUser?.id || '');
      setComments(res.comments || []);
    } catch (err) {
      console.error('Error fetching comments:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !post || !currentUser || submitting) return;

    setSubmitting(true);
    const textToSend = commentText.trim();
    const parentIdToSend = replyingTo ? replyingTo.id : null;

    // Optimistic comment insert
    const tempComment: Comment = {
      id: `temp-${Date.now()}`,
      postId: post.id,
      userId: currentUser.id,
      user: {
        id: currentUser.id,
        username: currentUser.username,
        displayName: currentUser.displayName,
        avatarUrl: currentUser.avatarUrl,
      },
      text: textToSend,
      parentId: parentIdToSend,
      likesCount: 0,
      hasLiked: false,
      replies: [],
      createdAt: new Date().toISOString(),
    };

    if (parentIdToSend) {
      setComments((prev) =>
        prev.map((c) => {
          if (c.id === parentIdToSend) {
            return { ...c, replies: [...(c.replies || []), tempComment] };
          }
          return c;
        })
      );
    } else {
      setComments((prev) => [...prev, tempComment]);
    }

    setCommentText('');
    setReplyingTo(null);

    try {
      const res = await api.addComment(post.id, currentUser.id, textToSend, parentIdToSend);
      if (res.success) {
        onCommentAdded?.();
        // Reload real IDs silently
        loadComments();
      }
    } catch (err) {
      console.error('Failed to post comment:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!post) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex flex-col justify-end animate-in fade-in">
      <div
        className="w-full max-w-2xl mx-auto bg-[#0B0D10] border-t border-x border-[#14171C] rounded-t-3xl max-h-[85vh] h-[650px] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-4 py-3 border-b border-[#14171C] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-sm text-white">Threaded Comments</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#14171C] text-[#9AA4AF] font-mono">
              {comments.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#9AA4AF] hover:text-white hover:bg-[#14171C]"
            aria-label="Close comments"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Replying banner */}
        {replyingTo && (
          <div className="px-4 py-1.5 bg-[#14171C] flex items-center justify-between text-xs text-[#00E5FF]">
            <div className="flex items-center space-x-1.5">
              <CornerDownRight className="w-3.5 h-3.5" />
              <span>Replying to @{replyingTo.username}</span>
            </div>
            <button
              onClick={() => setReplyingTo(null)}
              className="text-[#9AA4AF] hover:text-white"
            >
              Cancel
            </button>
          </div>
        )}

        {/* Comments Scrollable Area */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          {loading ? (
            <div className="flex items-center justify-center h-40 text-xs text-[#9AA4AF]">
              Loading comments...
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-center text-[#9AA4AF]">
              <p className="text-sm font-semibold text-white">No comments yet</p>
              <p className="text-xs mt-1">Start the conversation on Z-eye.</p>
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="space-y-2">
                {/* Main Comment */}
                <div className="flex items-start space-x-3 group">
                  <img
                    src={comment.user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                    alt={comment.user.username}
                    className="w-8 h-8 rounded-full object-cover shrink-0 border border-[#222730]"
                  />
                  <div className="flex-1 text-xs">
                    <div className="flex items-baseline space-x-2">
                      <span className="font-bold text-[#F5F7FA]">@{comment.user.username}</span>
                      <span className="text-[10px] text-[#9AA4AF]">
                        {new Date(comment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="mt-0.5 text-[#F5F7FA] leading-relaxed">{comment.text}</p>
                    <div className="flex items-center space-x-3 mt-1.5 text-[11px] text-[#9AA4AF]">
                      <button
                        onClick={() =>
                          setReplyingTo({ id: comment.id, username: comment.user.username })
                        }
                        className="hover:text-[#00E5FF] font-medium"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                  <button className="text-[#9AA4AF] hover:text-rose-500 pt-1">
                    <Heart className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Indented Thread Replies */}
                {comment.replies && comment.replies.length > 0 && (
                  <div className="pl-8 space-y-2 border-l border-[#222730] ml-4">
                    {comment.replies.map((reply) => (
                      <div key={reply.id} className="flex items-start space-x-2.5">
                        <img
                          src={reply.user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={reply.user.username}
                          className="w-6 h-6 rounded-full object-cover shrink-0 border border-[#222730]"
                        />
                        <div className="flex-1 text-xs">
                          <div className="flex items-baseline space-x-1.5">
                            <span className="font-bold text-[#F5F7FA]">@{reply.user.username}</span>
                            <span className="text-[10px] text-[#9AA4AF]">
                              {new Date(reply.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="mt-0.5 text-[#F5F7FA] leading-relaxed">{reply.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSendComment} className="p-3 border-t border-[#14171C] bg-black flex items-center space-x-2">
          <input
            type="text"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder={replyingTo ? `Reply to @${replyingTo.username}...` : 'Add a comment...'}
            className="flex-1 bg-[#14171C] border border-[#222730] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-[#9AA4AF] focus:outline-none focus:border-[#00E5FF]"
          />
          <button
            type="submit"
            disabled={!commentText.trim() || submitting}
            className="w-10 h-10 rounded-xl bg-[#00E5FF] hover:bg-[#00E5FF]/90 text-black flex items-center justify-center font-bold disabled:opacity-40 transition-opacity"
            aria-label="Send comment"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
