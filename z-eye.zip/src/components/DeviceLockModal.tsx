import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Shield, Smartphone, AlertTriangle, LogOut, CheckCircle2, RefreshCw, X, Radio } from 'lucide-react';

interface DeviceLockModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SIMULATED_DEVICES = [
  'Samsung Galaxy S25 Ultra (AMOLED)',
  'Google Pixel 9 Pro (Pure Black)',
  'OnePlus 13 (120Hz Pro)',
  'Xiaomi 15 Ultra (AMOLED)',
  'Sony Xperia 1 VI (4K OLED)',
];

export const DeviceLockModal: React.FC<DeviceLockModalProps> = ({ isOpen, onClose }) => {
  const {
    currentUser,
    deviceId,
    deviceModel,
    updateDeviceModel,
    takeoverPrompt,
    resolveTakeover,
  } = useAuth();

  const [sessions, setSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && currentUser) {
      loadSessions();
    }
  }, [isOpen, currentUser?.id]);

  const loadSessions = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const res = await api.getSessions(currentUser.id);
      setSessions(res.sessions || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoteLogout = async (sessId: string) => {
    await api.terminateSession(sessId);
    loadSessions();
  };

  if (!isOpen && !takeoverPrompt?.isOpen) return null;

  // 1. Takeover Challenge Prompt (When logging in on a new device while an existing device is active)
  if (takeoverPrompt?.isOpen) {
    const existing = takeoverPrompt.existingDevice;
    return (
      <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
        <div className="w-full max-w-md bg-[#0B0D10] border border-amber-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
          <div className="flex items-center space-x-3 text-amber-400">
            <div className="p-2.5 rounded-full bg-amber-400/10 border border-amber-400/20">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">Single-Device Lock Engaged</h3>
              <p className="text-xs text-amber-400">Sign out your other device?</p>
            </div>
          </div>

          <p className="text-xs text-[#9AA4AF] leading-relaxed">
            Z-eye enforces a strict Single-Device Lock (Requirement D). Your account has an active session on another device:
          </p>

          {existing && (
            <div className="p-3.5 rounded-xl bg-[#14171C] border border-[#222730] text-xs space-y-1.5 font-mono">
              <div className="text-white font-bold flex items-center space-x-1.5">
                <Smartphone className="w-4 h-4 text-[#00E5FF]" />
                <span>{existing.deviceModel}</span>
              </div>
              <div className="text-[11px] text-[#9AA4AF]">
                Location: <span className="text-white">{existing.locationCity || 'Tokyo, JP'}</span>
              </div>
              <div className="text-[11px] text-[#9AA4AF]">
                IP Address: <span className="text-white">{existing.ipAddress}</span>
              </div>
              <div className="text-[11px] text-[#9AA4AF]">
                Last Active: <span className="text-white">{new Date(existing.lastActive).toLocaleTimeString()}</span>
              </div>
            </div>
          )}

          <p className="text-[11px] text-[#9AA4AF]">
            Continuing will revoke the old session in one atomic transaction and push a forced-logout event to that device.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => resolveTakeover(false)}
              className="py-2.5 rounded-xl bg-[#14171C] hover:bg-[#222730] text-xs font-semibold text-white"
            >
              Cancel Login
            </button>
            <button
              onClick={() => resolveTakeover(true)}
              className="py-2.5 rounded-xl bg-[#00E5FF] hover:bg-[#00E5FF]/90 text-xs font-extrabold text-black shadow-lg shadow-[#00E5FF]/20"
            >
              Sign Out & Continue
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Active Sessions Manager Modal (Feature 63)
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="w-full max-w-lg bg-[#0B0D10] border border-[#222730] rounded-2xl p-5 shadow-2xl flex flex-col max-h-[85vh] space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#14171C]">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-[#00E5FF]" />
            <div>
              <h3 className="font-bold text-sm text-white">Login Activity & Active Sessions</h3>
              <p className="text-[10px] text-[#00E5FF] font-mono">1 Account = 1 Active Device Policy</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#9AA4AF] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Device Card */}
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#00E5FF]/10 to-[#7C4DFF]/10 border border-[#00E5FF]/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Smartphone className="w-4 h-4 text-[#00E5FF]" />
              <span className="font-bold text-xs text-white">This Device (Current Session)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>ACTIVE</span>
            </span>
          </div>
          <p className="text-xs font-semibold text-white mt-1">{deviceModel}</p>
          <p className="text-[11px] text-[#9AA4AF] font-mono mt-0.5">Device ID: {deviceId}</p>
        </div>

        {/* Device Simulator Switcher (Handy for testing Single-Device Lock takeover!) */}
        <div className="p-3 rounded-xl bg-[#14171C] border border-[#222730] text-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#9AA4AF] font-medium">Simulate Hardware Device Model:</span>
            <RefreshCw className="w-3 h-3 text-[#00E5FF]" />
          </div>
          <select
            value={deviceModel}
            onChange={(e) => updateDeviceModel(e.target.value)}
            className="w-full bg-[#0B0D10] border border-[#222730] rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#00E5FF]"
          >
            {SIMULATED_DEVICES.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        {/* Active Sessions List */}
        <div className="flex-1 overflow-y-auto space-y-2">
          <div className="text-[11px] font-bold text-[#9AA4AF] uppercase tracking-wider">
            Registered Sessions ({sessions.length})
          </div>

          {loading ? (
            <div className="text-xs text-[#9AA4AF] py-4 text-center">Loading sessions...</div>
          ) : sessions.length === 0 ? (
            <div className="text-xs text-[#9AA4AF] py-4 text-center">No active sessions found.</div>
          ) : (
            sessions.map((sess) => (
              <div
                key={sess.id}
                className="p-3 rounded-xl bg-[#14171C] border border-[#222730] flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white">{sess.deviceModel}</span>
                    {sess.isCurrentDevice && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF] font-mono">
                        THIS DEVICE
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-[#9AA4AF] mt-0.5 font-mono">
                    {sess.locationCity} • {sess.ipAddress} • {new Date(sess.lastActive).toLocaleTimeString()}
                  </div>
                </div>

                {!sess.isCurrentDevice && (
                  <button
                    onClick={() => handleRemoteLogout(sess.id)}
                    className="px-2.5 py-1 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 text-[11px] font-semibold transition-colors flex items-center space-x-1"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>Revoke</span>
                  </button>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer Note */}
        <div className="pt-2 border-t border-[#14171C] flex items-center justify-between text-[11px] text-[#9AA4AF]">
          <span>OWASP MASVS Device Binding Verified</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#222730] text-white hover:bg-white hover:text-black font-semibold text-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
