import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { PlatformMode, DeviceHardwareProfile, DeviceOptimizationResult } from '../types';
import {
  Cpu,
  Smartphone,
  Laptop,
  Monitor,
  Sparkles,
  Download,
  Zap,
  CheckCircle2,
  HardDrive,
  Wifi,
  Layers,
  BatteryCharging,
  X,
  RefreshCw,
  Sliders,
  ShieldCheck,
  Check,
  MessageSquare,
} from 'lucide-react';

interface DeviceOptimizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlatformMode: PlatformMode;
  onPlatformChange: (mode: PlatformMode) => void;
}

export const DeviceOptimizerModal: React.FC<DeviceOptimizerModalProps> = ({
  isOpen,
  onClose,
  currentPlatformMode,
  onPlatformChange,
}) => {
  const [detectedProfile, setDetectedProfile] = useState<DeviceHardwareProfile | null>(null);
  const [optimizationResult, setOptimizationResult] = useState<DeviceOptimizationResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [installedSuccess, setInstalledSuccess] = useState(false);

  // User Interactive Toggles
  const [ultraDataSaver, setUltraDataSaver] = useState(true);
  const [amoledTrueBlack, setAmoledTrueBlack] = useState(true);
  const [highRefreshRate, setHighRefreshRate] = useState(true);
  const [activeQuestion, setActiveQuestion] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      scanAndOptimizeDevice();
    }
  }, [isOpen, currentPlatformMode]);

  const scanAndOptimizeDevice = async () => {
    setLoading(true);
    setInstalledSuccess(false);

    // Collect real client environment metrics
    const ua = navigator.userAgent.toLowerCase();
    let detectedOS: 'android' | 'ios' | 'windows' | 'mac' | 'other' = 'android';
    let modelName = 'Samsung Galaxy S24 Ultra (AMOLED)';

    if (currentPlatformMode === 'ios' || ua.includes('iphone') || ua.includes('ipad')) {
      detectedOS = 'ios';
      modelName = 'Apple iPhone 16 Pro (Super Retina XDR)';
    } else if (currentPlatformMode === 'mac' || ua.includes('macintosh') || ua.includes('mac os')) {
      detectedOS = 'mac';
      modelName = 'Apple MacBook Pro (Liquid Retina Metal 3)';
    } else if (currentPlatformMode === 'desktop' || ua.includes('windows')) {
      detectedOS = 'windows';
      modelName = 'Windows 11 PC (High-DPI Multi-Monitor)';
    } else {
      detectedOS = 'android';
      modelName = 'Samsung Galaxy / Google Pixel (Dynamic AMOLED)';
    }

    const screenW = window.screen.width || 1080;
    const screenH = window.screen.height || 2400;
    const dpr = window.devicePixelRatio || 2.625;
    const cores = navigator.hardwareConcurrency || 8;
    const memory = (navigator as any).deviceMemory || 8;
    const conn = (navigator as any).connection?.effectiveType || '5G Ultra-Wideband';
    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    const profile: DeviceHardwareProfile = {
      os: detectedOS,
      deviceModel: modelName,
      screenWidth: screenW,
      screenHeight: screenH,
      pixelRatio: Math.round(dpr * 10) / 10,
      colorDepth: window.screen.colorDepth || 24,
      isAmoledCapable: true,
      refreshRateHz: 120,
      cpuCores: cores,
      memoryGB: memory,
      connectionType: conn,
      isTouchScreen: isTouch,
    };

    setDetectedProfile(profile);

    try {
      const result = await api.aiOptimizeDevice(profile);
      setOptimizationResult(result);
    } catch (err) {
      console.error('Device optimizer failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadOptimizedPackage = () => {
    if (!detectedProfile) return;
    setDownloading(true);
    setDownloadProgress(0);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setDownloading(false);
          setInstalledSuccess(true);
          // Trigger actual file download
          const target = detectedProfile.os;
          window.location.href = `/api/download/package/${target}`;
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div
        className="w-full max-w-2xl bg-[#0B0D10] border border-[#222730] rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#14171C] flex items-center justify-between bg-[#0E1116]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#7C4DFF] to-[#00E5FF] flex items-center justify-center text-black font-extrabold shadow-md shadow-[#00E5FF]/20">
              <Zap className="w-4 h-4 fill-black" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h3 className="font-extrabold text-sm text-white tracking-wide">Z-EYE SENTINEL AI BOT</h3>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#00E5FF]/10 text-[#00E5FF] font-mono font-bold border border-[#00E5FF]/20">
                  DEVICE ADAPTIVE
                </span>
              </div>
              <p className="text-[11px] text-[#9AA4AF]">
                Auto-detected hardware tuning • Zero-MB data saver • Screen-size optimization
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#9AA4AF] hover:text-white hover:bg-[#1C2028]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-[#F5F7FA]">
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-3 text-center">
              <RefreshCw className="w-8 h-8 text-[#00E5FF] animate-spin" />
              <p className="font-bold text-sm text-white">Scanning Client Hardware Architecture...</p>
              <p className="text-[#9AA4AF] text-xs max-w-sm">
                Evaluating screen resolution, GPU shaders, AMOLED pixel depth, and zero-MB neural compression rates.
              </p>
            </div>
          ) : (
            <>
              {/* 1. Hardware Scanner Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-[#14171C] to-[#0E1116] border border-[#222730] relative overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">
                      {detectedProfile?.os === 'android' ? '🤖' : detectedProfile?.os === 'ios' ? '🍏' : detectedProfile?.os === 'mac' ? '🍎' : '💻'}
                    </span>
                    <div>
                      <span className="text-[10px] font-mono text-[#00E5FF] uppercase font-bold tracking-wider">
                        Detected Hardware
                      </span>
                      <h4 className="font-extrabold text-sm text-white">{detectedProfile?.deviceModel}</h4>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1.5 bg-[#0B0D10] px-2.5 py-1 rounded-lg border border-[#222730]">
                    <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-[11px] text-[#9AA4AF] font-mono">{detectedProfile?.connectionType}</span>
                  </div>
                </div>

                {/* Hardware Spec Badges Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
                  <div className="p-2 rounded-lg bg-[#0B0D10]/80 border border-white/5">
                    <span className="text-[#9AA4AF] block text-[10px]">Display Screen</span>
                    <span className="font-bold text-white font-mono">
                      {detectedProfile?.screenWidth}x{detectedProfile?.screenHeight}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-[#0B0D10]/80 border border-white/5">
                    <span className="text-[#9AA4AF] block text-[10px]">DPI & Scale</span>
                    <span className="font-bold text-[#00E5FF] font-mono">{detectedProfile?.pixelRatio}x Retina</span>
                  </div>
                  <div className="p-2 rounded-lg bg-[#0B0D10]/80 border border-white/5">
                    <span className="text-[#9AA4AF] block text-[10px]">Hardware Cores</span>
                    <span className="font-bold text-white font-mono">{detectedProfile?.cpuCores} Cores CPU</span>
                  </div>
                  <div className="p-2 rounded-lg bg-[#0B0D10]/80 border border-white/5">
                    <span className="text-[#9AA4AF] block text-[10px]">Display Refresh</span>
                    <span className="font-bold text-[#7C4DFF] font-mono">120Hz ProMotion</span>
                  </div>
                </div>
              </div>

              {/* 2. Sentinel AI Bot Diagnosis (Hindi & English) */}
              <div className="p-4 rounded-xl bg-[#00E5FF]/5 border border-[#00E5FF]/20 space-y-2.5">
                <div className="flex items-center space-x-2 text-[#00E5FF]">
                  <Sparkles className="w-4 h-4" />
                  <span className="font-extrabold text-xs tracking-wider">AI BOT VERDICT & OPTIMIZATION</span>
                </div>
                <p className="text-white text-xs leading-relaxed font-medium">
                  {optimizationResult?.aiBotVerdictHindi}
                </p>
                <p className="text-[#9AA4AF] text-[11px] leading-relaxed italic border-t border-white/5 pt-2">
                  "{optimizationResult?.aiBotVerdictEnglish}"
                </p>
              </div>

              {/* 3. Zero-MB & High Performance Switches */}
              <div className="space-y-2">
                <h5 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center space-x-2">
                  <Sliders className="w-3.5 h-3.5 text-[#00E5FF]" />
                  <span>Real-Time Device Optimization Controls</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Toggle 1: Zero-MB Data Saver */}
                  <div
                    onClick={() => setUltraDataSaver(!ultraDataSaver)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      ultraDataSaver
                        ? 'bg-[#00E5FF]/10 border-[#00E5FF] shadow-sm shadow-[#00E5FF]/20'
                        : 'bg-[#14171C] border-[#222730] opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs text-white">🚀 Zero-MB Mode</span>
                      <span
                        className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                          ultraDataSaver ? 'bg-[#00E5FF] text-black' : 'bg-gray-700 text-white'
                        }`}
                      >
                        {ultraDataSaver ? '✓' : ''}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#9AA4AF]">
                      Reels take ~0.08 MB to watch. Uploads saved by 97.4% with AV1 neural compression.
                    </p>
                  </div>

                  {/* Toggle 2: AMOLED 0.000 Nits */}
                  <div
                    onClick={() => setAmoledTrueBlack(!amoledTrueBlack)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      amoledTrueBlack
                        ? 'bg-[#7C4DFF]/15 border-[#7C4DFF] shadow-sm shadow-[#7C4DFF]/20'
                        : 'bg-[#14171C] border-[#222730] opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs text-white">🖤 AMOLED True Black</span>
                      <span
                        className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                          amoledTrueBlack ? 'bg-[#7C4DFF] text-white' : 'bg-gray-700 text-white'
                        }`}
                      >
                        {amoledTrueBlack ? '✓' : ''}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#9AA4AF]">
                      Shuts off OLED pixels completely (0.000 nits) to save up to 40% battery life on phones.
                    </p>
                  </div>

                  {/* Toggle 3: 120Hz ProMotion */}
                  <div
                    onClick={() => setHighRefreshRate(!highRefreshRate)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      highRefreshRate
                        ? 'bg-emerald-500/10 border-emerald-500 shadow-sm shadow-emerald-500/20'
                        : 'bg-[#14171C] border-[#222730] opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs text-white">⚡ 120Hz Refresh</span>
                      <span
                        className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                          highRefreshRate ? 'bg-emerald-400 text-black' : 'bg-gray-700 text-white'
                        }`}
                      >
                        {highRefreshRate ? '✓' : ''}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#9AA4AF]">
                      Locks buttery smooth 120 FPS scrolling on Galaxy, iPhone Pro, and 144Hz PC monitors.
                    </p>
                  </div>
                </div>
              </div>

              {/* 4. Interactive Quick Bot Questions */}
              <div className="p-3.5 rounded-xl bg-[#14171C] border border-[#222730] space-y-2">
                <span className="text-[10px] text-[#9AA4AF] font-bold uppercase tracking-wider flex items-center space-x-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-[#00E5FF]" />
                  <span>Ask Sentinel AI Bot (Quick Answers)</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() =>
                      setActiveQuestion(
                        '📱 Screen Size Optimization: Desktop par screen resolution ke hisab se 3-column wide feed auto-scale hota hai. Mobile (Android/iOS) par single-hand bezel compact mode chalu rehta hai!'
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#1F242E] hover:bg-[#2A313E] text-white text-[11px] font-medium transition-colors"
                  >
                    📱 Screen size ke hisab se kaise optimize hua?
                  </button>
                  <button
                    onClick={() =>
                      setActiveQuestion(
                        '⚡ Zero-MB Reel Technology: AV1 micro-vector neural encoding se reel ka original 28 MB compress hoke 0.7 MB ban jata hai, aur viewer stream sirf 0.08 MB leta hai! Sab kuch HD dikhega lekin MB na ke barabar kharch hoga.'
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#1F242E] hover:bg-[#2A313E] text-white text-[11px] font-medium transition-colors"
                  >
                    ⚡ Reels dekhte waqt kitna kam MB lagega?
                  </button>
                  <button
                    onClick={() =>
                      setActiveQuestion(
                        '🔋 Battery Conservation: Z-eye ka background pure #000000 hai. AMOLED screens par black pixel light band kar dete hain, jisse battery 40% tak bachti hai!'
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#1F242E] hover:bg-[#2A313E] text-white text-[11px] font-medium transition-colors"
                  >
                    🔋 Battery kaise bachti hai?
                  </button>
                </div>
                {activeQuestion && (
                  <div className="p-3 rounded-lg bg-black/60 border border-[#00E5FF]/30 text-[#00E5FF] text-xs leading-relaxed animate-in fade-in">
                    {activeQuestion}
                  </div>
                )}
              </div>

              {/* 5. Smart Tailored Download / Install Card */}
              <div className="p-4 rounded-xl bg-gradient-to-b from-[#14171C] to-black border border-[#222730] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider">
                      Tailored Installation Build Ready
                    </span>
                    <h5 className="font-extrabold text-sm text-white">
                      {optimizationResult?.installerPackage.packageName}
                    </h5>
                    <p className="text-[11px] text-[#9AA4AF]">
                      Format: {optimizationResult?.installerPackage.fileFormat} • Size:{' '}
                      <span className="text-white font-bold">{optimizationResult?.installerPackage.fileSizeMB} MB</span>{' '}
                      (Ultra-Lightweight)
                    </p>
                  </div>
                  <span className="px-2 py-1 rounded bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 font-mono text-[10px]">
                    VERIFIED SECURE
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0B0D10] text-[11px] text-[#9AA4AF] space-y-1">
                  <p className="text-white font-medium">Installation Instructions:</p>
                  <p>{optimizationResult?.installerPackage.installGuide}</p>
                </div>

                {/* Download Progress Bar */}
                {downloading && (
                  <div className="space-y-1.5 pt-1">
                    <div className="flex justify-between text-[11px] text-[#9AA4AF]">
                      <span>Generating hardware-optimized build...</span>
                      <span className="text-[#00E5FF] font-bold">{downloadProgress}%</span>
                    </div>
                    <div className="w-full h-2 bg-[#1C2028] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] transition-all duration-200"
                        style={{ width: `${downloadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {installedSuccess && (
                  <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>
                      Package generated & downloaded! Optimized specifically for {detectedProfile?.deviceModel}.
                    </span>
                  </div>
                )}

                <button
                  onClick={handleDownloadOptimizedPackage}
                  disabled={downloading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#7C4DFF] to-[#00E5FF] hover:opacity-95 text-black font-extrabold text-xs tracking-wide shadow-lg shadow-[#00E5FF]/20 flex items-center justify-center space-x-2 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {downloading
                      ? 'Compiling Optimized Binary...'
                      : `Download / Install Optimized Build for ${detectedProfile?.deviceModel} (${optimizationResult?.installerPackage.fileSizeMB} MB)`}
                  </span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
