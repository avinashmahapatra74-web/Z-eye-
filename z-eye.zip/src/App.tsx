import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SyncProvider, useSync } from './context/SyncContext';
import { Post, PlatformMode } from './types';
import { api } from './services/api';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { FeedCard } from './components/FeedCard';
import { CommentsSheet } from './components/CommentsSheet';
import { CreatePostModal } from './components/CreatePostModal';
import { ProfileView } from './components/ProfileView';
import { DeviceLockModal } from './components/DeviceLockModal';
import { DeviceOptimizerModal } from './components/DeviceOptimizerModal';
import { BigFixAIDashboard } from './components/BigFixAIDashboard';
import { SafetyReportModal } from './components/SafetyReportModal';
import { AndroidTopBar, AndroidBottomBar } from './components/AndroidSystemBar';
import { IosTopBar, IosHomeIndicator } from './components/IosSystemBar';
import { DesktopSidebar } from './components/DesktopSidebar';
import { DesktopRightPanel } from './components/DesktopRightPanel';
import { DesktopWindowBar } from './components/DesktopWindowBar';
import { Smartphone, Monitor, ShieldCheck, Compass, Sparkles, Laptop, Shield } from 'lucide-react';

function MainApp() {
  const { currentUser, isForcedLogout, forcedLogoutReason, clearForcedLogout } = useAuth();
  const { subscribe } = useSync();

  const [currentTab, setCurrentTab] = useState<NavTab>('feed');
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState<boolean>(true);

  // Modals & sheets
  const [activeCommentsPost, setActiveCommentsPost] = useState<Post | null>(null);
  const [activeReportPostId, setActiveReportPostId] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isDeviceModalOpen, setIsDeviceModalOpen] = useState<boolean>(false);
  const [isOptimizerModalOpen, setIsOptimizerModalOpen] = useState<boolean>(false);

  // 4 Supported Platforms: android, ios, desktop (Windows), mac (macOS)
  const [platformMode, setPlatformMode] = useState<PlatformMode>('android');

  const isMobile = platformMode === 'android' || platformMode === 'ios';

  // Load feed
  useEffect(() => {
    loadFeed();
  }, [currentUser?.id, selectedTag]);

  // Real-time Database Sync Listeners
  useEffect(() => {
    // 1. Live Likes synchronization
    const unsubLikes = subscribe('LIKE_UPDATED', (payload: { postId: string; likesCount: number; userId: string; hasLiked: boolean }) => {
      setPosts((prev) =>
        prev.map((p) => {
          if (p.id === payload.postId) {
            return {
              ...p,
              likesCount: payload.likesCount,
              hasLiked: payload.userId === currentUser?.id ? payload.hasLiked : p.hasLiked,
            };
          }
          return p;
        })
      );
    });

    // 2. Live Comments synchronization
    const unsubComments = subscribe('COMMENT_ADDED', (payload: { postId: string; commentsCount: number }) => {
      setPosts((prev) =>
        prev.map((p) => {
          if (p.id === payload.postId) {
            return { ...p, commentsCount: payload.commentsCount };
          }
          return p;
        })
      );
    });

    // 3. Live New Post synchronization
    const unsubPosts = subscribe('POST_CREATED', (newPost: Post) => {
      setPosts((prev) => [newPost, ...prev]);
    });

    return () => {
      unsubLikes();
      unsubComments();
      unsubPosts();
    };
  }, [subscribe, currentUser?.id]);

  const loadFeed = async () => {
    setLoadingPosts(true);
    try {
      const res = await api.getFeed(currentUser?.id || 'u-apex', selectedTag);
      setPosts(res.posts || []);
    } catch (err) {
      console.error('Error fetching feed:', err);
    } finally {
      setLoadingPosts(false);
    }
  };

  // Optimistic Like Toggle (Feature 103)
  const handleLikeToggle = async (postId: string) => {
    if (!currentUser) return;

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const newHasLiked = !p.hasLiked;
          return {
            ...p,
            hasLiked: newHasLiked,
            likesCount: newHasLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1),
          };
        }
        return p;
      })
    );

    try {
      await api.toggleLike(postId, currentUser.id);
    } catch (err) {
      console.error('Background like sync failed:', err);
      loadFeed();
    }
  };

  const handleNavSelect = (tab: NavTab) => {
    if (tab === 'create') {
      setIsCreateModalOpen(true);
    } else {
      setCurrentTab(tab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Main Feed & Content renderer
  const renderMainContent = () => (
    <>
      {/* Forced Logout Alert Banner (Single-Device Lock) */}
      {isForcedLogout && (
        <div className="m-4 p-4 rounded-xl bg-amber-950/40 border border-amber-500/50 text-amber-200 text-xs flex items-start justify-between space-y-1">
          <div>
            <p className="font-bold text-amber-400">Single-Device Lock Triggered</p>
            <p className="mt-0.5">{forcedLogoutReason || 'Another device signed in to this account. Session revoked.'}</p>
          </div>
          <button
            onClick={clearForcedLogout}
            className="text-amber-400 font-bold ml-2 underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Body View based on currentTab */}
      <main className="flex-1 pb-20">
        {currentTab === 'feed' && (
          <div className="px-3 pt-3">
            {loadingPosts ? (
              <div className="flex flex-col items-center justify-center py-20 space-y-3">
                <div className="w-8 h-8 border-2 border-[#00E5FF] border-t-transparent rounded-full animate-spin" />
                <p className="text-xs text-[#9AA4AF] font-mono">Loading AMOLED Feed...</p>
              </div>
            ) : posts.length === 0 ? (
              <div className="py-20 text-center text-[#9AA4AF] text-xs">
                <p className="text-sm font-semibold text-white">No posts in this channel</p>
                <p className="mt-1">Try switching topic filters or create a new post.</p>
              </div>
            ) : (
              posts.map((post) => (
                <FeedCard
                  key={post.id}
                  post={post}
                  onLikeToggle={handleLikeToggle}
                  onOpenComments={(p) => setActiveCommentsPost(p)}
                  onOpenReport={(pId) => setActiveReportPostId(pId)}
                />
              ))
            )}
          </div>
        )}

        {currentTab === 'explore' && (
          <div className="p-4 space-y-4">
            <div className="flex items-center space-x-2">
              <Compass className="w-5 h-5 text-[#00E5FF]" />
              <h3 className="font-extrabold text-sm text-white">Explore Trending Photos & Short Videos</h3>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {posts.slice(0, 8).map((p, idx) => {
                const isVid = p.postType === 'video' || p.media[0]?.type === 'video';
                return (
                  <div
                    key={`${p.id}-${idx}`}
                    onClick={() => setActiveCommentsPost(p)}
                    className="relative aspect-square rounded-xl overflow-hidden cursor-pointer group bg-[#0B0D10] border border-[#14171C]"
                  >
                    {isVid ? (
                      <video
                        src={p.media[0]?.url}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        muted
                        playsInline
                      />
                    ) : (
                      <img
                        src={p.media[0]?.url || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400'}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    )}

                    {/* Format Badge */}
                    <span className="absolute top-2 left-2 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] text-[#00E5FF] font-medium border border-white/10 z-10 flex items-center space-x-1">
                      <span>{isVid ? '🎬 Video' : '📸 Photo'}</span>
                    </span>

                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center space-x-3 text-white font-bold text-xs transition-opacity z-10">
                      <span>❤️ {p.likesCount}</span>
                      <span>💬 {p.commentsCount}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {currentTab === 'ai' && <BigFixAIDashboard />}

        {currentTab === 'profile' && (
          <ProfileView
            onOpenDeviceManager={() => setIsDeviceModalOpen(true)}
            onPostSelect={(post) => setActiveCommentsPost(post)}
          />
        )}
      </main>
    </>
  );

  return (
    <div className="min-h-screen bg-black text-[#F5F7FA] font-['Plus_Jakarta_Sans'] flex flex-col items-center relative">
      {/* USER REQUESTED: Desktop Switch Button in the TOP CORNER */}
      <div className="fixed top-2.5 right-3 sm:top-3.5 sm:right-4 z-50 flex items-center space-x-2">
        <button
          id="top-corner-desktop-switch-btn"
          onClick={() => setPlatformMode(isMobile ? 'desktop' : 'android')}
          className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#00E5FF] to-[#7C4DFF] hover:brightness-110 text-black font-extrabold text-xs shadow-xl shadow-[#00E5FF]/30 flex items-center space-x-1.5 transition-all active:scale-95 border border-white/30 backdrop-blur-md"
          title={isMobile ? 'Switch to Desktop / PC Mode' : 'Switch to Mobile Phone Mode'}
        >
          {isMobile ? (
            <>
              <Monitor className="w-3.5 h-3.5" />
              <span>Desktop Mode</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile Mode</span>
            </>
          )}
        </button>
      </div>

      {/* 1. Global Multi-Platform Switcher Toolbar (Android, iOS, Desktop, Mac) */}
      <div className="w-full bg-[#0B0D10] border-b border-[#14171C] px-3 py-1.5 flex flex-wrap items-center justify-between text-[11px] text-[#9AA4AF] z-40 sticky top-0 pr-36 sm:pr-40">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-[#00E5FF] animate-pulse" />
          <span className="font-extrabold text-white font-mono tracking-wider">Z-EYE MULTI-PLATFORM</span>
          <span className="hidden md:inline text-[#9AA4AF]">| Android • iOS • Desktop • Mac</span>
        </div>

        {/* 4 Platform Switch Tabs */}
        <div className="flex items-center space-x-1 bg-[#14171C] p-1 rounded-xl border border-[#222730]">
          <button
            id="platform-android-btn"
            onClick={() => setPlatformMode('android')}
            className={`px-2.5 py-1 rounded-lg flex items-center space-x-1.5 text-xs font-semibold transition-all ${
              platformMode === 'android'
                ? 'bg-[#00E5FF] text-black font-extrabold shadow-sm shadow-[#00E5FF]/20'
                : 'text-[#9AA4AF] hover:text-white hover:bg-[#222730]'
            }`}
            title="Android AMOLED Phone Frame (Galaxy / Pixel)"
          >
            <span>🤖</span>
            <span>Android</span>
          </button>

          <button
            id="platform-ios-btn"
            onClick={() => setPlatformMode('ios')}
            className={`px-2.5 py-1 rounded-lg flex items-center space-x-1.5 text-xs font-semibold transition-all ${
              platformMode === 'ios'
                ? 'bg-[#00E5FF] text-black font-extrabold shadow-sm shadow-[#00E5FF]/20'
                : 'text-[#9AA4AF] hover:text-white hover:bg-[#222730]'
            }`}
            title="Apple iOS iPhone 16 Pro Dynamic Island Frame"
          >
            <span>🍏</span>
            <span>iOS</span>
          </button>

          <button
            id="platform-desktop-btn"
            onClick={() => setPlatformMode('desktop')}
            className={`px-2.5 py-1 rounded-lg flex items-center space-x-1.5 text-xs font-semibold transition-all ${
              platformMode === 'desktop'
                ? 'bg-[#00E5FF] text-black font-extrabold shadow-sm shadow-[#00E5FF]/20'
                : 'text-[#9AA4AF] hover:text-white hover:bg-[#222730]'
            }`}
            title="Windows 11 PC Desktop 3-Column Layout"
          >
            <span>💻</span>
            <span>Desktop</span>
          </button>

          <button
            id="platform-mac-btn"
            onClick={() => setPlatformMode('mac')}
            className={`px-2.5 py-1 rounded-lg flex items-center space-x-1.5 text-xs font-semibold transition-all ${
              platformMode === 'mac'
                ? 'bg-[#00E5FF] text-black font-extrabold shadow-sm shadow-[#00E5FF]/20'
                : 'text-[#9AA4AF] hover:text-white hover:bg-[#222730]'
            }`}
            title="macOS Sonoma Frosted Glass Studio Layout"
          >
            <span>🍎</span>
            <span>Mac</span>
          </button>
        </div>
      </div>

      {/* 2. MOBILE VIEW (Android / iOS) */}
      {isMobile && (
        <div className="w-full flex-1 flex flex-col items-center justify-start py-4 px-2 sm:px-4">
          {/* Mobile Chassis Device Bezel Frame */}
          <div
            className={`w-full max-w-[440px] transition-all flex flex-col bg-black shadow-2xl relative ${
              platformMode === 'ios'
                ? 'rounded-[48px] border-[8px] border-[#1F242E] shadow-[#00E5FF]/5'
                : 'rounded-[38px] border-[6px] border-[#1A1E26] shadow-[#00E5FF]/5'
            }`}
          >
            {/* System Status Bar: Android vs iOS */}
            {platformMode === 'android' ? (
              <AndroidTopBar onDesktopSwitch={() => setPlatformMode('desktop')} />
            ) : (
              <IosTopBar onDesktopSwitch={() => setPlatformMode('desktop')} />
            )}

            {/* Mobile Header with USER-REQUESTED 'Desktop Mode' Button */}
            <Header
              selectedTag={selectedTag}
              onSelectTag={setSelectedTag}
              onOpenDeviceManager={() => setIsDeviceModalOpen(true)}
              onOpenBigFixAI={() => setCurrentTab('ai')}
              onOpenOptimizer={() => setIsOptimizerModalOpen(true)}
              platformMode={platformMode}
              onSwitchToDesktop={() => setPlatformMode('desktop')}
            />

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto">
              {renderMainContent()}
            </div>

            {/* Mobile Bottom Navigation */}
            <Navigation currentTab={currentTab} onSelectTab={handleNavSelect} />

            {/* Mobile Bottom System Bar: Android 3-button vs iOS Home Indicator */}
            {platformMode === 'android' ? (
              <AndroidBottomBar
                onBack={() => {
                  if (currentTab !== 'feed') {
                    setCurrentTab('feed');
                  }
                }}
                onHome={() => {
                  setCurrentTab('feed');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onRecents={() => setIsDeviceModalOpen(true)}
              />
            ) : (
              <IosHomeIndicator />
            )}
          </div>
        </div>
      )}

      {/* 3. DESKTOP & MAC VIEW (Full Responsive 3-Column Layout) */}
      {!isMobile && (
        <div className="w-full max-w-7xl mx-auto flex-1 flex flex-col min-h-screen">
          {/* Windows / macOS Title Bar with Window Controls */}
          <DesktopWindowBar
            platformMode={platformMode}
            onSelectPlatform={setPlatformMode}
            onSwitchToMobile={() => setPlatformMode('android')}
          />

          {/* Responsive 3-Column Layout: Left Sidebar + Center Feed + Right Panel */}
          <div className="flex-1 flex w-full">
            {/* Left Sidebar */}
            <DesktopSidebar
              currentTab={currentTab}
              onSelectTab={handleNavSelect}
              platformMode={platformMode}
              onSelectPlatform={setPlatformMode}
              onOpenDeviceManager={() => setIsDeviceModalOpen(true)}
              onSwitchToMobile={() => setPlatformMode('android')}
            />

            {/* Center Feed Column */}
            <div className="flex-1 max-w-2xl min-h-screen border-r border-[#1C2028] bg-black">
              <Header
                selectedTag={selectedTag}
                onSelectTag={setSelectedTag}
                onOpenDeviceManager={() => setIsDeviceModalOpen(true)}
                onOpenBigFixAI={() => setCurrentTab('ai')}
                onOpenOptimizer={() => setIsOptimizerModalOpen(true)}
                platformMode={platformMode}
                onSwitchToMobile={() => setPlatformMode('android')}
              />
              {renderMainContent()}
            </div>

            {/* Right Telemetry & Platform Switcher Panel */}
            <DesktopRightPanel
              platformMode={platformMode}
              onSelectPlatform={setPlatformMode}
              onSwitchToMobile={() => setPlatformMode('android')}
              onOpenOptimizer={() => setIsOptimizerModalOpen(true)}
            />
          </div>
        </div>
      )}

      {/* Threaded Comments Sheet */}
      <CommentsSheet
        post={activeCommentsPost}
        onClose={() => setActiveCommentsPost(null)}
        onCommentAdded={loadFeed}
      />

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onPostCreated={() => {
          loadFeed();
          setCurrentTab('feed');
        }}
      />

      {/* Single-Device Lock & Sessions Manager */}
      <DeviceLockModal
        isOpen={isDeviceModalOpen}
        onClose={() => setIsDeviceModalOpen(false)}
      />

      {/* Device Hardware Optimizer & Sentinel Bot Modal */}
      <DeviceOptimizerModal
        isOpen={isOptimizerModalOpen}
        onClose={() => setIsOptimizerModalOpen(false)}
        currentPlatformMode={platformMode}
        onPlatformChange={setPlatformMode}
      />

      {/* Safety Report Modal */}
      <SafetyReportModal
        postId={activeReportPostId}
        onClose={() => setActiveReportPostId(null)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SyncProvider>
        <MainApp />
      </SyncProvider>
    </AuthProvider>
  );
}
